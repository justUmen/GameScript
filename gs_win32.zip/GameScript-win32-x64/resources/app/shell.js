const electron = require('electron')
const app = electron.app
const Menu = electron.Menu
const Tray = electron.Tray
const BrowserWindow = electron.BrowserWindow
const path = require('path')
const url = require('url')

//~ var shell = require('shelljs');
var iconpath = path.join(__dirname, 'icons/logo.png')
var iconpath2 = path.join(__dirname, 'icons/logo2.png')

let GameScriptWindow
function createWindow () {

	GameScriptWindow = new BrowserWindow({show: false, 
		webPreferences: {
			webSecurity: false
		}
	})
	//webSecurity false to load file:// like in change_wallpaper(window.images);
  
  // GameScriptWindow.setMenu(null);

  var appIcon = null;
  appIcon = new Tray(iconpath);
  var contextMenu = Menu.buildFromTemplate([
      { label: 'Show GS', click:  function(){
          GameScriptWindow.maximize();
      } },
      { label: 'Quit GS', click:  function(){
          app.isQuiting = true;
          app.quit();
      } }
  ]);
  appIcon.setToolTip('GameScript - Electron Application');
  appIcon.setContextMenu(contextMenu);
  appIcon.on('click', function(e){
     if (GameScriptWindow.isVisible()) {
       GameScriptWindow.hide()
       appIcon.setImage(iconpath2);
     } else {
       GameScriptWindow.maximize()
       appIcon.setImage(iconpath);
     }
   });

	GameScriptWindow.setBackgroundColor("#000");
	if(process.platform === "win32"){
		GameScriptWindow.loadURL(url.format({
		  pathname: path.join(__dirname, 'shell.html'),
		  protocol: 'file:',
		  slashes: true
		}));
	}
	else{
		GameScriptWindow.loadURL("file:///home/umen/SyNc/Projects/GameScript_electron/shell.html");
	}
	GameScriptWindow.once('ready-to-show', () => {
		// GameScriptWindow.show()
		GameScriptWindow.maximize()
	})

	GameScriptWindow.webContents.openDevTools()

  // GameScriptWindow.on('minimize',function(event){
  //     event.preventDefault();
  //     GameScriptWindow.hide();
  // });

  GameScriptWindow.on('close', function (event) {
      if(!app.isQuiting){
          event.preventDefault();
          GameScriptWindow.hide();
      }
      return false;
  });
}


app.on('ready', createWindow)

app.on('activate', function () {
  // On OS X it's common to re-create a window in the app when the
  // dock icon is clicked and there are no other windows open.
  if (GameScriptWindow === null) {
    createWindow()
  }
})
