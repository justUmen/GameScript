

function real_tree_1(){
GS_text.innerHTML += `<pre>
                                              .         ;
                 .              .              ;%     ;;
                   ,           ,                :;%  %;
                    :         ;                   :;%;'     .,
           ,.        %;     %;            ;        %;'    ,;
             ;       ;%;  %%;        ,     %;    ;%;    ,%'
              %;       %;%;      ,  ;       %;  ;%;   ,%;'%;%;;,.
               ;%;      %;        ;%;        % ;%;  ,%;'
                '%;.     ;%;     %;'         ';%%;.%;'
                 ':;%.    ;%%. %@;        %; ;@%;%'
                    ':%;.  :;bd%;          %;@%;'
                      '@%:.  :;%.         ;@@%;'
                        '@%.  ';@%.      ;@@%;
                          '@%%. '@%%    ;@@%;
                            ;@%. :@%%  %@@%;
                             %@bd%%%bd%%:;
                                #@%%%%%@@;
                                %@@%%%@@;
                                %@@@%(o);  . '
                                %@@@o%@@(.,'
                            '.. %@@@o%@@;
                               ')@@@o%@@;
                                %@@(o)@@;
                               .%@@@@%@@;
                               ;%@@@@%@@;.
                              ;%@@@`+code+` / `+reset+`@@@;.
                         ...;%@@@@@@@@@@@@%..</pre>`;
}


function real_tree_2(){
GS_text.innerHTML += `<pre>
                                              .         ;
                 .              .              ;%     ;;
                   ,           ,                :;%  %;
                    :         ;                   :;%;'     .,
           ,.        %;     %;            ;        %;'    ,;
             ;       ;%;  %%;        ,     %;    ;%;    ,%'
              %;       %;%;      ,  ;       %;  ;%;   ,%;'%;%;;,.`+code+` /home/user/Images/ `+reset+`
               ;%;      %;        ;%;        % ;%;  ,%;'
                '%;.     ;%;     %;'         ';%%;.%;'
                 ':;%.    ;%%. %@;        %; ;@%;%'`+code+` /home/user/ `+reset+`
                    ':%;.  :;bd%;          %;@%;'
                      '@%:.  :;%.         ;@@%;'
                        '@%.  ';@%.      ;@@%;
                          '@%%. `+code+` /var/ `+reset+`  ;@@%;
                            ;@%. :@%%  %@@%;
                       `+code+` /bin/ `+reset+`%@bd%%%bd%%:;`+code+` /home/ `+reset+`
                                #@%%%%%@@;
                                %@@%%%@@;
                                %@@@%(o);  . '
                                %@@@o%@@(.,'
                            '.. %@@@o%@@;
                               ')@@@o%@@;
                                %@@(o)@@;
                               .%@@@@%@@;
                               ;%@@@@%@@;.
                              ;%@@@`+code+` / `+reset+`@@@;.
                         ...;%@@@@@@@@@@@@%..</pre>`;
}


function real_tree_3(){
GS_text.innerHTML += `<pre>
                                              .         ;
                 .              .              ;%     ;;
                   ,           ,                :;%  %;
                    :         ;                   :;%;'     .,
           ,.        %;     %;            ;        %;'    ,;
             ;       ;%;  %%;        ,     %;    ;%;    ,%'      `+codeFile+` /home/user/Images/linux.jpeg `+reset+`
              %;       %;%;      ,  ;       %;  ;%;   ,%;'%;%;;,.`+code+` /home/user/Images/ `+reset+`
               ;%;      %;        ;%;        % ;%;  ,%;'
                '%;.     ;%;     %;'         ';%%;.%;'
                 ':;%.    ;%%. %@;        %; ;@%;%'`+code+` /home/user/ `+reset+`
                    ':%;.  :;bd%;          %;@%;'
                      '@%:.  :;%.         ;@@%;'
                        '@%.  ';@%.      ;@@%;`+codeFile+` /home/fichier1 `+reset+`
                          '@%%. `+code+` /var/ `+reset+`  ;@@%;
                            ;@%. :@%%  %@@%;
                       `+code+` /bin/ `+reset+`%@bd%%%bd%%:;`+code+` /home/ `+reset+`
                                #@%%%%%@@;
                                %@@%%%@@;
                                %@@@%(o);  . '
                                %@@@o%@@(.,'
                            '.. %@@@o%@@;
                               ')@@@o%@@;`+codeError+` /home `+reset+`
                                %@@(o)@@;`+codeFile+` /fichier1 `+reset+`
                               .%@@@@%@@;`+codeError+` /fichier1 `+reset+`
                               ;%@@@@%@@;.
                              ;%@@@`+code+` / `+reset+`@@@;.
                         ...;%@@@@@@@@@@@@%..</pre>`;
}
function real_tree_4(){
GS_text.innerHTML += `<pre>
                                              .         ;
                 .              .              ;%     ;;
                   ,           ,                :;%  %;
                    :         ;                   :;%;'     .,
           ,.        %;     %;            ;        %;'    ,;
             ;       ;%;  %%;        ,     %;    ;%;    ,%'      `+codeFile+` /home/user/Images/linux.jpeg `+reset+`
              %;       %;%;      ,  ;       %;  ;%;   ,%;'%;%;;,.`+code+` /home/user/Images/ `+reset+`
               ;%;      %;        ;%;        % ;%;  ,%;'
                '%;.     ;%;     %;'         ';%%;.%;'
                 ':;%.    ;%%. %@;        %; ;@%;%'`+code+` /home/user/ `+reset+`
                    ':%;.  :;bd%;          %;@%;'
                      '@%:.  :;%.         ;@@%;'
                        '@%.  ';@%.      ;@@%;`+codeFile+` /home/fichier1 `+reset+`
                          '@%%. `+code+` /var/ `+reset+`  ;@@%;
                            ;@%. :@%%  %@@%;
                       `+code+` /bin/ `+reset+`%@bd%%%bd%%:;`+code+` /home/ `+reset+`
                                #@%%%%%@@;
                                %@@%%%@@;
                                %@@@%(o);  . '
                                %@@@o%@@(.,'
                            '.. %@@@o%@@;
                               ')@@@o%@@;`+codeFile+` /Home `+reset+`
                                %@@(o)@@;`+codeFile+` /fichier1 `+reset+`
                               .%@@@@%@@;`+codeFile+` /fichier2 `+reset+`
                               ;%@@@@%@@;.
                              ;%@@@`+code+` / `+reset+`@@@;.
                         ...;%@@@@@@@@@@@@%..</pre>`;
}

function tree_1(){
GS_text.innerHTML += `<pre>
`+code+` / `+reset+`
|-- `+code+` /home/ `+reset+`
|   |-- `+code+` /home/user/ `+reset+`
|   |   |-- `+code+` /home/user/Pictures/ `+reset+`
|-- `+code+` /bin/ `+reset+`
|-- `+code+` /var/ </pre>`;
}

function tree_2(){
GS_text.innerHTML += `<pre>
`+code+` / `+reset+`
|-- `+code+` /home/ `+reset+`
|   |-- `+code+` /home/user/ `+reset+`
|   |   |-- `+code+` /home/user/Pictures/ `+reset+`
|   |   |   |-- `+codeFile+` /home/user/Pictures/linux.jpeg `+reset+`
|   |-- `+codeFile+` /home/fichier1 `+reset+`
|   |-- `+codeFile+` /home/fichier2 `+reset+`
|-- `+code+` /bin/ `+reset+`
|-- `+code+` /var/ `+reset+`
|-- `+codeFile+` /fichier1 `+reset+`
|-- `+codeFile+` /fichier2 `+reset+`
|-- `+codeFile+` /Home </pre>`;
}

function tree_3(){
GS_text.innerHTML += `<pre>
`+code+` / `+reset+`
`+code+` /home/ `+reset+`
`+code+` /home/user/ `+reset+`
`+code+` /home/user/Pictures/ `+reset+`
`+codeFile+` /home/user/Pictures/linux.jpeg `+reset+`
`+codeFile+` /home/fichier1 `+reset+`
`+codeFile+` /home/fichier2 `+reset+`
`+code+` /bin/ `+reset+`
`+code+` /var/ `+reset+`
`+codeFile+` /fichier1 `+reset+`
`+codeFile+` /fichier2 `+reset+`
`+codeFile+` /Home </pre>`;
}
async function launchGameScript_chapter_lecture() {

document.getElementById('toggle_music').style.display='inline';
document.getElementById('toggle_voice').style.display='inline';
document.getElementById('GS_selects').style.display='none';
document.getElementById('button_start_lecture').style.display='none';
document.getElementById('button_start_quiz').value='Stop Lecture';
document.getElementById('button_start_quiz').onclick = function() { location.reload(); }
toggle_music();
await new_line(4,"Hey salut tout le monde et bienvenue dans le premier chapitre sur bash.");
await new_line(5,"Avant de pouvoir apprendre notre première commande, il va falloir d'abord comprendre la logique derrière l'organisation des répertoires et des fichiers sur les systèmes d'exploitation de " + voc + "type Unix" + reset + ", comme " + voc + "Linux" + reset + ".");
await new_line(6,"Commençons par nous intéresser aux 'répertoires', qui portent aussi le nom de 'dossiers'.");
real_tree_1();
await new_line(8,"Vous pouvez imaginer le système d'organisation des dossiers comme un arbre.");
await new_line(9,"Dans cet arbre les lignes qui représentent les dossiers sont en bleu ciel.");
await new_line(10,"A la base de cet arbre vous avez le symbole " + code + "/" + reset + " qui représente le " + voc + "répertoire racine" + reset + ".");
await new_line(11,"C'est un répertoire spécial qui contiendra TOUS les autres dossiers du système.");
real_tree_2();
await new_line(13,"Dans cet arbre, à chaque fois qu'une branche se sépare de l'arbre, c'est un nouveau dossier.");
await new_line(14,"Ce passage à une autre branche se remarque aussi dans les titres en bleu ciel avec l'apparition d'un nouveau symbole '/' supplémentaire.");
await new_line(15,"Par exemple, " + code + "/home/" + reset + " représente le dossier 'home' dans le " + voc + "répertoire racine" + reset + ".");
await new_line(16,"" + code + "/home/user/" + reset + " représente le dossier 'user', qui est dans le dossier 'home', qui est lui même dans le " + voc + "répertoire racine" + reset + ".");
await new_line(17,"Et ainsi de suite, comme par exemple : " + code + "/home/user/Images/" + reset + "");
await new_line(18,"Dans ce cas, 'Images' est dans 'user', 'user' est dans 'home' et 'home' est dans '/'.");
await new_line(19,"Mais attention, pour représenter un répertoire, il n'est pas obligatoire de rajouter un '/' à la fin.");
await new_line(20,"C'est à dire que " + learn + "/home/user/" + reset + " est équivalent à " + learn + "/home/user" + reset + ".");
await new_line(21,"De même, " + learn + "/home/" + reset + " et " + learn + "/home" + reset + " sont équivalents.");
real_tree_3();
await new_line(23,"Parlons maintenant des fichiers, dans mon arbre ils sont ici en vert. Ce sont dans mon exemple des 'feuilles' et sont directement acrochés à une branche, ou parfois même directement au tronc.");
await new_line(24,"Ces fichiers appartiennent donc directement à un dossier. Mais nous avons ici quelques problèmes en rouge, des fichiers qui ne peuvent pas exister...");
await new_line(25,"" + codeError + "fichier1" + reset + " ne peut pas exister car il y a déjà un fichier du même nom " + codeFile + "fichier1" + reset + " dans le même répertoire. Ici le répertoire racine. (/fichier1)");
await new_line(26,"En revanche, en haut, " + codeFile + "fichier1" + reset + " peut exister car même si le nom du fichier est le même, ils ne sont pas dans le même dossier.");
await new_line(27,"Les éléments d'un système de type Unix doivent avoir une référence unique : ici " + learn + "/fichier1" + reset + " et " + learn + "/home/fichier1" + reset + " ne sont pas en conflit.");
await new_line(28,"Le fichier " + codeError + "/home" + reset + " ne peut pas exister non plus car il y a déjà un dossier " + code + "/home/" + reset + " qui utilise le même nom au même endroit.");
await new_line(29,"Pour que ces fichiers puissent exister, il faut leur donner d'autres noms.");
real_tree_4();
await new_line(31,"Ici, il suffit d'appeler le deuxième fichier 'fichier2' et le tour est joué.");
await new_line(32,"Pour " + codeError + "home" + reset + ", il suffit également de lui donner un autre nom qui ne pose pas de problème comme 'Home', avec un h majuscule.");
await new_line(33,"Oui ! Dans un système d'exploitation de type Unix, les majuscules sont importantes. 'Home', avec un grand H et 'home' sont deux noms différents.");
await new_line(34,"En informatique, quand les majuscules ne sont pas équivalentes aux minuscules, on dit que les noms sont " + voc + "sensibles à la casse" + reset + ".");
await new_line(35,"Effectivement, les systèmes de type Unix sont " + voc + "sensibles à la casse" + reset + ". C'est à dire que 'home', 'Home', 'hOme', 'hoMe', 'homE', 'HoMe', 'hOmE', 'HOme', 'hoME', 'HomE', 'hOMe', 'HOME', etc... sont valides et différentes !");
tree_1();
await new_line(37,"Il est aussi possible de représenter l'arborescence linux de cette manière.");
tree_2();
await new_line(39,"Et ici le même exemple avec les fichiers. Identique à l'arbre que l'on a déjà vu.");
tree_3();
await new_line(41,"Mais l'arborescence peut aussi être très claire sans les décalages.");
await new_line(42,"Si ça n'est pas encore très intuitif pour vous, ne vous inquiétez pas.");
await new_line(43,"Maintenant que vous connaissez la logique, avec le temps et la répétition ce sera pour vous très bientôt évident.");
await new_line(44,"Ce genre de ligne, qui commence par ce '/' ou " + voc + "répertoire racine" + reset + " s'appelle le " + voc + "chemin absolu" + reset + " d'un fichier ou d'un dossier.");
await new_line(45,"Elle représente avec précision uniquement le fichier ou dossier en question.");
await new_line(46,"Ici il est impossible d'avoir deux lignes identiques.");
await new_line(47,"Ce " + voc + "chemin absolu" + reset + " est le concept le plus fondamental de la ligne de commande.");
await new_line(48,"Maintenant nous pouvons voir notre première commande.");
await new_line(49,"Commençons par créer un nouveau dossier avec la commande " + learn + "mkdir" + reset + " (mkdir vient de l'anglais " + learn + "M" + reset + "a" + learn + "K" + reset + "e " + learn + "DIR" + reset + "ectory).");
await new_line(50,"Il suffit de taper mkdir, suivi d'un espace et enfin du nom du dossier.");
new_line_no_wait(51,"Créeons maintenant le dossier House en faisant : " + learn + "mkdir House" + reset + " puis validez la commande en appuyant sur la touche entrée.");
await interactive(52,"mkdir House");
funcjs_52_mkdir_House();
new_line_no_wait(53,"Affichons maintenant les dossiers et les fichiers avec un simple " + learn + "ls" + reset + " (ls vient de l'anglais " + learn + "L" + reset + "i" + learn + "S" + reset + "t).");
await interactive(54,"ls");
funcjs_54_ls();
await new_line(55,"Vous devriez voir le dossier que vous venez de créer.");
await new_line(56,"Maintenant rentrons dans ce dossier avec la commande " + learn + "cd" + reset + " (cd vient de l'anglais " + learn + "C" + reset + "hange " + learn + "D" + reset + "irectory).");
new_line_no_wait(57,"Pour cela, il suffit de faire " + code + "cd" + reset + ", suivi du nom du dossier voulu, dans notre cas : " + learn + "cd House" + reset + ".");
await interactive(58,"cd House");
funcjs_58_cd_House();
new_line_no_wait(59,"Maintenant réaffichons les fichiers et dossiers avec un simple " + learn + "ls" + reset + ".");
await interactive(60,"ls");
funcjs_60_ls();
await new_line(61,"Ici le répertoire 'House' est vide, c'est normal puisque nous venons de le créer.");
await new_line(62,"Mais qu'en est-il ici du " + voc + "chemin absolu" + reset + " dont je vous ai parlé avant ?");
await new_line(63,"En fait, un terminal tourne toujours dans un dossier, et peut se 'déplacer' dans l'arborescense du système.");
await new_line(64,"C'est ce que vous avez fait avec la commande " + learn + "cd House" + reset + ", vous avez déplacé votre terminal dans le dossier 'House'.");
new_line_no_wait(65,"Pour savoir dans quel répertoire votre terminal est en ce moment, il suffit de taper " + learn + "pwd" + reset + " (pwd vient de l'anglais " + learn + "P" + reset + "rint " + learn + "W" + reset + "orking " + learn + "D" + reset + "irectory).");
await interactive(66,"pwd");
funcjs_66_pwd();
await new_line(67,"Le résultat que vous voyiez ici est le " + voc + "chemin absolu" + reset + " du répertoire ou vous êtes en ce moment.");
await new_line(68,"Ce répertoire où vous êtes porte un nom spécial : c'est votre " + voc + "" + voc + "répertoire courant" + reset + ".");
await new_line(69,"Comme je vous l'ai déjà dit, il n'est pas obligatoire de mettre un '/' pour le dernier dossier, c'est pourquoi vous voyez ici " + learn + "$(pwd)" + reset + " sans un '/' à la fin.");
await new_line(70,"Voilà donc 4 commandes Unix fondamentales : " + learn + "pwd" + reset + ", " + learn + "ls" + reset + ", " + learn + "cd" + reset + " et " + learn + "mkdir" + reset + ".");
await new_line(71,"" + learn + "pwd" + reset + " et " + learn + "ls" + reset + " sont des commandes particulièrement innoffensives, elle ne font que vous donnez des renseignements.");
await new_line(72,"N'hésitez donc pas à les taper systématiquement, dès que vous êtes dans un terminal.");
await new_line(73,"" + learn + "pwd" + reset + ", pour savoir quel est votre " + voc + "répertoire courant" + reset + "");
await new_line(74,"et " + learn + "ls" + reset + ", pour afficher le contenu de votre " + voc + "répertoire courant" + reset + ".");
new_line_no_wait(75,"Maintenant créons un nouveau répertoire 'Room' dans notre " + voc + "répertoire courant" + reset + " en faisant " + learn + "mkdir Room" + reset + ".");
await interactive(76,"mkdir Room");
funcjs_76_mkdir_Room();
new_line_no_wait(77,"Changeons de " + voc + "répertoire courant" + reset + " avec " + learn + "cd Room" + reset + ".");
await interactive(78,"cd Room");
funcjs_78_cd_Room();
new_line_no_wait(79,"Maintenant, affichez le chemin absolu de votre " + voc + "répertoire courant" + reset + ".");
await interactive(80,"pwd");
funcjs_80_pwd();
new_line_no_wait(81,"Super, et maintenant affichez les éléments du " + voc + "répertoire courant" + reset + ".");
await interactive(82,"ls");
funcjs_82_ls();
await new_line(83,"Ici le dossier est vide, mais vous maitrisez maintenant les deux commandes les plus importantes : " + learn + "pwd" + reset + " et " + learn + "ls" + reset + ".");
await new_line(84,"Les commandes " + learn + "cd" + reset + " et " + learn + "mkdir" + reset + " que nous avons vu ensemble sont plus complexes.");
await new_line(85,"Il faut leur donner une cible, ou un nom comme par exemple : " + learn + "mkdir Room" + reset + ".");
await new_line(86,"Cette 'cible' est appelée un " + voc + "argument" + reset + "!");
await new_line(87,"Mais il est aussi possible d'avoir des commandes avec plusieurs " + voc + "arguments" + reset + ".");
await new_line(88,"Il suffit de continuer à les séparer par des espaces.");
new_line_no_wait(89,"On va créer les dossiers 'bed', 'closet' et 'desk' en une seule commande. Tapez donc la commande : " + learn + "mkdir bed closet desk" + reset + "");
await interactive(90,"mkdir bed closet desk");
funcjs_90_mkdir_bed_closet_desk();
new_line_no_wait(91,"Affichez les éléments du " + voc + "répertoire courant" + reset + ".");
await interactive(92,"ls");
funcjs_92_ls();
new_line_no_wait(93,"Maintenant pour supprimer ces dossiers, vous pouvez taper : " + learn + "rmdir bed closet desk" + reset + ". (rmdir vient de l'anglais " + learn + "R" + reset + "e" + learn + "M" + reset + "ove " + learn + "DIR" + reset + "ectory)");
await interactive(94,"rmdir bed closet desk");
funcjs_94_rmdir_bed_closet_desk();
await new_line(95,"" + learn + "rmdir" + reset + " est une commande plutôt innofensive, parce qu'elle refusera de supprimer un dossier si celui-ci n'est pas vide.");
await new_line(96,"Ce qui peut empêcher de graves accidents. Si par exemple, vous faites par erreur " + learn + "rmdir /home" + reset + ".");
await new_line(97,"La commande " + learn + "rm" + reset + " est la commande pour supprimer des fichiers. (rm vient de l'anglais " + learn + "R" + reset + "e" + learn + "M" + reset + "ove)");
await new_line(99,"Tout comme " + learn + "mkdir" + reset + ", il faudra lui donner en " + voc + "argument" + reset + " le nom du fichier en question, par exemple : " + learn + "rm test" + reset + ".");
new_line_no_wait(100,"Il vient de se passer quelque chose de bizarre... Affichez le contenu du " + voc + "répertoire courant" + reset + ".");
await interactive(101,"ls");
funcjs_101_ls();
new_line_no_wait(102,"" + code + "rmdir" + reset + " a bien supprimé les dossiers. Mais ces fichiers n'ont rien à faire ici, supprimez le fichier 'virus0' avec " + learn + "rm virus0" + reset + "");
await interactive(103,"rm virus0");
funcjs_103_rm_virus0();
new_line_no_wait(104,"Affichez à nouveau les éléments du " + voc + "répertoire courant" + reset + ", pour voir s'il est toujours là.");
await interactive(105,"ls");
funcjs_105_ls();
await new_line(106,"Super, virus0 n'existe plus.");
await new_line(107,"Mais attention avec la commande " + learn + "rm" + reset + ", c'est une commande dangereuse à ne pas utiliser à la légère.");
await new_line(108,"Les fichiers sont supprimés directement, il ne vont pas dans une corbeille, donc soyez prudent.");
await new_line(109,"Une erreur en ligne de commande ne pardonne pas.");
await new_line(110,"Une faute de frappe ou un " + voc + "répertoire courant" + reset + " innatendu peut avoir de graves conséquences.");
await new_line(111,"Avant de lancer une commande, soyez donc sûrs de ce que vous faites.");
await new_line(112,"N'hésitez jamais a lancer ou relancer " + learn + "pwd" + reset + " et " + learn + "ls" + reset + " pour savoir quel est votre " + voc + "répertoire courant" + reset + " et vérifier son contenu.");
await new_line(113,"Mais nous avons encore d'autres 'virus' à supprimer. Mais on peut aussi les supprimer d'une autre manière.");
await new_line(114,"Nous pouvons utiliser son " + voc + "chemin absolu" + reset + ".");
await new_line(116,"Lorsque vous avez tapé " + learn + "rm virus0" + reset + ", vous avez demandé la suppression du fichier 'virus0' dans votre " + voc + "répertoire courant" + reset + ".");
new_line_no_wait(117,"Je viens de changer votre " + voc + "répertoire courant" + reset + ". Affichez le maintenant.");
await interactive(118,"pwd");
funcjs_118_pwd();
new_line_no_wait(119,"Affichez le contenu de votre " + voc + "répertoire courant" + reset + ".");
await interactive(120,"ls");
funcjs_120_ls();
await new_line(121,"Le fichier 'virus1', existe toujours dans le répertoire 'Room', mais étant donné votre " + voc + "répertoire courant" + reset + ", vous ne pouvez pas lancer " + learn + "rm virus1" + reset + ".");
await new_line(122,"Heureusement, vous connaissez le " + voc + "chemin absolu" + reset + " du fichier 'virus1' : " + learn + "$HOME/House/Room/virus1${Reset}");
await new_line(123,"Vous pouvez utiliser son " + voc + "chemin absolu" + reset + " comme " + voc + "argument" + reset + ". Cette commande marchera donc quel que soit votre " + voc + "répertoire courant" + reset + " !");
new_line_no_wait(124,"Supprimez le avec cette commande : " + learn + "rm $HOME/House/Room/virus1" + reset + ".");
await interactive(125,"rm $HOME/House/Room/virus1");
funcjs_125_rm__HOME_House_Room_virus1();
await new_line(126,"Maintenant, comment pouvoir vérifier si le fichier a bien été supprimé ?");
await new_line(127,"Lorsqu'une commande ne se passe pas comme prévue, elle vous renvoit très souvent une erreur.");
new_line_no_wait(128,"Essayez de supprimer le fichier 'virus1' à nouveau en utilisant son " + voc + "chemin absolu" + reset + ".");
await interactive(129,"rm $HOME/House/Room/virus1");
funcjs_129_rm__HOME_House_Room_virus1();
await new_line(130,"Ici la commande " + learn + "rm" + reset + " vous renvoit une erreur, le fichier n'existe donc déjà plus.");
await new_line(131,"Maintenant, on peut aussi utiliser le " + voc + "chemin absolu" + reset + " du dossier 'Room' pour afficher son contenu.");
await new_line(132,"Vous connaissez déjà la commande " + learn + "ls" + reset + ", pour lister le contenu du " + voc + "répertoire courant" + reset + ".");
await new_line(133,"Sans " + voc + "argument" + reset + ", avec un simple " + learn + "ls" + reset + ", le répertoire utilisé sera automatiquement le " + voc + "répertoire courant" + reset + ".");
await new_line(134,"Mais il est en fait aussi possible de donner un " + voc + "argument" + reset + " à " + learn + "ls" + reset + ".");
await new_line(135,"Cet " + voc + "argument" + reset + " représente le répertoire cible, par exemple " + learn + "ls /" + reset + " affichera le contenu du " + voc + "répertoire racine" + reset + ".");
new_line_no_wait(136,"Nous pouvons afficher le contenu du répertoire 'Room' sans se déplacer dans l'arborescence, avec cette commande : " + learn + "ls $HOME/House/Room/" + reset + ".");
await interactive(137,"ls $HOME/House/Room/");
funcjs_137_ls__HOME_House_Room_();
await new_line(138,"Excellent, le fichier 'virus1' n'existe plus.");
await new_line(139,"Encore une fois, je vous rappelle que dans un " + voc + "chemin absolu" + reset + ", si le dernier caractère est un '/', il n'est pas obligatoire.");
new_line_no_wait(140,"Donc ici le dernier '/' dans " + learn + "$HOME/House/Room/" + reset + " n'est pas obligatoire. Testez donc à nouveau avec cette commande : " + learn + "ls $HOME/House/Room" + reset + "");
await interactive(141,"ls $HOME/House/Room");
funcjs_141_ls__HOME_House_Room();
await new_line(142,"Pas de problème, le résultat est le même pour ces deux commandes : " + learn + "ls $HOME/House/Room/" + reset + " et " + learn + "ls $HOME/House/Room" + reset + ".");
await new_line(143,"Quand vous avez fait " + learn + "rm virus0" + reset + " pour la première suppression, vous avez utilisé ce que l'on appelle le " + voc + "chemin relatif" + reset + ".");
await new_line(144,"On dit que ce chemin est relatif parce qu'il dépend de votre " + voc + "répertoire courant" + reset + ".");
await new_line(145,"Imaginons deux fichiers 'virus' avec comme " + voc + "chemin absolu" + reset + " : " + learn + "/virus" + reset + " et " + learn + "/bin/virus" + reset + ".");
await new_line(146,"Si " + learn + "pwd" + reset + " vous donne " + learn + "$HOME" + reset + ". Un " + learn + "rm virus" + reset + " ne supprimera aucun d'entre eux. Cette commande voudra supprimer le fichier avec ce chemin absolu : " + learn + "$HOME/virus" + reset + ".");
await new_line(148,"D'où la très grande utilité de ce " + voc + "chemin absolu" + reset + ". Vous pouvez utiliser " + learn + "rm /virus" + reset + " et " + learn + "rm /bin/virus" + reset + " quel que soit votre " + voc + "répertoire courant" + reset + ".");
new_line_no_wait(149,"Je viens de vous déplacer dans l'arborescence, affichez donc le chemin absolu du " + voc + "répertoire courant" + reset + ".");
await interactive(150,"pwd");
funcjs_150_pwd();
await new_line(151,"Pour changer de " + voc + "répertoire courant" + reset + ", vous pouvez utiliser la commande " + learn + "cd" + reset + ".");
await new_line(152,"Pour revenir dans le répertoire 'Room', vous pouvez utiliser son " + voc + "chemin absolu" + reset + " : " + learn + "cd $HOME/House/Room/" + reset + "");
await new_line(153,"Mais il n'est pas obligatoire d'utiliser son " + voc + "chemin absolu" + reset + ", il est aussi possible de revenir dans le répertoire 'Room' en utilisant son " + voc + "chemin relatif" + reset + ".");
await new_line(154,"Vous voulez aller dans " + learn + "$HOME/House/Room/" + reset + " mais vous êtes déjà dans " + learn + "$HOME" + reset + ".");
new_line_no_wait(155,"Il est donc possible de se déplacer de là où vous êtes avec un " + learn + "cd House/Room/" + reset + ". Allez-y.");
await interactive(156,"cd House/Room/");
funcjs_156_cd_House_Room_();
new_line_no_wait(157,"Affichez maintenant les éléments de votre " + voc + "répertoire courant" + reset + ".");
await interactive(158,"ls");
funcjs_158_ls();
new_line_no_wait(159,"Ici vous voyez encore des fichiers virus, supprimez le fichier virus2 en utilisant le " + voc + "chemin relatif" + reset + ".");
await interactive(160,"rm virus2");
funcjs_160_rm_virus2();
await new_line(161,"Excellent!");
await new_line(162,"Nous avons vu dans l'exemple précédent que " + learn + "cd House/Room/" + reset + " utilise un " + voc + "chemin relatif" + reset + ", pourtant cette commande contient aussi des '/'.");
await new_line(163,"Donc comment reconnaitre un " + voc + "chemin absolu" + reset + " d'un " + voc + "chemin relatif" + reset + " ?");
await new_line(164,"Le " + voc + "chemin absolu" + reset + " est en fait très facile à reconnaitre !");
await new_line(165,"Il commence toujours à la racine, c'est à dire que le premier caractère d'un " + voc + "chemin absolu" + reset + " est toujours un '/'.");
await new_line(166,"Il y a aussi une syntaxe spéciale très utile pour le " + voc + "chemin relatif" + reset + " : " + learn + ".." + reset + "");
await new_line(167,"" + learn + ".." + reset + " représente dans l'arborescence le parent du " + voc + "répertoire courant" + reset + ".");
await new_line(168,"C'est le vocabulaire que nous employons pour parler de cette arborescence, ce sont des relations parents / enfants.");
await new_line(169,"Par exemple pour " + learn + "/home/user/test/" + reset + ", le dossier parent de test est user. Le dossier parent de user est home.");
await new_line(170,"Et bien évidemment test est un enfant de user, et user est un enfant de home.");
await new_line(171,"Cibler les enfants en " + voc + "argument" + reset + " avec un " + voc + "chemin relatif" + reset + " est très simple, il suffit d'écrire le nom de leurs parents successifs.");
await new_line(172,"Comme par exemple avec la commande de tout a l'heure : " + learn + "cd House/Room/${reet}");
await new_line(173,"Pour cibler les parents, c'est un peu plus compliqué. Il faut utiliser " + learn + ".." + reset + ".");
new_line_no_wait(174,"Affichez donc le chemin absolu de votre " + voc + "répertoire courant" + reset + ".");
await interactive(175,"pwd");
funcjs_175_pwd();
await new_line(176,"Vous connaissez aussi la commande pour changer de répertoire courant : " + learn + "cd" + reset + ".");
await new_line(177,"Ici nous allons nous déplacer dans le répertoire parent. Nous sommes dans " + learn + "$HOME/House/Room/" + reset + " mais nous voulons aller dans " + learn + "$HOME/House/" + reset + "");
new_line_no_wait(178,"Il est possible de remonter d'un cran dans l'arborescence, ou comme je viens de le dire de se déplacer dans le répertoire parent avec un " + learn + "cd .." + reset + "");
await interactive(179,"cd ..");
funcjs_179_cd___();
new_line_no_wait(180,"Affichez le chemin absolu du " + voc + "répertoire courant" + reset + ".");
await interactive(181,"pwd");
funcjs_181_pwd();
await new_line(182,"J'espère que le résultat de " + learn + "pwd" + reset + " est logique pour vous.");
new_line_no_wait(183,"Mais il nous reste deux virus à supprimer, commençons par supprimer le fichier virus3 avec son " + voc + "chemin relatif" + reset + ".");
await interactive(184,"rm Room/virus3");
funcjs_184_rm_Room_virus3();
new_line_no_wait(185,"Bien ! Maintenant supprimons le fichier virus4 en utilisant son " + voc + "chemin absolu" + reset + ".");
await interactive(186,"rm $HOME/House/Room/virus4");
funcjs_186_rm__HOME_House_Room_virus4();
await new_line(187,"Parfait, vous avez tout compris ! Et je vous donne rendez-vous au questionnaire !");
}
async function launchGameScript_chapter_quiz() {
document.getElementById('GS_selects').style.display='none';
document.getElementById('toggle_music_quiz').style.display='inline';
document.getElementById('button_start_quiz').style.display='none';
document.getElementById('button_start_lecture').value='Stop Quiz';
document.getElementById('button_start_lecture').onclick = function() { location.reload(); }
toggle_music_quiz();
GOOD=1;
if(GOOD){ GOOD=await quiz("1","Quel symbole représente le répertoire racine sur Linux ?","/"); }
if(GOOD){ GOOD=await quiz("2","Quelle commande affiche le chemin absolu du répertoire courant ?","pwd"); }
if(GOOD){ GOOD=await quiz("3","Quelle commande affiche le contenu du répertoire racine ?","ls /"); }
if(GOOD){ GOOD=await quiz("4","Quelle commande change le répertoire courant du terminal par son répertoire parent ?","cd .."); }
if(GOOD){ GOOD=await quiz("5","Quelle commande affiche le contenu du répertoire courant ?","ls"); }
if(GOOD){ GOOD=await quiz("6","Quelle commande supprime le dossier vide 'test' du répertoire courant ?","rmdir test"); }
if(GOOD){ GOOD=await quiz("7","Par quel symbole commence le chemin absolu d'un fichier ?","/"); }
if(GOOD){ GOOD=await quiz("8","Le nom du chemin relatif d'un fichier est souvent plus court que son équivalent en chemin absolu. (vrai/faux)","vrai"); }
if(GOOD){ GOOD=await quiz("9","Quelle commande peut supprimer le fichier /home/test quel que soit votre répertoire courant ?","rm /home/test"); }
P1="24d8";
P2="f016";
await ask_username(P1,P2);
}
