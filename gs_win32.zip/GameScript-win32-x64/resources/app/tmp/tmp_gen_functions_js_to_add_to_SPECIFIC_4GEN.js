function funcjs_52_mkdir_House(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_54_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_58_cd_House(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_60_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_66_pwd(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_76_mkdir_Room(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_78_cd_Room(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_80_pwd(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_82_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_90_mkdir_bed_closet_desk(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_92_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_94_rmdir_bed_closet_desk(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_101_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_103_rm_virus0(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_105_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_118_pwd(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_120_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_125_rm__HOME_House_Room_virus1(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_129_rm__HOME_House_Room_virus1(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_137_ls__HOME_House_Room_(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_141_ls__HOME_House_Room(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_150_pwd(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_156_cd_House_Room_(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_158_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_160_rm_virus2(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_175_pwd(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_179_cd___(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_181_pwd(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_184_rm_Room_virus3(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_186_rm__HOME_House_Room_virus4(){
GS_text.innerHTML += `<hr>
<hr>`;}
