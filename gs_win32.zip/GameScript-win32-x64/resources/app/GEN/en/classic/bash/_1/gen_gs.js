//~ ??? NEED TO GO FROM FRENCH TO ENGLISH :P 

function real_tree_1(){
GS_text.innerHTML += `<hr>
<pre>
                                              .         ;
                 .              .              ;%     ;;
                   ,           ,                :;%  %;
                    :         ;                   :;%;'     .,
           ,.        %;     %;            ;        %;'    ,;
             ;       ;%;  %%;        ,     %;    ;%;    ,%'
              %;       %;%;      ,  ;       %;  ;%;   ,%;'%;%;;,.
               ;%;      %;        ;%;        % ;%;  ,%;'
                '%;.     ;%;     %;'         ';%%;.%;'
                 ':;%.    ;%%. %@;        %; ;@%;%'
                    ':%;.  :;bd%;          %;@%;'
                      '@%:.  :;%.         ;@@%;'
                        '@%.  ';@%.      ;@@%;
                          '@%%. '@%%    ;@@%;
                            ;@%. :@%%  %@@%;
                             %@bd%%%bd%%:;
                                #@%%%%%@@;
                                %@@%%%@@;
                                %@@@%(o);  . '
                                %@@@o%@@(.,'
                            '.. %@@@o%@@;
                               ')@@@o%@@;
                                %@@(o)@@;
                               .%@@@@%@@;
                               ;%@@@@%@@;.
                              ;%@@@`+code+` / `+reset+`@@@;.
                         ...;%@@@@@@@@@@@@%..</pre><hr>`;
}


function real_tree_2(){
GS_text.innerHTML += `<hr>
<pre>
                                              .         ;
                 .              .              ;%     ;;
                   ,           ,                :;%  %;
                    :         ;                   :;%;'     .,
           ,.        %;     %;            ;        %;'    ,;
             ;       ;%;  %%;        ,     %;    ;%;    ,%'
              %;       %;%;      ,  ;       %;  ;%;   ,%;'%;%;;,.`+code+` /home/user/Images/ `+reset+`
               ;%;      %;        ;%;        % ;%;  ,%;'
                '%;.     ;%;     %;'         ';%%;.%;'
                 ':;%.    ;%%. %@;        %; ;@%;%'`+code+` /home/user/ `+reset+`
                    ':%;.  :;bd%;          %;@%;'
                      '@%:.  :;%.         ;@@%;'
                        '@%.  ';@%.      ;@@%;
                          '@%%. `+code+` /var/ `+reset+`  ;@@%;
                            ;@%. :@%%  %@@%;
                       `+code+` /bin/ `+reset+`%@bd%%%bd%%:;`+code+` /home/ `+reset+`
                                #@%%%%%@@;
                                %@@%%%@@;
                                %@@@%(o);  . '
                                %@@@o%@@(.,'
                            '.. %@@@o%@@;
                               ')@@@o%@@;
                                %@@(o)@@;
                               .%@@@@%@@;
                               ;%@@@@%@@;.
                              ;%@@@`+code+` / `+reset+`@@@;.
                         ...;%@@@@@@@@@@@@%..</pre><hr>`;
}


function real_tree_3(){
GS_text.innerHTML += `<hr>
<pre>
                                              .         ;
                 .              .              ;%     ;;
                   ,           ,                :;%  %;
                    :         ;                   :;%;'     .,
           ,.        %;     %;            ;        %;'    ,;
             ;       ;%;  %%;        ,     %;    ;%;    ,%'      `+codeFile+` /home/user/Images/linux.jpeg `+reset+`
              %;       %;%;      ,  ;       %;  ;%;   ,%;'%;%;;,.`+code+` /home/user/Images/ `+reset+`
               ;%;      %;        ;%;        % ;%;  ,%;'
                '%;.     ;%;     %;'         ';%%;.%;'
                 ':;%.    ;%%. %@;        %; ;@%;%'`+code+` /home/user/ `+reset+`
                    ':%;.  :;bd%;          %;@%;'
                      '@%:.  :;%.         ;@@%;'
                        '@%.  ';@%.      ;@@%;`+codeFile+` /home/fichier1 `+reset+`
                          '@%%. `+code+` /var/ `+reset+`  ;@@%;
                            ;@%. :@%%  %@@%;
                       `+code+` /bin/ `+reset+`%@bd%%%bd%%:;`+code+` /home/ `+reset+`
                                #@%%%%%@@;
                                %@@%%%@@;
                                %@@@%(o);  . '
                                %@@@o%@@(.,'
                            '.. %@@@o%@@;
                               ')@@@o%@@;`+codeError+` /home `+reset+`
                                %@@(o)@@;`+codeFile+` /fichier1 `+reset+`
                               .%@@@@%@@;`+codeError+` /fichier1 `+reset+`
                               ;%@@@@%@@;.
                              ;%@@@`+code+` / `+reset+`@@@;.
                         ...;%@@@@@@@@@@@@%..</pre><hr>`;
}
function real_tree_4(){
GS_text.innerHTML += `<hr>
<pre>
                                              .         ;
                 .              .              ;%     ;;
                   ,           ,                :;%  %;
                    :         ;                   :;%;'     .,
           ,.        %;     %;            ;        %;'    ,;
             ;       ;%;  %%;        ,     %;    ;%;    ,%'      `+codeFile+` /home/user/Images/linux.jpeg `+reset+`
              %;       %;%;      ,  ;       %;  ;%;   ,%;'%;%;;,.`+code+` /home/user/Images/ `+reset+`
               ;%;      %;        ;%;        % ;%;  ,%;'
                '%;.     ;%;     %;'         ';%%;.%;'
                 ':;%.    ;%%. %@;        %; ;@%;%'`+code+` /home/user/ `+reset+`
                    ':%;.  :;bd%;          %;@%;'
                      '@%:.  :;%.         ;@@%;'
                        '@%.  ';@%.      ;@@%;`+codeFile+` /home/fichier1 `+reset+`
                          '@%%. `+code+` /var/ `+reset+`  ;@@%;
                            ;@%. :@%%  %@@%;
                       `+code+` /bin/ `+reset+`%@bd%%%bd%%:;`+code+` /home/ `+reset+`
                                #@%%%%%@@;
                                %@@%%%@@;
                                %@@@%(o);  . '
                                %@@@o%@@(.,'
                            '.. %@@@o%@@;
                               ')@@@o%@@;`+codeFile+` /Home `+reset+`
                                %@@(o)@@;`+codeFile+` /fichier1 `+reset+`
                               .%@@@@%@@;`+codeFile+` /fichier2 `+reset+`
                               ;%@@@@%@@;.
                              ;%@@@`+code+` / `+reset+`@@@;.
                         ...;%@@@@@@@@@@@@%..</pre><hr>`;
}

function tree_1(){
GS_text.innerHTML += `<hr>
<pre>
`+code+` / `+reset+`
|-- `+code+` /home/ `+reset+`
|   |-- `+code+` /home/user/ `+reset+`
|   |   |-- `+code+` /home/user/Pictures/ `+reset+`
|-- `+code+` /bin/ `+reset+`
|-- `+code+` /var/ </pre><hr>`;
}

function tree_2(){
GS_text.innerHTML += `<hr>
<pre>
`+code+` / `+reset+`
|-- `+code+` /home/ `+reset+`
|   |-- `+code+` /home/user/ `+reset+`
|   |   |-- `+code+` /home/user/Pictures/ `+reset+`
|   |   |   |-- `+codeFile+` /home/user/Pictures/linux.jpeg `+reset+`
|   |-- `+codeFile+` /home/fichier1 `+reset+`
|   |-- `+codeFile+` /home/fichier2 `+reset+`
|-- `+code+` /bin/ `+reset+`
|-- `+code+` /var/ `+reset+`
|-- `+codeFile+` /fichier1 `+reset+`
|-- `+codeFile+` /fichier2 `+reset+`
|-- `+codeFile+` /Home </pre><hr>`;
}

function tree_3(){
GS_text.innerHTML += `<hr>
<pre>
`+code+` / `+reset+`
`+code+` /home/ `+reset+`
`+code+` /home/user/ `+reset+`
`+code+` /home/user/Pictures/ `+reset+`
`+codeFile+` /home/user/Pictures/linux.jpeg `+reset+`
`+codeFile+` /home/fichier1 `+reset+`
`+codeFile+` /home/fichier2 `+reset+`
`+code+` /bin/ `+reset+`
`+code+` /var/ `+reset+`
`+codeFile+` /fichier1 `+reset+`
`+codeFile+` /fichier2 `+reset+`
`+codeFile+` /Home </pre><hr>`;
}

function funcjs_52_mkdir_House(){
GS_text.innerHTML += `<hr>
<hr>`;
}
function funcjs_54_ls(){
GS_text.innerHTML += `<hr>
Desktop
Documents
Downloads
House
Music
Videos
<hr>`;
}
function funcjs_58_cd_House(){
GS_text.innerHTML += `<hr>
<hr>`;
}
function funcjs_60_ls(){
GS_text.innerHTML += `<hr>
<hr>`;
}
function funcjs_66_pwd(){
GS_text.innerHTML += `<hr>
/home/umen/House
<hr>`;
}
function funcjs_76_mkdir_Room(){
GS_text.innerHTML += `<hr>
<hr>`;
}
function funcjs_78_cd_Room(){
GS_text.innerHTML += `<hr>
<hr>`;
}
function funcjs_80_pwd(){
GS_text.innerHTML += `<hr>
/home/umen/House/Room
<hr>`;
}
function funcjs_82_ls(){
GS_text.innerHTML += `<hr>
<hr>`;
}
function funcjs_90_mkdir_bed_closet_desk(){
GS_text.innerHTML += `<hr>
<hr>`;
}
function funcjs_92_ls(){
GS_text.innerHTML += `<hr>
bed  closet  desk
<hr>`;
}
function funcjs_94_rmdir_bed_closet_desk(){
GS_text.innerHTML += `<hr>
<hr>`;
}
function funcjs_101_ls(){
GS_text.innerHTML += `<hr>
virus0  virus1  virus2  virus3  virus4
<hr>`;
}
function funcjs_103_rm_virus0(){
GS_text.innerHTML += `<hr>
<hr>`;
}
function funcjs_105_ls(){
GS_text.innerHTML += `<hr>
virus1  virus2  virus3  virus4
<hr>`;
}
function funcjs_118_pwd(){
GS_text.innerHTML += `<hr>
/home/umen
<hr>`;
}
function funcjs_120_ls(){
GS_text.innerHTML += `<hr>
Desktop
Documents
Downloads
House
Music
Videos
<hr>`;
}
function funcjs_125_rm__HOME_House_Room_virus1(){
GS_text.innerHTML += `<hr>
<hr>`;
}
function funcjs_129_rm__HOME_House_Room_virus1(){
GS_text.innerHTML += `<hr>
rm: cannot remove '/home/umen/House/Room/virus1': No such file or directory	
<hr>`;
}
function funcjs_137_ls__HOME_House_Room_(){
GS_text.innerHTML += `<hr>
virus2  virus3  virus4
<hr>`;
}
function funcjs_141_ls__HOME_House_Room(){
GS_text.innerHTML += `<hr>
virus2  virus3  virus4
<hr>`;
}
function funcjs_150_pwd(){
GS_text.innerHTML += `<hr>
/home/umen
<hr>`;
}
function funcjs_156_cd_House_Room_(){
GS_text.innerHTML += `<hr>
<hr>`;
}
function funcjs_158_ls(){
GS_text.innerHTML += `<hr>
virus1  virus2  virus3  virus4
<hr>`;
}
function funcjs_160_rm_virus2(){
GS_text.innerHTML += `<hr>
<hr>`;
}
function funcjs_175_pwd(){
GS_text.innerHTML += `<hr>
/home/umen/House/Room
<hr>`;
}
function funcjs_179_cd___(){
GS_text.innerHTML += `<hr>
<hr>`;
}
function funcjs_181_pwd(){
GS_text.innerHTML += `<hr>
/home/umen/House
<hr>`;
}
function funcjs_184_rm_Room_virus3(){
GS_text.innerHTML += `<hr>
<hr>`;
}
function funcjs_186_rm__HOME_House_Room_virus4(){
GS_text.innerHTML += `<hr>
<hr>`;
}
async function launchGameScript_chapter_lecture() {

reset_GS();
document.getElementById('toggle_music').style.display='inline';
document.getElementById('toggle_voice').style.display='inline';
document.getElementById('button_print_passwords').style.display='none';
document.getElementById('GS_selects').style.display='none';
document.getElementById('button_start_lecture').style.display='none';
document.getElementById('button_start_quiz').value='Stop Lecture';
document.getElementById('button_start_quiz').onclick = function() { reset_GS(); };
toggle_music();
await new_line(4,"Hello everyone and welcome to the first chapter about 'bash'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(5,"Before learning about our first command, we need to understand the logic behind the organisation of files and folders in Unix-like operating systems, like Linux.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(6,"Let's start to talk about 'directories', also known as 'folders'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
real_tree_1();
await new_line(8,"You can picture the organization of files and folders as a tree.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(9,"In this tree, the folders are shown in sky blue.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(10,"At the bottom of the tree you have the symbol " + code + "/" + reset + " which represents the " + voc + "root directory" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(11,"It is a special folder that will contain ALL the other folders of the system.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
real_tree_2();
await new_line(13,"In this tree, everytime you see a new branch, it represents a new folder.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(14,"This passage to another branch can also be seen in their names with the appearance of an additional symbol '/'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(15,"For example, " + code + "/home/" + reset + " represent the folder 'home' in the " + voc + "root directory" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(16,"" + code + "/home/user/" + reset + " represent the directory 'user', which is in the directory 'home', which is itself in the " + voc + "root directory" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(17,"And so on, like for example : " + code + "/home/user/Images/" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(18,"In this case, 'Images' is in 'user', 'user' is in 'home' and 'home' is in '/'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(19,"But be careful, having a '/' at the end of the last folder isn't mandatory.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(20,"It means that " + learn + "/home/user/" + reset + " is equivalent to " + learn + "/home/user" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(21,"Also, " + learn + "/home/" + reset + " and " + learn + "/home" + reset + " are equivalent.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
real_tree_3();
await new_line(23,"Now let's talk about the files, here in my tree they are in green. In my example, files are 'leaves'. They are connected to a branch, or even sometimes to the trunk itself.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(24,"These files belong to a folder. But here, we have some problems: in red, we can see files that can't exist...");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(25,"" + codeError + "file1" + reset + " can't exist because there is already a file with the same name in the same directory. Here the root directory : " + learn + "/file1" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(26,"But above it, the other file " + codeFile + "/home/file1" + reset + " can exist, because even if their name is the same, they are not directly in the same folder.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(27,"The elements in a Unix-like operating system should have a unique reference : here " + learn + "/file1" + reset + " and " + learn + "/home/file1" + reset + " are not in conflit.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(28,"The file " + codeError + "/home" + reset + " can't exist either, because there is already a folder " + code + "/home/" + reset + ", that is using the same name in the same place.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(29,"For these files to exist, we must give them different names.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
real_tree_4();
await new_line(31,"Here we just have to call the second file : 'file2'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(32,"For " + codeError + "home" + reset + ", we need to give another name that won't be a problem : like for example 'Home'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(33,"Yes ! On Unix, uppercase letters are important. 'Home' and 'home' are two different names.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(34,"When the uppercase letters are considered different from the lowercase letters, we say that the computer system is " + voc + "case sensitive" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(35,"Indeed, Unix-like Operating Systems are " + voc + "case sensitive" + reset + ". It means that 'home', 'Home', 'hOme', 'hoMe', 'homE', 'HoMe', 'hOmE', 'HOme', 'hoME', 'HomE', 'hOMe', 'HOME', etc... are all different and valid names !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
tree_1();
await new_line(37,"It is also possible to represent the same folders this way.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
tree_2();
await new_line(39,"And here is the same example with files. Identical to the tree we saw earlier.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
tree_3();
await new_line(41,"But the structure can also be understood without the tree-like format.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(42,"If all of this isn't obvious for you now, don't worry.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(43,"Now that you understand the logic, with time and repetition, it will soon be easy for you.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(44,"This kind of line, which start with the " + voc + "root directory" + reset + " '/', is called the " + voc + "absolute path" + reset + " of a folder or file.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(45,"It represents with precision, the targeted file or folder.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(46,"Here, it is impossible to have two identical lines.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(47,"This " + voc + "absolute path" + reset + " is the most important concept of the command line.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(48,"Now we can see our first command !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(49,"Let's start by creating a new folder with the command " + learn + "mkdir" + reset + " (This command's name comes from the sentence : " + learn + "m" + reset + "a" + learn + "k" + reset + "e " + learn + "dir" + reset + "ectory).");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(50,"You just have to type 'mkdir', followed by a space and a name for your folder.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(51,"Now let's create the folder 'House', with : " + learn + "mkdir House" + reset + ", and confirm the command by pressing the Return key.");
await interactive(52,"mkdir House");
funcjs_52_mkdir_House();
new_line_no_wait(53,"Let's now display the folders and files, with a simple " + learn + "ls" + reset + " (ls comes from the word : " + learn + "l" + reset + "i" + learn + "s" + reset + "t).");
await interactive(54,"ls");
funcjs_54_ls();
await new_line(55,"You should see the folder you've created.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(56,"Now we can go inside that folder with the command " + learn + "cd" + reset + " (cd comes from " + learn + "c" + reset + "hange " + learn + "d" + reset + "irectory).");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(57,"To do that, we just have to do " + code + "cd" + reset + ", followed by the name of the folder, in our case : " + learn + "cd House" + reset + ".");
await interactive(58,"cd House");
funcjs_58_cd_House();
new_line_no_wait(59,"Now, let's display the files and folders again with a simple " + learn + "ls" + reset + ".");
await interactive(60,"ls");
funcjs_60_ls();
await new_line(61,"Here the directory 'House' is empty, it's normal, because you've just created it.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(62,"But, what about the " + voc + "absolute path" + reset + " I talked about before ?");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(63,"In fact, a terminal is always running in a folder, and can 'move' in the system tree.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(64,"It's exactly what you did with the command " + learn + "cd House" + reset + ", you moved the terminal in the folder 'House'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(65,"To know in which directory your terminal is right now, you just have to type " + learn + "pwd" + reset + " (pwd comes from " + learn + "P" + reset + "rint " + learn + "W" + reset + "orking " + learn + "D" + reset + "irectory).");
await interactive(66,"pwd");
funcjs_66_pwd();
await new_line(67,"The result you see here is the " + voc + "absolute path" + reset + " of the folder you are currently in.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(68,"This folder, where you are right now, has a special name : it's your " + voc + "working directory" + reset + ", also called " + voc + "current directory" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(69,"Like I said before, it is not mandatory to put a '/' for the last folder, that's why you can see here, " + learn + "$(pwd)" + reset + ", without a '/' at the end.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(70,"So here you have 4 fundamental Unix commands : " + learn + "pwd" + reset + ", " + learn + "ls" + reset + ", " + learn + "cd" + reset + " and " + learn + "mkdir" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(71,"" + learn + "pwd" + reset + " and " + learn + "ls" + reset + " are very safe to use, because they just display informations.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(72,"So don't hesitate to use them extensively, as soon as you are in a terminal.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(73,"" + learn + "pwd" + reset + ", to know what is your " + voc + "current directory" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(74,"And " + learn + "ls" + reset + ", to display the content of your " + voc + "current directory" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(75,"Now let's create a new folder, called 'Room', in our " + voc + "current directory" + reset + ", with : " + learn + "mkdir Room" + reset + "");
await interactive(76,"mkdir Room");
funcjs_76_mkdir_Room();
new_line_no_wait(77,"Change your " + voc + "current directory" + reset + " with : " + learn + "cd Room" + reset + "");
await interactive(78,"cd Room");
funcjs_78_cd_Room();
new_line_no_wait(79,"Now, try the command to display the absolute path of your " + voc + "current directory" + reset + " !");
await interactive(80,"pwd");
funcjs_80_pwd();
new_line_no_wait(81,"Awesome, now let's display the elements of your " + voc + "current directory" + reset + " !");
await interactive(82,"ls");
funcjs_82_ls();
await new_line(83,"Here the folder is empty, but you already understand two important commands : " + learn + "pwd" + reset + " and " + learn + "ls" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(84,"The commands " + learn + "cd" + reset + " and " + learn + "mkdir" + reset + " are more complex.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(85,"They need a target or a name, like for example : " + learn + "mkdir Room" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(86,"This 'target' is called an " + voc + "argument" + reset + " !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(87,"But it's also possible to use commands with multiple " + voc + "arguments" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(88,"You just have to separate them with spaces.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(89,"Create the folders 'bed', 'closet' and 'desk' with a single command : " + learn + "mkdir bed closet desk" + reset + "");
await interactive(90,"mkdir bed closet desk");
funcjs_90_mkdir_bed_closet_desk();
new_line_no_wait(91,"Display the elements of the " + voc + "current directory" + reset + ".");
await interactive(92,"ls");
funcjs_92_ls();
new_line_no_wait(93,"Now to delete these folders, you can do : " + learn + "rmdir bed closet desk" + reset + ". (rmdir comes from " + learn + "r" + reset + "e" + learn + "m" + reset + "ove " + learn + "dir" + reset + "ectory)");
await interactive(94,"rmdir bed closet desk");
funcjs_94_rmdir_bed_closet_desk();
await new_line(95,"" + learn + "rmdir" + reset + " is a rather innoffensive command, because it will refuse to delete a folder if it isn't empty.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(96,"That can prevent accidents. If for example, you did " + learn + "rmdir /home" + reset + " by mistake.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(97,"" + learn + "rm" + reset + " is the command to delete files. (rm comes from the word " + learn + "r" + reset + "e" + learn + "m" + reset + "ove)");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(99,"Just like " + learn + "mkdir" + reset + ", you need to give it an " + voc + "argument" + reset + " : the name of the file you want to target, for example : " + learn + "rm test" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(100,"Something strange just happened... Display the content of your " + voc + "working directory" + reset + ".");
await interactive(101,"ls");
funcjs_101_ls();
new_line_no_wait(102,"" + code + "rmdir" + reset + " deleted the folders successfully. But these files have nothing to do here ! Delete the file 'virus1' with : " + learn + "rm virus0" + reset + "");
await interactive(103,"rm virus0");
funcjs_103_rm_virus0();
new_line_no_wait(104,"Display again the elements of the " + voc + "current directory" + reset + ", to see if 'virus0' is still there.");
await interactive(105,"ls");
funcjs_105_ls();
await new_line(106,"Awesome, 'virus0' doesn't exist anymore.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(107,"But be careful with " + learn + "rm" + reset + ", it is a very dangerous command, and you shouldn't take it lightly !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(108,"The files are deleted, they won't go in a recyclebin, so be careful.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(109,"A mistake using command line can be unforgiving.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(110,"A mispell or a wrong " + voc + "current directory" + reset + " can have severe consequences.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(111,"Before confirming a command, be sure of what you are doing.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(112,"Never hesitate to launch and relaunch " + learn + "pwd" + reset + " and " + learn + "ls" + reset + ", to know what is your " + voc + "current directory" + reset + " and check its content.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(113,"But for now we have more 'viruses' to delete. And we can remove them differently.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(114,"We can use their " + voc + "absolute path" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(116,"When you did " + learn + "rm virus0" + reset + ", you've asked for the deletion of the file 'virus0' in your " + voc + "current directory" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(117,"I've just changed your current directory, display it now.");
await interactive(118,"pwd");
funcjs_118_pwd();
new_line_no_wait(119,"Display the content of your " + voc + "current directory" + reset + ".");
await interactive(120,"ls");
funcjs_120_ls();
await new_line(121,"The file 'virus1' still exists in the folder 'Room', but with your " + voc + "current directory" + reset + ", you can't do " + learn + "rm virus1" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(122,"Hopefully, you know the " + voc + "absolute path" + reset + " of the file 'virus1' : " + learn + "" + home + "/House/Room/virus1" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(123,"You can use its " + voc + "absolute path" + reset + " as an argument. And this command will work regardless of your " + voc + "current directory" + reset + " !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(124,"Delete 'virus1' with : " + learn + "rm " + home + "/House/Room/virus1" + reset + ".");
await interactive(125,"rm /home/example/House/Room/virus1");
funcjs_125_rm__HOME_House_Room_virus1();
await new_line(126,"Now, how can we check if the file was deleted ?");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(127,"When a command doesn't go as planned, it will display an error.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(128,"Try to delete the file 'virus1' again with its " + voc + "absolute path" + reset + ".");
await interactive(129,"rm /home/example/House/Room/virus1");
funcjs_129_rm__HOME_House_Room_virus1();
await new_line(130,"Here the command " + learn + "rm" + reset + " is displaying an error, because the file you want to delete doesn't exist.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(131,"We can also use the " + voc + "absolute path" + reset + " of the folder 'Room' to display its content.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(132,"You already know the command " + learn + "ls" + reset + ", to display the content of your " + voc + "current directory" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(133,"Without " + voc + "argument" + reset + ", with a simple " + learn + "ls" + reset + ", the targetted folder will be the " + voc + "current directory" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(134,"But it is also possible to give an " + voc + "argument" + reset + " to " + learn + "ls" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(135,"This " + voc + "argument" + reset + " is the targeted folder, for example " + learn + "ls /" + reset + ", will display the content of the " + voc + "root directory" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(136,"We can display the content of the folder 'Room', without having to move in this directory first, with : " + learn + "ls " + home + "/House/Room/" + reset + ".");
await interactive(137,"ls /home/example/House/Room/");
funcjs_137_ls__HOME_House_Room_();
await new_line(138,"Excellent, the file 'virus1' no longer exists.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(139,"Once again, I want to remind you that in an " + voc + "absolute path" + reset + ", if the last character is '/', it's not mandatory.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(140,"So here the last '/' in " + learn + "" + home + "/House/Room/" + reset + " isn't mandatory. Test with this command : " + learn + "ls " + home + "/House/Room" + reset + "");
await interactive(141,"ls /home/example/House/Room");
funcjs_141_ls__HOME_House_Room();
await new_line(142,"No problem there, the result is identical for both commands : " + learn + "ls " + home + "/House/Room/" + reset + " and " + learn + "ls " + home + "/House/Room" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(143,"When you did " + learn + "rm virus0" + reset + " for the first deletion, you used what's called the " + voc + "relative path" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(144,"We say that this path is 'relative' because it depends on your " + voc + "working directory" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(145,"Let's imagine two 'virus' files : with their " + voc + "absolute path" + reset + " being : " + learn + "/virus" + reset + " and " + learn + "/bin/virus" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(146,"If " + learn + "pwd" + reset + " is displaying " + learn + "" + home + "" + reset + ". A " + learn + "rm virus" + reset + " won't delete any of them, but would try to remove the file " + learn + "" + home + "/virus" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(148,"This is why this " + voc + "absolute path" + reset + " is very important. You can do " + learn + "rm /virus" + reset + ", or " + learn + "rm /bin/virus" + reset + ", and it will work whatever your " + voc + "current directory" + reset + " is.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(149,"I just changed your " + voc + "current directory" + reset + ", display it.");
await interactive(150,"pwd");
funcjs_150_pwd();
await new_line(151,"To change your " + voc + "current directory" + reset + ", you can use the command " + learn + "cd" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(152,"To go back in the folder 'Room', you can use its " + voc + "absolute path" + reset + " : " + learn + "cd " + home + "/House/Room/" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(153,"But you can also do the same thing using its " + voc + "relative path" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(154,"You want to move in " + learn + "" + home + "/House/Room/" + reset + ", and you already are in " + learn + "" + home + "" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(155,"It is therefore possible to move from where you are now, with : " + learn + "cd House/Room/" + reset + ". Go ahead, try it.");
await interactive(156,"cd House/Room/");
funcjs_156_cd_House_Room_();
new_line_no_wait(157,"Display the elements of your " + voc + "working directory" + reset + ".");
await interactive(158,"ls");
funcjs_158_ls();
new_line_no_wait(159,"Here you can still see some 'virus' files. Delete the file 'virus2' using its " + voc + "relative path" + reset + ".");
await interactive(160,"rm virus2");
funcjs_160_rm_virus2();
await new_line(161,"Excellent!");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(162,"In the last example, we saw that " + learn + "cd House/Room/" + reset + " is using a " + voc + "relative path" + reset + ", but this path still contains several '/'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(163,"So how can we know if a path is an " + voc + "absolute path" + reset + " or a " + voc + "relative path" + reset + " ?");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(164,"The " + voc + "absolute path" + reset + " is in fact very easy to recognize !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(165,"It always starts at the root directory, it means that the first character of an " + voc + "absolute path" + reset + " is always a '/'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(166,"There is also a very useful syntax you can use with the " + voc + "relative path" + reset + " : " + learn + ".." + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(167,"" + learn + ".." + reset + " represents the parent folder of your " + voc + "current directory" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(168,"It is the vocabulary we will use to talk about this tree, they have child / parent relationships.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(169,"For example, for " + learn + "/home/user/test/" + reset + ", the parent folder of 'test' is 'user', and the parent of 'user' is 'home'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(170,"And of course, 'test' is a child of 'user', and 'user' is a child of 'home'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(171,"Targetting children in " + voc + "argument" + reset + " with their " + voc + "relative path" + reset + " is very simple, you just have to write the names of their successive parents.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(172,"Like for example with the command we used before : " + learn + "cd House/Room/" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(173,"To target parents, it's a little more complicated. We have to use these " + learn + ".." + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(174,"Display the absolute path of you current directory.");
await interactive(175,"pwd");
funcjs_175_pwd();
await new_line(176,"You already know the command to change your current directory : " + learn + "cd" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(177,"Here we want to move in the parent folder. We are in " + learn + "" + home + "/House/Room/" + reset + " and we want to go in " + learn + "" + home + "/House/" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(178,"It is possible to go up one branch in the tree, or like i said before to move in the parent folder with : " + learn + "cd .." + reset + "");
await interactive(179,"cd ..");
funcjs_179_cd___();
new_line_no_wait(180,"Display the absolute path of the current directory.");
await interactive(181,"pwd");
funcjs_181_pwd();
await new_line(182,"I hope that the result of " + learn + "pwd" + reset + " makes sense for you.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(183,"But we have two more viruses to get rid of, delete 'virus3' with its " + voc + "relative path" + reset + ".");
await interactive(184,"rm Room/virus3");
funcjs_184_rm_Room_virus3();
new_line_no_wait(185,"Good ! Now delete the file 'virus4' with its " + voc + "absolute path" + reset + ".");
await interactive(186,"rm /home/example/House/Room/virus4");
funcjs_186_rm__HOME_House_Room_virus4();
await new_line(187,"Amazing, you got it ! Try to confirm your knowledge with the quiz now.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
launchGameScript_chapter_quiz();
}
async function launchGameScript_chapter_quiz() {
reset_GS();
intro_quiz_message();
document.getElementById('button_print_passwords').style.display='none';
document.getElementById('GS_selects').style.display='none';
document.getElementById('toggle_music_quiz').style.display='inline';
document.getElementById('button_start_quiz').style.display='none';
document.getElementById('button_start_lecture').value='Stop Quiz';
document.getElementById('button_start_lecture').onclick = function() { reset_GS(); }
toggle_music_quiz();
GOOD=1;
if(GOOD){ GOOD=await quiz("1","Quel symbole représente le répertoire racine sur Linux ?","/"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("2","Quelle commande affiche le chemin absolu du répertoire courant ?","pwd"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("3","Quelle commande affiche le contenu du répertoire racine ?","ls /"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("4","Quelle commande change le répertoire courant du terminal par son répertoire parent ?","cd .."); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("5","Quelle commande affiche le contenu du répertoire courant ?","ls"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("6","Quelle commande supprime le dossier vide 'test' du répertoire courant ?","rmdir test"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("7","Par quel symbole commence le chemin absolu d'un fichier ?","/"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("8","Le nom du chemin relatif d'un fichier est souvent plus court que son équivalent en chemin absolu. (vrai/faux)","vrai"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("9","Quelle commande peut supprimer le fichier /home/test quel que soit votre répertoire courant ?","rm /home/test"); } else { error_quiz_message(); return; }
P1="24d8";
P2="f016";
await ask_username(P1,P2,WHOAMI,SUBJECT,CHAPTER);
}
LINES=187
setTimeout(function(){ download_audio_chapter(WHOAMI,'en','classic','bash','m1','1'); }, 2000);
if(VIDEO) download_video_chapter(WHOAMI,'en','classic','bash','m1','1');
