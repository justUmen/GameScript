function funcjs_10_read_NAME(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_12_echo___NAME(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_17_cat_CODE(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_19_bash_CODE(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_29_cat_if1(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_46___1__eq_2___echo____(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_55_if_ls_then_echo_GOOD_fi(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_58_if_true_then_echo_vrai_else_echo_faux_fi(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_61_if_true_then_echo_vrai_fi(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_72_cat_if1(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_74_bash_if1(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_76_bash_if1(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_79_cat_if2(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_83_cat_if3(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_89_cat_if4(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_102_cat_if5(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_106_cat_if6(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_109_cat_if7(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_144_bash_if7(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_148_cat_if8(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_151_bash_if8(){
GS_text.innerHTML += `<hr>
<hr>`;}
async function launchGameScript_chapter_lecture() {

reset_GS();
document.getElementById('toggle_music').style.display='inline';
document.getElementById('toggle_voice').style.display='inline';
document.getElementById('button_print_passwords').style.display='none';
document.getElementById('GS_selects').style.display='none';
document.getElementById('button_start_lecture').style.display='none';
document.getElementById('button_start_quiz').value='Stop Lecture';
document.getElementById('button_start_quiz').onclick = function() { reset_GS(); };
toggle_music();
await new_line(5,"Avec 'bash', il par exemple possible de demander une valeur à l'utilisateur, pour donner à votre script une certaine interactivité.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(6,"Pour cela il faudra utiliser la commande " + code + "read" + reset + ", qui prendra en argument le nom de la variable où sera stocké la valeur donnée.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(7,"Pour demander la valeur de la variable NAME à l'utilisateur, il suffira de faire " + learn + "read NAME" + reset + " (l'anglais de lire)");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(8,"" + code + "read" + reset + " attendra qu'une valeur soit donnée et que la touche Entrée soit pressée pour continuer.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(9,"Essayez donc de demander la valeur de la variable 'NAME' avec " + learn + "read NAME" + reset + ", donnez lui une valeur quelconque, puis validez avec la touche entrée.");
await interactive(10,"read NAME");
funcjs_10_read_NAME();
new_line_no_wait(11,"Affichez maintenant la valeur de la variable 'NAME'.");
await interactive(12,"echo \$NAME");
funcjs_12_echo___NAME();
await new_line(13,"Nous avons déjà vu que pour créer un script bash, il suffisait d'écrire les commandes que vous voulez exécuter dans un fichier texte.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(14,"Les commandes seront alors lancés les unes après les autres lorsque vous donnez ce fichier en argument à la commande 'bash'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(15,"Si la commande " + code + "read" + reset + " est utilisée dans un script, elle mettra ce script en pause tant qu'elle n'aura pas reçu une valeur pour sa variable.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(16,"Affichez donc le contenu du fichier 'CODE'.");
await interactive(17,"cat CODE");
funcjs_17_cat_CODE();
new_line_no_wait(18,"Faites maintenant : " + learn + "bash CODE" + reset + ", il vous faudra donner une valeur à 'void' pour continuer.");
await interactive(19,"bash CODE");
funcjs_19_bash_CODE();
await new_line(20,"Ici vous voyez bien que la première commande " + learn + "echo -n void=" + reset + " se lance avant la commande read, mais que la deuxième commande " + learn + "echo \$void" + reset + " attendra la fin de la commande " + code + "read" + reset + " avant de se lancer.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(21,"A chaque fois que GameScript vous demande de taper quelque chose après ce \e[97;45m # \e[0m, c'est en fait cette commande " + code + "read" + reset + " qui est utilisée !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(22,"Mais Bash est aussi capable de créer des scripts plus complexes qu'une simple succession de commande.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(23,"Par exemple, lorque Gamescript vous demande de taper quelque chose, il vérifie si le contenu que vous avez tapé correspond à la commande qui vous a été demandé.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(24,"Si vous faites une erreur ou une faute de frappe, GameScript ne vous laissera pas continuer.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(25,"Pour avoir cet effet, un script bash utilise des " + voc + "conditions" + reset + ", avec une combinaison de plusieurs commandes : " + code + "if" + reset + ", " + code + "then" + reset + ", " + code + "else" + reset + " et " + code + "fi" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(26,"Avec ces " + voc + "conditions" + reset + ", il est possible de contrôler avec précision le comportement de votre script.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(27,"GameScript utilise régulièrement cette combinaison " + code + "if{reset}/" + code + "then{reset}/" + code + "else{reset}/" + code + "fi" + reset + " pour décider quelles commandes doivent être lancées et quelles commandes ne doivent pas l'être.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(28,"Voyons notre premier exemple, affichez le contenu du fichier 'if1'.");
await interactive(29,"cat if1");
funcjs_29_cat_if1();
await new_line(30,"Ici nous avons un exemple de l'utilisation de la commande " + code + "if" + reset + " (l'anglais du mot 'si') en combinaison avec " + code + "else" + reset + " (l'anglais de 'sinon').");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(31,"Ce script demandera à l'utilisateur la valeur de la variable 'X', si cette valeur est 1, le script affichera 'COURS', si cette valeur n'est pas 1, le script affichera 'QUESTIONNAIRE'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(32,"Ce mot clef " + code + "if" + reset + " annonce l'ouverture d'une condition, qui devra avoir le " + voc + "test logique" + reset + " voulu en argument.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(33,"Il faudra ensuite utiliser le mot clef " + code + "then" + reset + ", pour définir l'emplacement du début du code à exécuter si cette condition est valide.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(34,"Cette condition commence à " + code + "if" + reset + " mais vous devez également définir où elle se termine en utilisant le mot clef " + code + "fi" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(35,"Vous pouvez lire cette combinaison " + code + "if" + reset + "/" + code + "then" + reset + "/" + code + "else" + reset + "/" + code + "fi" + reset + " comme 'si/faire/sinon faire/fin'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(36,"Le code " + code + "[ \$X -eq 1 ]" + reset + " est un " + voc + "test logique" + reset + " que vous pouvez lire comme 'X est égal à 1'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(37,"Finalement vous pouvez lire le code " + learn + "if [ \$X -eq 1 ];then echo COURS;else echo QUESTIONNAIRE;fi" + reset + " comme : 'si X est égal à 1, faire afficher COURS, sinon faire afficher QUESTIONNAIRE, fin du si'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(38,"Comme d'habitude, les " + code + ";" + reset + " peuvent être remplacées par des mises à la lignes, mais attention car tous les espaces que vous voyez dans cet exemple sont indispensables !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(39,"Par exemple, il y a un espace entre " + code + "if" + reset + " et le code entre [].");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(40,"Vous pouvez tout simplement voir " + code + "if" + reset + " comme une commande qui prend ce code en argument.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(41,"Bien évidemment un espace est indispensable pour séparer une commande de son argument.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(42,"L'argument d'un " + code + "if" + reset + " peut être soit " + learn + "true" + reset + " (vrai) soit " + learn + "false" + reset + " (faux).");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(43,"C'est en fait ce que renvoit le code que vous voyez ici " + code + "[ \$X -eq 1 ]" + reset + ", c'est un " + voc + "test logique" + reset + " qui renverra " + learn + "true" + reset + " si la variable X est égal à 1, et " + learn + "false" + reset + " si ça n'est pas le cas.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(44,"Vous pouvez également utiliser la variable " + code + "\$?" + reset + " que nous avons déjà vu.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(45,"Testez donc si 1 est égal à 2 avec : " + learn + "[ 1 -eq 2 ];echo \$?" + reset + "");
await interactive(46,"[ 1 -eq 2 ];echo \$?");
funcjs_46___1__eq_2___echo____();
await new_line(47,"Si donné en argument à if, 0 devient " + learn + "true" + reset + " et tout autre nombre devient " + learn + "false" + reset + ". Ici ce 1 deviendra donc " + learn + "false" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(48,"Ce " + code + "-eq" + reset + " permet de comparer si deux nombres sont équivalents. (de l'anglais EQual : égal)");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(49,"Vous pouvez en utilisez d'autres, comme " + code + "-lt" + reset + " (Less Than / moins que), " + code + "-gt" + reset + " (Greater Than / plus grand que), " + code + "-ge" + reset + " (Greater or Equal / plus grand ou égal), " + code + "-le" + reset + " (Less or Equal / moins ou égal) et " + code + "-ne" + reset + " (Not Equal / pas égal).");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(50,"Par exemple, si X=1, le code " + code + "[ \$X -eq 1 ]" + reset + " renverra " + learn + "true" + reset + ", " + code + "[ 1 -lt 2 ]" + reset + " renverra " + learn + "true" + reset + " et " + code + "[ 2 -gt 22 ]" + reset + " renverra " + learn + "false" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(51,"" + code + "[ 1 -eq 1 ]" + reset + " renverra " + learn + "true" + reset + " (\$? = 0) si 1 est égal à 1, ce qui sera bien évidemment toujours le cas.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(52,"C'est pourquoi vous pouvez aussi utiliser cette syntaxe que vous connaissez déjà : " + learn + "[ 1 -eq 1 ] && echo GOOD" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(53,"N'importe quelle commande en argument de " + code + "if" + reset + " peut également fonctionner.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(54,"Testez donc cette commande, qui affiche 'GOOD' si la commande donnée en argument est un succès : " + learn + "if ls;then echo GOOD;fi" + reset + "");
await interactive(55,"if ls;then echo GOOD;fi");
funcjs_55_if_ls_then_echo_GOOD_fi();
await new_line(56,"" + code + "ls" + reset + " renvoit " + learn + "true" + reset + " à " + code + "if" + reset + " car la commande est un succès. Autrement dit " + code + "\$?" + reset + " est égal à 0.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(57,"Essayez donc de faire : " + learn + "if true;then echo vrai;else echo faux;fi" + reset + "");
await interactive(58,"if true;then echo vrai;else echo faux;fi");
funcjs_58_if_true_then_echo_vrai_else_echo_faux_fi();
await new_line(59,"Si vous n'en avez pas besoin, le " + code + "else" + reset + " dans votre script n'est pas obligatoire.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(60,"Essayez donc de faire : " + learn + "if true;then echo vrai;fi" + reset + "");
await interactive(61,"if true;then echo vrai;fi");
funcjs_61_if_true_then_echo_vrai_fi();
await new_line(62,"Dans cet exemple, tous les espaces et les " + code + ";" + reset + " sont indispensables, faites donc bien attention à ne pas en oublier.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(63,"" + learn + "if" + codeFile + " " + learn + "true;then echo vrai;fi" + reset + " : Cet espace en vert entre " + code + "if" + reset + " et son argument est " + voc + "important" + reset + ", c'est pourquoi " + code + "if [ \$X -gt 5 ]" + reset + " est correct mais " + codeError + "if[ \$X -gt 5 ]" + reset + " ne l'est pas.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(64,"" + learn + "if true" + codeFile + ";" + learn + "then echo vrai;fi" + reset + " : La commande " + code + "if" + reset + " et son argument doivent aussi être séparés du reste, c'est pourquoi il faudra utiliser un " + code + ";" + reset + " ou une mise à la ligne.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(65,"" + learn + "if true;" + codeFile + "then echo vrai;" + learn + "fi" + reset + " : Pour être valide, un " + code + "if" + reset + " doit contenir le mot clef 'then', suivi d'un espace, suivi d'au moins une commande et d'un " + code + ";" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(66,"" + learn + "if true;then echo vrai;" + codeFile + "fi" + reset + " : Il doit aussi se terminer par un " + code + "fi" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(68,"La présentation est bien évidemment flexible, ces espaces et " + code + ";" + reset + " peuvent être remplacés par des mises à la lignes comme vous le voyez dans le code ci-dessus.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(69,"Mais revenons sur un exemple complet 'if/then/else/fi' : " + code + "if true;then echo vrai;else echo faux;fi" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(70,"Ici, quel que soit la situation, il est important de comprendre que seul l'" + voc + "une" + reset + " de ces commandes " + code + "echo" + reset + " se lancera, " + voc + "jamais" + reset + " les deux.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(71,"Revenons maintenant sur notre premier exemple, réaffichez le contenu du fichier 'if1'.");
await interactive(72,"cat if1");
funcjs_72_cat_if1();
new_line_no_wait(73,"Puis lancez ce script avec : " + learn + "bash if1" + reset + ", puis donnez à X la valeur 1 en tapant simplement 1 et validez avec la touche entrée.");
await interactive(74,"bash if1");
funcjs_74_bash_if1();
new_line_no_wait(75,"Lancez à nouveau ce script avec : " + learn + "bash if1" + reset + ", et donnez à X une valeur numérique différente de 1.");
await interactive(76,"bash if1");
funcjs_76_bash_if1();
await new_line(77,"Maintenant vous devriez comprendre comment cette syntaxe fonctionne.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(78,"Affichez maintenant le contenu du fichier 'if2'.");
await interactive(79,"cat if2");
funcjs_79_cat_if2();
await new_line(80,"Le code du script 'if2' est équivalent au code du script 'if1', seul la présentation du code est différente.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(81,"Ici les " + code + ";" + reset + " ont été remplacés par des mises à la ligne.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(82,"Affichez donc le contenu du fichier 'if3'.");
await interactive(83,"cat if3");
funcjs_83_cat_if3();
await new_line(84,"Comme pour les commandes, les espaces peuvent être utilisés pour présenter votre code différemment, par exemple pour le rendre plus lisible.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(85,"Traditionnelement, des tabulations ou plusieurs espaces sont ajoutés au début d'une ligne quand le code est d'un autre niveau.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(86,"On appelle cette présentation un style d'indentation, l'" + voc + "indentation" + reset + " étant ce décalage en début de ligne avant le code " + code + "echo COURS" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(87,"Avec l'exemple de 'if3', il est très facile de voir le " + voc + "bloc de code" + reset + " à l'intérieur du " + code + "if" + reset + " et celui à l'intérieur du " + code + "else" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(88,"Affichez donc le contenu du fichier 'if4'.");
await interactive(89,"cat if4");
funcjs_89_cat_if4();
await new_line(90,"Après ce " + code + "fi" + reset + " le script continuera à s'exécuter normalement ligne par ligne.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(91,"C'est à dire qu'ici, quel que soit la valeur donnée à 'X' la commande " + code + "echo TEXTE" + reset + " se lancera.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(92,"L'absence d'espaces en début de ligne nous permet de rapidement comprendre que cette ligne de code n'est pas dépendant d'un " + code + "if" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(93,"Mais attention, ces " + voc + "indentations" + reset + " ne sont pas obligatoires : c'est un choix esthétique qui revient au créateur du script.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(94,"Je vous recommande cependant d'utiliser ce " + voc + "style d'indentation" + reset + " pour que votre script soit plus facilement compréhensible.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(95,"Nous avons donc vu que le code " + code + "[ \$X -eq 5 ]" + reset + " est capable de vérifier si 'X' est égal à la valeur 5. (anglais " + code + "eq" + reset + "ual)");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(96,"Mais vous pouvez aussi vérifier si 'X' n'est " + voc + "pas" + reset + " égal à la valeur 5 avec : " + code + "[ \$X -ne 5 ]" + reset + " (anglais " + code + "n" + reset + "ot " + code + "e" + reset + "qual)");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(97,"Vérifier si 'X' est supérieur à 5 avec : " + code + "[ \$X -gt 5 ]" + reset + " (anglais " + code + "g" + reset + "reater " + code + "t" + reset + "han)");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(98,"Vérifier si 'X' est inférieur à 5 avec : " + code + "[ \$X -lt 5 ]" + reset + " (anglais " + code + "l" + reset + "esser " + code + "t" + reset + "han)");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(99,"Ce code entre '[ ]' contiendra la logique qui sera donné à if.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(100,"Mais ce code peut aussi être utilisé comme une commande avec une syntaxe que nous avons déjà vu.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(101,"Affichez donc le contenu du fichier 'if5'.");
await interactive(102,"cat if5");
funcjs_102_cat_if5();
await new_line(103,"Cette syntaxe est identique au traditionnel 'if/then/else/fi', mais sa lisibilité est assez réduite, je vous déconseille donc de l'utiliser dans un script lorsque les conditions deviennent complexes.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(104,"Voyons donc maintenant un exemple contenant " + voc + "plusieurs niveaux de conditions" + reset + " : des if dans d'autres if.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(105,"Affichez donc le contenu du fichier 'if6'.");
await interactive(106,"cat if6");
funcjs_106_cat_if6();
await new_line(107,"Ce code est en fait très simple, mais le manque d'indentation le rend impossible à lire.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(108,"Voyons le même code avec une indentation propre, affichez donc le contenu du fichier 'if7'.");
await interactive(109,"cat if7");
funcjs_109_cat_if7();
await new_line(110,"Ici avec ce genre de présentation, il est très facile de voir quelles commandes appartiennent à quel " + code + "if" + reset + ", quel " + code + "else" + reset + " correspond à quel " + code + "if" + reset + " et quel sont les " + code + "if" + reset + " à l'intérieur d'autres " + code + "if" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(111,"A chaque passage dans un nouveau " + code + "if" + reset + " vous pouvez voir ici une tabulation de plus avant le début de la commande.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(112,"Au contraire, à chaque fois qu'un " + code + "if" + reset + " se termine avec un " + code + "fi" + reset + ", il y a une tabulation de moins.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(113,"Maintenant que ce code est plus lisible, nous allons le lire et le comprendre ensemble.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(114,"Pour cela nous allons nous comporter comme le ferait 'bash', en lisant et interprétant les commandes ligne par ligne.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(116,"- Tout d'abord, une variable nommé X sera créé et contiendra la valeur 11.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(118,"- Ensuite nous avons notre première condition.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(120,"- Si celle-ci est correcte nous entrerons dans le code du 'then' correspondant.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(122,"- Si cette condition est incorrecte, nous entrerons dans le 'else' correspondant à ce premier 'if'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(124,"- Ici X étant égal à 11, nous rentrons dans le 'if' car 11 est un nombre plus grand que 5.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(126,"- Dans notre cas avec X=11, ce code ne sera donc pas utilisé.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(128,"- Dans ce 'if' nous avons notre première commande qui sera executée : " + code + "echo h" + reset + ", qui affichera la lettre h.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(130,"- Puis nous avons une nouvelle condition sur la valeur de X : si X est inférieur à 10.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(132,"- X étant égal à 11, et 11 n'étant pas inférieur à 10, nous ignorerons le contenu de ce 'if'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(134,"- Et nous irons dans le contenu du 'else' correspondant à ce 'if'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(136,"- Notre deuxième commande est donc : " + code + "echo e" + reset + ", qui affichera la lettre e.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(138,"- Puis nous avons un nouvelle condition : si X est inférieur à 11.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(140,"- X n'étant pas inférieur à 11, puisqu'il est égal à 11, nous irons dans le 'else' correspondant, et nous affichons notre troisième lettre avec " + code + "echo y" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(142,"- Au final, avec X égal à 11, voilà les trois commandes qui seront exécutés.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(143,"Vous pouvez maintenant lancer ce script avec : " + learn + "bash if7" + reset + ".");
await interactive(144,"bash if7");
funcjs_144_bash_if7();
await new_line(145,"Bash affiche bien ce que nous avions prévu : h, puis e, puis y.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(146,"Bien évidemment, lorsque la valeur de X n'est pas 11, le même code n'affichera pas la même chose.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(147,"Affichez donc le contenu du fichier 'if8'.");
await interactive(148,"cat if8");
funcjs_148_cat_if8();
await new_line(149,"Ici le code est identique, seul la valeur de X a changé, essayez de lire ce code et trouvez ce qu'il affichera avant de continuer.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(150,"Si vous pensez avoir la bonne réponse, lancez ce script pour vérifier : " + learn + "bash if8" + reset + ".");
await interactive(151,"bash if8");
funcjs_151_bash_if8();
await new_line(152,"Lorsque vous voyez ces [], il s'agit en fait de la syntaxe secondaire de la commande " + code + "test" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(153,"Par exemple, " + code + "[ 1 -eq 2 ]" + reset + " est en fait équivalent à " + code + "test 1 -eq 2" + reset + " !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(154,"N'hésitez donc pas à voir plus de détails sur ces " + voc + "tests logiques" + reset + " avec un : " + code + "man test" + reset + " !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(155,"En avant pour le questionnaire !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
launchGameScript_chapter_quiz();
}
async function launchGameScript_chapter_quiz() {
reset_GS();
intro_quiz_message();
document.getElementById('button_print_passwords').style.display='none';
document.getElementById('GS_selects').style.display='none';
document.getElementById('toggle_music_quiz').style.display='inline';
document.getElementById('button_start_quiz').style.display='none';
document.getElementById('button_start_lecture').value='Stop Quiz';
document.getElementById('button_start_lecture').onclick = function() { reset_GS(); }
toggle_music_quiz();
GOOD=1;
if(GOOD){ GOOD=await quiz("1","Par quel mot clef doit se terminer une condition 'if' ?","fi"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("2","Quel argument pouvez-vous donner à 'if' qui garantira l'exécution du contenu dans son 'else' correspondant ?","false"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("3","Comment demander la valeur de la variable 'nom' à l'utilisateur ?","read nom"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("4","En utilisant 'if', un seul '[' et un seul ']', comment afficher le mot 'oui' si la valeur de X est plus grande que 2 ?","if [ $X -gt 2 ];then echo oui;fi"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("5","Sans utiliser de 'if' et en utilisant qu'un seul '[' et qu'un seul ']', comment afficher le mot 'oui' si la valeur de X est plus petite que 2 ?","[ $X -lt 2 ]&&echo oui"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("6","Sans utiliser de 'if' ou de '[', comment afficher le mot 'oui' si la valeur de X est égal à 2 ?","test $X -eq 2&&echo oui"); } else { error_quiz_message(); return; }
P1="2211";
P2="ddfb";
await ask_username(P1,P2,WHOAMI,SUBJECT,CHAPTER);
}
LINES=155
setTimeout(function(){ download_audio_chapter(WHOAMI,'fr','classic','bash','m1','11'); }, 2000);
if(VIDEO) download_video_chapter(WHOAMI,'fr','classic','bash','m1','11');
