function funcjs_9_lss_file(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_11_cat_file(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_25_pwd1_file(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_33_ls_a(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_42_pwd_1_file(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_44_cat_file(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_49_pwd_2_error(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_53_cat_error(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_57_pwdd_2_error(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_61_cat_error(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_64_pwd_1_out_2_err(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_66_cat_err(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_74_pwdd__pwd_1__f_2__e(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_84_pwdd_1__f_2__e__pwd_1__f_2__e(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_90__pwdd__pwd_1__f_2__e(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_92_cat_e(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_95_cat_FICHIER__echo_GOOD__echo_ERROR(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_98_echo_GOOD__echo_ERROR(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_115_pwd___f(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_118_pwdd___f(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_125_cat_X_2__dev_null(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_127_cat__dev_null(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_133_pwd___tmp_pwd_log_2__1(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_135_cat__tmp_pwd_log(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_137_pwdd___tmp_pwd_log_2__1(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_139_cat__tmp_pwd_log(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_146__pwdd_pwd_(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_167__pwdd_pwd____dev_null(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_170__pwdd_pwd___F(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_172_cat_F(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_175__pwdd_pwd___F(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_177_cat_F(){
GS_text.innerHTML += `<hr>
<hr>`;}
async function launchGameScript_chapter_lecture() {

reset_GS();
document.getElementById('toggle_music').style.display='inline';
document.getElementById('toggle_voice').style.display='inline';
document.getElementById('button_print_passwords').style.display='none';
document.getElementById('GS_selects').style.display='none';
document.getElementById('button_start_lecture').style.display='none';
document.getElementById('button_start_quiz').value='Stop Lecture';
document.getElementById('button_start_quiz').onclick = function() { reset_GS(); };
toggle_music();
await new_line(4,"Nous avons déjà vu dans les chapitres précédents comment utiliser le symbole " + code + ">" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(5,"Ce symbole nous permet de rediriger le résultat d'une commande vers un fichier, comme par exemple " + learn + "ls>file" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(6,"Le fichier 'file' sera créé s'il n'existe pas et contiendra le résultat de la commande " + learn + "ls" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(7,"Avec le symbole " + code + ">" + reset + " le résultat de la commande à sa gauche ne s'affiche plus dans le terminal.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(8,"Commencez par cette commande avec une faute de frappe : " + learn + "lss>file" + reset + "");
await interactive(9,"lss>file");
funcjs_9_lss_file();
new_line_no_wait(10,"Maintenant affichez le contenu de 'file'.");
await interactive(11,"cat file");
funcjs_11_cat_file();
await new_line(12,"Ici, la commande " + learn + "lss>file" + reset + " nous affiche une erreur dans le terminal et le fichier 'file' est vide.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(13,"On aurait pu penser qu'avec la commande " + learn + "lss>file" + reset + ", que le message d'erreur serait dans le fichier 'file'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(15,"Et bien non ! Lorsqu'une commande s'exécute, il y en en fait " + voc + "deux" + reset + " flux de sortie indépendants.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(16,"Le premier flux est celui que nous avons déjà redirigé avec le " + code + ">" + reset + ", il s'agit de la " + voc + "sortie standard" + reset + ". (en anglais stdout ou standard output)");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(18,"Les erreurs utilisent un autre flux de sortie, qui s'appelle la " + voc + "sortie erreur standard" + reset + ". (en anglais stderr ou standard error)");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(19,"Ayant deux flux différents, il est par exemple possible de rediriger les résultats d'un coté, et les erreurs de l'autre.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(20,"Par défaut, sans l'utilisation des redirections, un terminal affiche les deux flux au même endroit.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(21,"Pour rediriger la " + voc + "sortie standard" + reset + ", il faudra utiliser " + code + "1>" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(23,"" + code + ">" + reset + " est en fait une abréviation de " + code + "1>" + reset + ". Les deux sont équivalents et redirigent la " + voc + "sortie standard" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(24,"Faites donc un " + learn + "pwd1>file" + reset + "");
await interactive(25,"pwd1>file");
funcjs_25_pwd1_file();
await new_line(26,"Ici nous avons un problème parce que le terminal considère que la commande complète n'est pas " + code + "pwd" + reset + ", mais " + code + "pwd1" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(27,"Nous avons déjà vu dans le chapitre 3 que la commande " + learn + "echo a  b" + reset + " était équivalente à " + learn + "echo a b" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(28,"" + code + "echo" + reset + " considère que le premier argument est 'a' et que le deuxième est 'b'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(29,"Mais cette logique s'applique à toutes les commandes. Il est en fait possible d'ajouter des espaces à volonté.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(30,"Par exemple, " + learn + "ls -a" + reset + " est équivalent " + learn + "ls          -a" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(31,"L'option '-a' a besoin " + voc + "d'au moins un espace" + reset + " pour qu'elle puisse être interprétée comme une option.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(32,"Faites donc un " + learn + "ls-a" + reset + "");
await interactive(33,"ls-a");
funcjs_33_ls_a();
await new_line(34,"Ici " + learn + "ls-a" + reset + " provoque tout simplement le lancement d'une commande inconnue sans option.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(35,"Parfois cet espace n'est pas nécessaire, comme avec les symboles spéciaux : " + code + ">" + reset + ", " + code + "&" + reset + ", " + code + "|" + reset + ", etc...");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(36,"Un symbole spécial ne sera pas considéré comme appartenant au nom de la commande ou du fichier, sauf s'il est précédé du caractère d'échappement.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(37,"Mais la commande " + learn + "pwd>file" + reset + " peut tout aussi bien s'écrire " + learn + "pwd > file" + reset + " ou encore " + learn + "pwd  >  file" + reset + " ou encore " + learn + "pwd>   file" + reset + ", etc..");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(38,"Ceci étant dit, revenons sur notre problème avec " + learn + "pwd1>file" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(39,"Le chiffre '1' n'étant pas un caractère spécial, votre terminal considère que la commande complète est " + learn + "pwd1" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(40,"Il faudra donc ici séparer " + code + "1>" + reset + " de " + code + "pwd" + reset + " par un espace.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(41,"Faites donc un " + learn + "pwd 1>file" + reset + "");
await interactive(42,"pwd 1>file");
funcjs_42_pwd_1_file();
new_line_no_wait(43,"Affichez le contenu du fichier 'file'.");
await interactive(44,"cat file");
funcjs_44_cat_file();
await new_line(45,"" + learn + "pwd 1>file" + reset + " est donc bien équivalent à " + learn + "pwd>file" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(47,"Pour rediriger la " + voc + "sortie erreur standard" + reset + ", il faudra tout simplement utiliser " + code + "2>" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(48,"Faites donc un " + learn + "pwd 2>error" + reset + "");
await interactive(49,"pwd 2>error");
funcjs_49_pwd_2_error();
await new_line(50,"Ici le résultat de la commande s'affiche dans le terminal.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(51,"Normal puisque qu'avec cette commande nous n'avons pas de redirection de la sortie standard.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(52,"Affichez maintenant le contenu du fichier 'error'.");
await interactive(53,"cat error");
funcjs_53_cat_error();
await new_line(54,"Le fichier est vide car aucun message n'a été envoyé sur le flux " + voc + "d'erreur standard" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(55,"Mais vous pouvez noter que le fichier a bien été créé.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(56,"Maintenant faites donc la même commande avec une faute de frappe : " + learn + "pwdd 2>error" + reset + "");
await interactive(57,"pwdd 2>error");
funcjs_57_pwdd_2_error();
await new_line(58,"Ici rien ne s'affiche dans le terminal.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(59,"Normal encore une fois, puisque rien n'a été envoyé sur la " + voc + "sortie standard" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(60,"Affichez par contre le contenu du fichier 'error'.");
await interactive(61,"cat error");
funcjs_61_cat_error();
await new_line(62,"Ici l'erreur a bien été enregistrée dans le fichier.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(63,"Essayez de rediriger séparement les résultats et les erreurs d'une commande dans deux fichiers différents avec : " + learn + "pwd 1>out 2>err" + reset + "");
await interactive(64,"pwd 1>out 2>err");
funcjs_64_pwd_1_out_2_err();
new_line_no_wait(65,"Affichez le contenu du fichier 'err'.");
await interactive(66,"cat err");
funcjs_66_cat_err();
await new_line(67,"La commande ne provoquant pas d'erreur, 'err' est vide.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(68,"Pour vérifier si " + code + "1>" + reset + " et " + code + "2>" + reset + " peuvent fonctionner en même temps, il va falloir utiliser un code qui utilise les deux flux.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(69,"Prenons par exemple : " + learn + "pwdd||pwd" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(70,"" + code + "pwdd" + reset + " renverra un message d'erreur. Il utilisera donc la sortie erreur standard. (stderr)");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(71,"" + code + "pwdd" + reset + " renvoyant une erreur, la commande " + code + "pwd" + reset + " se lancera et enverra son résultat vers la sortie standard. (stdout)");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(72,"" + code + "1>" + reset + " est équivalent à " + code + ">" + reset + ", et l'équivalent de " + code + ">>" + reset + " est tout simplement " + code + "1>>" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(73,"Essayez donc de faire : " + learn + "pwdd||pwd 1>>f 2>>e" + reset + "");
await interactive(74,"pwdd||pwd 1>>f 2>>e");
funcjs_74_pwdd__pwd_1__f_2__e();
await new_line(75,"Ici une erreur s'affiche dans le terminal, " + code + "2>>" + reset + " semble donc ne pas fonctionner...");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(76,"En fait, les redirections s'utilisent avec une commande. Ici " + code + "pwdd||pwd" + reset + " n'est pas une commande !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(78,"Il s'agit en fait de " + voc + "deux" + reset + " commandes différentes : " + code + "pwdd" + reset + " et " + code + "pwd" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(79,"C'est à dire que " + learn + "pwdd||pwd 1>>f 2>>e" + reset + " est aussi composé de " + voc + "deux" + reset + " commandes.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(80,"La première : " + code + "pwdd" + reset + " et la deuxième : " + code + "pwd 1>>f 2>>e" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(81,"Dans ce cas, " + code + "2>>e" + reset + " ne redirigera que les erreurs de la commmande " + code + "pwd" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(82,"Il est donc normal que l'erreur de " + code + "pwdd" + reset + " s'affiche dans le terminal.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(83,"Pour rediriger les résultats et les erreurs des deux commandes, faites donc : " + learn + "pwdd 1>>f 2>>e||pwd 1>>f 2>>e" + reset + "");
await interactive(84,"pwdd 1>>f 2>>e||pwd 1>>f 2>>e");
funcjs_84_pwdd_1__f_2__e__pwd_1__f_2__e();
await new_line(85,"Vous pouvez aussi plus simplement regrouper les deux commandes pour qu'elles ne fassent " + voc + "qu'une" + reset + ", en utilisant les " + code + "()" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(87,"Par exemple, pour " + code + "(ls&&lss)2>e" + reset + ", la redirection " + code + "2>e" + reset + " sera faite sur " + code + "ls&&lss" + reset + ", et non pas uniquement sur " + code + "lss" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(88,"L'espace ici entre " + code + ")" + reset + " et " + code + "2>e" + reset + " n'est pas nécessaire car " + code + ")" + reset + " est un caractère spécial, elle sépare donc sans ambiguïté la redirection.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(89,"Faites donc : " + learn + "(pwdd||pwd)1>>f 2>>e" + reset + ", l'équivalent de la commande précédente : " + learn + "pwdd 1>>f 2>>e||pwd 1>>f 2>>e" + reset + ".");
await interactive(90,"(pwdd||pwd)1>>f 2>>e");
funcjs_90__pwdd__pwd_1__f_2__e();
new_line_no_wait(91,"Affichez le contenu du fichier 'e'.");
await interactive(92,"cat e");
funcjs_92_cat_e();
await new_line(93,"Ici la deuxième erreur a bien été ajoutée à la suite de l'erreur de la commande précédente.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(94,"Pour mieux comprendre ces " + code + "()" + reset + ", reprenons un exemple que l'on a déjà vu, faites donc : " + learn + "cat FICHIER&&echo GOOD||echo ERROR" + reset + "");
await interactive(95,"cat FICHIER&&echo GOOD||echo ERROR");
funcjs_95_cat_FICHIER__echo_GOOD__echo_ERROR();
await new_line(96,"Ici, si FICHIER n'existe pas dans DOSSIER, " + code + "cat FICHIER" + reset + " renverra une erreur, ce qui provoquera le lancement de " + code + "echo ERROR" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(97,"Maintenant faites un simple : " + learn + "echo GOOD||echo ERROR" + reset + "");
await interactive(98,"echo GOOD||echo ERROR");
funcjs_98_echo_GOOD__echo_ERROR();
await new_line(99,"Evidemment ici ERROR ne s'affiche pas. Pourtant le code est le même que dans la commande précédente : " + learn + "cat FICHIER&&echo GOOD||echo ERROR" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(100,"Mais dans " + learn + "cat FICHIER&&echo GOOD||echo ERROR" + reset + ", " + code + "echo ERROR" + reset + " se lancera car " + code + "||" + reset + " ne se combine pas avec " + code + "echo GOOD" + reset + " comme dans " + learn + "echo GOOD||echo ERROR" + reset + ", mais avec " + code + "cat FICHIER&&echo GOOD" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(101,"Sans les " + code + "()" + reset + ", les conditions se lisent simplement de gauche à droite.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(102,"" + learn + "cat FICHIER&&echo GOOD||echo ERROR" + reset + " a en fait un ordre logique équivalent à " + learn + "(cat FICHIER&&echo GOOD)||echo ERROR" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(103,"Comme " + code + "cat FICHIER&&echo GOOD" + reset + " renvoit une erreur, " + code + "echo ERROR" + reset + " se lancera.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(104,"Vous pouvez donc changer aussi le sens de lecture de vos conditions avec les " + code + "()" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(105,"Par exemple, prenons le code suivant : " + learn + "cd DOSSIER&&(cat FICHIER||echo \"FICHIER n'existe pas dans DOSSIER\")||echo \"DOSSIER n'existe pas\"" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(106,"Les " + code + "()" + reset + " permettent de lier la commande " + code + "echo \"FICHIER n'existe pas dans DOSSIER\"" + reset + " avec la commande " + code + "cat FICHIER" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(107,"Sans les " + code + "()" + reset + ", " + code + "echo \"FICHIER n'existe pas dans DOSSIER\"" + reset + " se lancera si la commande " + code + "cd DOSSIER" + reset + " renvoit une erreur, ce qui n'est pas ce que l'on veut.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(108,"Vous pouvez donc utiliser ces " + code + "()" + reset + " pour regrouper votre code.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(109,"Que votre but soit de changer la logique d'exécution de vos commandes, ou comme avant pour regrouper les flux de sortie.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(110,"Pour rediriger la sortie standard, vous devez utiliser " + code + ">" + reset + " ou " + code + "1>" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(111,"Pour rediriger la sortie d'erreur, vous devez utiliser " + code + "2>" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(112,"Si vous voulez rediriger les deux à la fois, vous pouvez utiliser : " + code + "&>" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(113,"Ou évidemment " + code + "&>>" + reset + " si vous voulez ajouter le contenu à la fin d'un fichier.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(114,"Faites donc : " + learn + "pwd&>>f" + reset + "");
await interactive(115,"pwd&>>f");
funcjs_115_pwd___f();
await new_line(116,"" + code + "&>>" + reset + " commence par un caractère spécial, l'espace à sa gauche n'est donc pas nécessaire, contrairement à " + code + "1>" + reset + " ou " + code + "2>" + reset + " que l'on vu précédemment.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(117,"Faites donc la même commande avec une faute de frappe : " + learn + "pwdd&>>f" + reset + "");
await interactive(118,"pwdd&>>f");
funcjs_118_pwdd___f();
await new_line(119,"Avec cette commande, rien ne s'affiche dans le terminal, les deux redirections se passent donc correctement.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(120,"" + code + "&>>" + reset + " est donc bien équivalent à la combinaison de " + code + "1>>" + reset + " et de " + code + "2>>" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(121,"Mais parfois il est possible qu'un flux ne vous intéresse pas du tout.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(122,"Pour ce genre de cas il existe un fichier spécial, " + code + "/dev/null" + reset + ", que vous pouvez utiliser avec vos redirections.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(123,"" + code + "/dev/null" + reset + " est un fichier vide qui restera toujours vide.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(124,"Affichez donc le contenu du fichier inexistant 'X', en vous débarassant des messages d'erreur.");
await interactive(125,"cat X 2>/dev/null");
funcjs_125_cat_X_2__dev_null();
new_line_no_wait(126,"Affichez donc le contenu du fichier " + code + "/dev/null" + reset + "");
await interactive(127,"cat /dev/null");
funcjs_127_cat__dev_null();
await new_line(128,"Effectivement, malgré cette redirection, " + code + "/dev/null" + reset + " est toujours vide.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(129,"Si vous voulez vous débarasser des deux flux, il suffit d'utiliser " + code + "&>/dev/null" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(130,"Vous pouvez également, si vous le souhaitez, rediriger un flux vers un autre flux.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(131,"" + code + "2>&1" + reset + " redirigera la sortie erreur standard vers la sortie standard, et " + code + "1>&2" + reset + " redirigera la sortie standard vers la sortie erreur standard.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(132,"Ajoutez à la fin du fichier '/tmp/pwd.log' la sortie standard de la commande " + code + "pwd" + reset + ", puis regroupez sa sortie erreur standard avec sa sortie standard.");
await interactive(133,"pwd>>/tmp/pwd.log 2>&1");
funcjs_133_pwd___tmp_pwd_log_2__1();
new_line_no_wait(134,"Affichez donc le contenu du fichier '/tmp/pwd.log'.");
await interactive(135,"cat /tmp/pwd.log");
funcjs_135_cat__tmp_pwd_log();
new_line_no_wait(136,"Maintenant, faites avec une faute de frappe : " + learn + "pwdd>>/tmp/pwd.log 2>&1" + reset + "");
await interactive(137,"pwdd>>/tmp/pwd.log 2>&1");
funcjs_137_pwdd___tmp_pwd_log_2__1();
new_line_no_wait(138,"Puis réaffichez le contenu de '/tmp/pwd.log'.");
await interactive(139,"cat /tmp/pwd.log");
funcjs_139_cat__tmp_pwd_log();
await new_line(140,"L'erreur a été ici ajoutée à la suite, " + code + "2>&1" + reset + " est donc clairement dépendant du " + code + ">>" + reset + " de la sortie standard.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(141,"Attention donc à cette syntaxe, " + code + "2>&1" + reset + " veut dire que : \"La sortie d'erreur standard utilisera la même redirection que la sortie standard\".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(142,"" + code + "2>&1" + reset + " s'adaptera donc si la redirection de la sortie standard est " + code + ">" + reset + " ou " + code + ">>" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(143,"Pour ajouter à la fin d'un fichier, " + codeError + "2>>&1" + reset + " pourrait venir à l'esprit mais ce n'est pas une syntaxe valide.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(144,"Résumons donc : pour combiner les flux de même type de plusieurs commandes, nous devons donc utiliser les " + code + "()" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(145,"Faites donc " + learn + "(pwdd;pwd)" + reset + "");
await interactive(146,"(pwdd;pwd)");
funcjs_146__pwdd_pwd_();
await new_line(148,"Ici les deux sorties standards se regroupent en une seule sortie standard, celle de la commande " + code + "pwdd" + reset + " était vide.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(149,"Les deux sorties erreurs standards se regroupent également en une seule sortie d'erreur standard, celle de la commande " + code + "pwd" + reset + " était vide.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(150,"Nous avons donc maintenant notre code, qui utilise à la fois stdout et stderr : " + learn + "(pwdd;pwd)" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(151,"Mais il reste encore deux flux " + voc + "distincts" + reset + " pour ce groupe de commande : sa sortie standard et sa sortie erreur standard.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(153,"Ce schéma représente " + code + "(pwdd;pwd)" + reset + " : stdout et stderr sont indépendants, vous pouvez donc les rediriger normalement.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(154,"Par exemple " + code + "(pwdd;pwd)>>resultats 2>>erreurs" + reset + ", stdout sera envoyé vers le fichier 'resultat', et stderr vers le fichier 'erreurs'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(156,"Ce schéma représente " + code + "(pwdd;pwd)2>&1" + reset + ", ici la sortie erreur sera combinée avec la sortie standard.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(157,"Cependant, si vous voulez rediriger le contenu dans un fichier, il faudra le faire " + voc + "avant" + reset + " de rediriger stderr avec " + code + "2>&1" + reset + " car les redirections se lisent de gauche à droite.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(158,"Par exemple, " + code + "(pwdd;pwd)>tmp 2>&1" + reset + " n'as pas le même sens que " + code + "(pwdd;pwd)2>&1 >tmp" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(159,"La première redirigera stdout et stderr vers le fichier 'tmp', alors que la deuxième ne redirigera que stdout vers le fichier 'tmp'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(160,"Prenons par exemple la commande idiote mais correcte avec deux redirections de la sortie standard " + code + "(pwdd;pwd)>/dev/null 2>&1 1>f" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(161,"Les redirections se lisant de gauche à droite, stdout finira dans le fichier 'f' alors que stderr restera dans '/dev/null'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(163,"Ce schéma représente " + code + "(pwdd;pwd)1>&2" + reset + ", ici la sortie standard sera combinée avec la sortie erreur standard.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(165,"Pour se débarasser de ces deux flux, vous pourriez y ajouter " + code + "&>/dev/null" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(166,"Faites le donc : " + learn + "(pwdd;pwd)&>/dev/null" + reset + "");
await interactive(167,"(pwdd;pwd)&>/dev/null");
funcjs_167__pwdd_pwd____dev_null();
await new_line(168,"" + code + "&>/dev/null" + reset + " serait donc équivalent à : " + code + ">/dev/null 2>&1" + reset + ", ou " + code + "1>/dev/null 2>&1" + reset + ", ou encore " + code + "2>/dev/null 1>&2" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(169,"Maintenant rediriger les deux flux vers le fichier 'F' avec : " + learn + "(pwdd;pwd)&>F" + reset + "");
await interactive(170,"(pwdd;pwd)&>F");
funcjs_170__pwdd_pwd___F();
new_line_no_wait(171,"Puis affichez le contenu du fichier F.");
await interactive(172,"cat F");
funcjs_172_cat_F();
await new_line(173,"Vous pouvez notez ici que les deux flux ont été réunis avant l'écriture dans le fichier, c'est à dire que malgré l'utilisation de " + code + ">" + reset + " au lieu de " + code + ">>" + reset + ", la deuxième ligne n'a pas écrasée la première.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(174,"Faites donc à nouveau : " + learn + "(pwdd;pwd)&>F" + reset + "");
await interactive(175,"(pwdd;pwd)&>F");
funcjs_175__pwdd_pwd___F();
new_line_no_wait(176,"Puis réaffichez le contenu du fichier F.");
await interactive(177,"cat F");
funcjs_177_cat_F();
await new_line(178,"Ici vous avez à nouveau ces deux lignes, si vous aviez utilisé " + code + "&>>" + reset + " à la place de " + code + "&>" + reset + " vous auriez ici bien évidemment quatre lignes.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(179,"Pour terminer, la commande " + code + "(pwdd;pwd)>>tmp 2>&1" + reset + " est équivalente à la commande : " + code + "(pwdd;pwd)&>>tmp" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(180,"J'espère que ces redirections sont maintenant claires pour vous et bonne chance pour le questionnaire.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
launchGameScript_chapter_quiz();
}
async function launchGameScript_chapter_quiz() {
reset_GS();
intro_quiz_message();
document.getElementById('button_print_passwords').style.display='none';
document.getElementById('GS_selects').style.display='none';
document.getElementById('toggle_music_quiz').style.display='inline';
document.getElementById('button_start_quiz').style.display='none';
document.getElementById('button_start_lecture').value='Stop Quiz';
document.getElementById('button_start_lecture').onclick = function() { reset_GS(); }
toggle_music_quiz();
GOOD=1;
if(GOOD){ GOOD=await quiz("1","Comment afficher le contenu du fichier 'cat' en se débarassant de tous les messages d'erreur potentiels ?","cat cat 2>/dev/null"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("2","Comment executer deux commandes : 'mkdir A' et 'touch B' et regrouper leurs flux de même type ? (erreur et sortie standard)","(mkdir A;touch B)"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("3","La commande 'pwdd&>/dev/null' est équivalente à la commande 'pwdd 2>&1 >/dev/null'. (vrai/faux)","faux"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("4","Le fichier ERROR étant créé par la commande 'cat x 2>ERROR', comment afficher son contenu sur la sortie standard ?","cat ERROR"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("5","Comment afficher le contenu du fichier 'LOG' sur la sortie erreur standard en utilisant '1>' ?","cat LOG 1>&2"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("6","Comment rediriger la sortie standard et la sortie erreur standard de la commande 'mkdir TEST' dans le fichier /var/mkdir","mkdir TEST&>/var/mkdir"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("7","Sans utiliser '&>>', comment ajouter à la fin du fichier '/tmp/pwd.log' la sortie standard de la commande 'pwd', puis regroupez sa sortie erreur standard avec sa sortie standard ?","pwd>>/tmp/pwd.log 2>&1"); } else { error_quiz_message(); return; }
P1="1109";
P2="ff12";
await ask_username(P1,P2,WHOAMI,SUBJECT,CHAPTER);
}
LINES=180
setTimeout(function(){ download_audio_chapter(WHOAMI,'fr','classic','bash','m1','7'); }, 2000);
if(VIDEO) download_video_chapter(WHOAMI,'fr','classic','bash','m1','7');
