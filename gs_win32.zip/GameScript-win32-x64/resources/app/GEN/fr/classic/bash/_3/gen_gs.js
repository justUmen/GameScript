function funcjs_7_ls__a__w_1(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_10_ls__a___width_1(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_15_ls__aw_10(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_21_man_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_23_ls___version(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_30_echo_bonjour(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_32_echo_bonjour_tout_le_monde(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_41_echo_bonjour_test(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_44_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_50_cat_test(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_55_cat_test_test(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_60_echo_au_revoir_test(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_62_cat_test(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_69_echo_bonjour__test(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_71_cat_test(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_77_ls__test(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_79_cat_test(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_84_echo_pwd__test(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_87_pwd__test(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_89_cat_test(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_94_echo_a__b(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_105_echo_a___b(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_109_echo_a__b(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_111_echo_a____b(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_115_echo_x__y(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_121_echo_____quitter(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_129_echo___X___X__(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_132_echo__X___X_(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_137_man_echo(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_141_echo__e__a_nb_(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_143_man_echo(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_145_echo__e__a_tb_(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_147_echo__e__a_tb__tab(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_149_cat_tab(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_151_cat_test_tab(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_153_rm_tab_test(){
GS_text.innerHTML += `<hr>
<hr>`;}
async function launchGameScript_chapter_lecture() {

reset_GS();
document.getElementById('toggle_music').style.display='inline';
document.getElementById('toggle_voice').style.display='inline';
document.getElementById('button_print_passwords').style.display='none';
document.getElementById('GS_selects').style.display='none';
document.getElementById('button_start_lecture').style.display='none';
document.getElementById('button_start_quiz').value='Stop Lecture';
document.getElementById('button_start_quiz').onclick = function() { reset_GS(); };
toggle_music();
await new_line(4,"Dans le chapitre 2, nous avons vu que les options peuvent avoir deux formes, l'une courte comme dans " + learn + "ls -l" + reset + ", et l'autre longue comme dans " + learn + "ls --all" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(5,"Si vous avez plusieures options à passer à la même commande, vous pouvez les mettre les unes à la suite des autres : " + learn + "ls -a -w 1" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(6,"Essayez donc avec cet exemple : " + learn + "ls -a -w 1" + reset + "");
await interactive(7,"ls -a -w 1");
funcjs_7_ls__a__w_1();
await new_line(8,"Vous pouvez bien évidemment utiliser les versions longues de la même manière, ou même les mélanger avec des options courtes.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(9,"Essayez donc de faire la même chose avec : " + learn + "ls -a --width=1" + reset + "");
await interactive(10,"ls -a --width=1");
funcjs_10_ls__a___width_1();
await new_line(11,"Mais n'oubliez pas les options courtes commencent par " + code + "-" + reset + " et les options longues commencent par " + code + "--" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(12,"Si vous utilisez les options courtes, vous pouvez également les regrouper avec le même " + code + "-" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(13,"Par exemple pour passez l'option " + code + "-a" + reset + " et l'option " + code + "-w 10" + reset + " à " + code + "ls" + reset + ", vous pouvez tapez " + code + "ls -aw 10" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(14,"Essayez donc cette commande : " + learn + "ls -aw 10" + reset + "");
await interactive(15,"ls -aw 10");
funcjs_15_ls__aw_10();
await new_line(16,"Attention donc à ne pas oublier qu'il y a deux " + code + "-" + reset + " avant les options longues.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(17,"Les commandes " + learn + "ls --all" + reset + " et " + learn + "ls -all" + reset + " ne sont pas du tout identiques.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(18,"" + learn + "ls --all" + reset + " est identique à " + learn + "ls -a" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(19,"Mais " + learn + "ls -all" + reset + " est identique à " + learn + "ls -a -l -l" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(20,"Ouvrez maintenant le manuel de " + code + "ls" + reset + " et cherchez l'option pour afficher son numéro de version.");
await interactive(21,"man ls");
funcjs_21_man_ls();
new_line_no_wait(22,"Affichez le numéro de version de " + code + "ls" + reset + ".");
await interactive(23,"ls --version");
funcjs_23_ls___version();
await new_line(24,"Parfait !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(25,"GameScript affiche en ce moment du texte dans votre terminal.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(26,"GameScript utilisant les mêmes commandes, laquelle est utilisée ici pour affichez ces phrases ?");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(27,"Pour afficher quelque chose dans un terminal, il vous faudra utiliser la commande " + code + "echo" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(28,"Cette commande vous renverra simplement un écho de ce que vous lui avez donné en argument.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(29,"Affichez donc le mot 'bonjour' dans votre terminal avec la commande : " + learn + "echo bonjour" + reset + "");
await interactive(30,"echo bonjour");
funcjs_30_echo_bonjour();
new_line_no_wait(31,"La commande " + code + "echo" + reset + " accepte plusieurs arguments, vous pouvez tester : " + learn + "echo bonjour tout le monde" + reset + "");
await interactive(32,"echo bonjour tout le monde");
funcjs_32_echo_bonjour_tout_le_monde();
await new_line(33,"Simple comme bonjour !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(34,"On a déjà vu ensemble que " + code + "mkdir" + reset + " était utilisé pour créer de nouveaux dossiers.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(35,"Mais comment créer de nouveaux fichiers ?");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(36,"Figurez-vous que vous pouvez utiliser la commande " + code + "echo" + reset + " !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(37,"Lorsque vous utilisez la commande " + code + "echo" + reset + ", le résultat s'affichera dans votre terminal.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(38,"Mais il est aussi possible de " + voc + "rediriger" + reset + " ce résultat ailleurs, par exemple dans un fichier texte.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(39,"Il vous faudra utiliser le symbole " + code + ">" + reset + ". Il représente une " + voc + "redirection" + reset + " du résultat.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(40,"Créez donc le fichier texte 'test' avec la commande : " + code + "echo bonjour>test" + reset + "");
await interactive(41,"echo bonjour>test");
funcjs_41_echo_bonjour_test();
await new_line(42,"Lorsque vous utilisez " + learn + "echo bonjour>test" + reset + ", si le fichier 'test' n'existe pas il sera créé.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(43,"Affichez donc les éléments de votre répertoire de travail.");
await interactive(44,"ls");
funcjs_44_ls();
await new_line(45,"Ici vous avez non seulement créé le fichier texte 'test', mais vous lui avez également donné un contenu.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(46,"Ce contenu sera le résultat de la commande à gauche du symbole " + code + ">" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(47,"Pour afficher le contenu de ce fichier, il vous faudra utiliser la commande " + code + "cat" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(48,"Encore une fois, il suffira de donner en argument à " + code + "cat" + reset + " le nom du fichier en question, comme vous le feriez pour la commande " + code + "rm" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(49,"Affichez donc le contenu du fichier 'test' avec : " + learn + "cat test" + reset + "");
await interactive(50,"cat test");
funcjs_50_cat_test();
await new_line(51,"La commande " + code + "cat" + reset + " porte ce nom car elle peut être utilisée pour faire une con" + code + "cat" + reset + "énation. C'est à dire mettre bout à bout des chaines de caractère.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(52,"Pour concaténer, il suffit de mettre les fichiers en argument les uns après les autres.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(53,"Il est aussi possible d'utiliser plusieures fois le même fichier.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(54,"Testez donc la commande : " + learn + "cat test test" + reset + "");
await interactive(55,"cat test test");
funcjs_55_cat_test_test();
await new_line(56,"" + learn + "cat test test" + reset + " affiche ici simplement deux fois le contenu du fichier 'test'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(57,"Encore une fois : lorsque vous utilisez " + code + ">" + reset + ", si le fichier n'existe pas il sera créé.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(58,"Par contre, si le fichier existe déjà le contenu sera remplacé.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(59,"Testons donc la commande : " + learn + "echo au revoir>test" + reset + "");
await interactive(60,"echo au revoir>test");
funcjs_60_echo_au_revoir_test();
new_line_no_wait(61,"Affichez maintenant le contenu du fichier 'test'.");
await interactive(62,"cat test");
funcjs_62_cat_test();
await new_line(63,"Ici le contenu a été remplacé ! Le mot 'bonjour' n'existe plus.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(64,"Attention donc à " + code + ">" + reset + ", car il peut supprimer le contenu de vos fichiers.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(65,"Si vous voulez " + voc + "ajouter" + reset + " du nouveau contenu dans un fichier, il vous faudra utiliser " + code + ">>" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(66,"De même, si vous utilisez " + code + ">>" + reset + ", si le fichier n'existe pas il sera créé.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(67,"Mais si le fichier existe déjà, le nouveau contenu s'ajoutera à la fin du fichier.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(68,"Testez donc avec : " + learn + "echo bonjour>>test" + reset + "");
await interactive(69,"echo bonjour>>test");
funcjs_69_echo_bonjour__test();
new_line_no_wait(70,"Puis affichez le contenu du fichier 'test'.");
await interactive(71,"cat test");
funcjs_71_cat_test();
await new_line(72,"Ici le mot 'bonjour' a été rajouté à la fin du fichier texte.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(73,"Vous pouvez continuer à utiliser " + code + ">>" + reset + " pour ajouter votre nouveau contenu les uns à la suite des autres.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(74,"Mais ces redirections (" + code + ">" + reset + " et " + code + ">>" + reset + ") ne se limitent pas à la commande " + code + "echo" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(75,"Toutes les commandes peuvent les utiliser.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(76,"Mettez par exemple le résultat de la commande " + learn + "ls" + reset + " à la suite du fichier 'test'  !");
await interactive(77,"ls>>test");
funcjs_77_ls__test();
new_line_no_wait(78,"Et affichez le fichier 'test'.");
await interactive(79,"cat test");
funcjs_79_cat_test();
await new_line(80,"C'est le " + voc + "résultat" + reset + " de la commande qui sera redirigé. Ici " + learn + "ls" + reset + " donne comme résultat : 'test', car 'test' est le seul élément du répertoire courant.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(81,"Si vous voulez y ajouter du texte, il faudra utiliser " + code + ">>" + reset + " en combinaison avec la commande " + code + "echo" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(82,"Si vous voulez ajouter le mot 'pwd' à la fin du fichier il faudra utiliser : " + learn + "echo pwd>>test" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(83,"Ajoutez ces trois lettres 'pwd' à la fin du fichier 'test'.");
await interactive(84,"echo pwd>>test");
funcjs_84_echo_pwd__test();
await new_line(85,"Donc attention à ne pas confondre " + learn + "pwd>>test" + reset + " avec " + learn + "echo pwd>>test" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(86,"Maintenant ajoutons le " + voc + "résultat" + reset + " de " + code + "pwd" + reset + " à la fin du fichier 'test'.");
await interactive(87,"pwd>>test");
funcjs_87_pwd__test();
new_line_no_wait(88,"Et affichez le fichier 'test'.");
await interactive(89,"cat test");
funcjs_89_cat_test();
await new_line(90,"Très Bien ! J'espère que le résultat ne vous surprend pas.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(91,"Maintenant revenons à la commande " + code + "echo" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(92,"Certains caractères spéciaux ne sont pas simple à afficher.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(93,"Essayez d'afficher la lettre 'a' et la lettre 'b', séparé par deux espaces avec : " + learn + "echo a  b" + reset + "");
await interactive(94,"echo a  b");
funcjs_94_echo_a__b();
await new_line(95,"Le résultat n'est pas celui qui était prévu... Il n'y a qu'un seul espace entre a et b.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(96,"Ici, " + code + "echo" + reset + " considère qu'il y a deux arguments, le premier argument 'a' et le deuxième argument 'b'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(97,"Il affiche donc les deux arguments séparé par un espace.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(98,"Il est donc parfois utile de limiter le nombre d'argument à un !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(99,"Mais comment afficher cet espace pour que la suite ne soit pas considérée comme un nouvel argument ?");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(100,"Il faudra utiliser ce que l'on appele en informatique un " + voc + "caractère d'échappement" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(101,"Ici, il s'agit du caractère " + code + " \ " + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(102,"Ce caractère d'échappement affectera " + voc + "uniquement" + reset + " le prochain caractère.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(103,"Dans notre cas, pour représenter un espace avec la commande " + code + "echo" + reset + " nous pouvons utiliser " + code + "\\ " + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(104,"Essayez donc avec ce caractère d'échappement : " + learn + "echo a \\ b" + reset + "");
await interactive(105,"echo a \ b");
funcjs_105_echo_a___b();
await new_line(106,"Il y a bien cette fois deux espaces entre 'a' et 'b', cependant il y a toujours deux arguments, le premier est 'a' et le deuxième est ' b'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(107,"Pour avoir un seul et unique argument, il faut supprimer cet espace après le 'a'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(108,"Essayez donc avec un seul argument : " + learn + "echo a\\ b" + reset + "");
await interactive(109,"echo a\ b");
funcjs_109_echo_a__b();
new_line_no_wait(110,"Maintenant, essayez d'afficher un deuxième espace entre a et b.");
await interactive(111,"echo a\ \ b");
funcjs_111_echo_a____b();
await new_line(112,"Ce caractère d'échappement est très utile pour afficher des caractères que vous ne pouvez pas afficher autrement.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(113,"Comme par exemple le symbole " + learn + ">" + reset + ", qui comme vous le savez, est aussi interprété par votre terminal comme un caractère spécial.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(114,"Testez donc cette commande : " + learn + "echo x\\>y" + reset + "");
await interactive(115,"echo x\>y");
funcjs_115_echo_x__y();
await new_line(116,"Ici, vous comprenez bien " + voc + "l'énorme" + reset + " différence qu'il y a entre " + learn + "echo x\>y" + reset + " et " + learn + "echo x>y" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(117,"" + learn + "echo x>y" + reset + " va créer le nouveau fichier 'y' avec comme contenu 'x' !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(118,"" + learn + "echo x\\>y" + reset + " affiche simplement du texte dans le terminal.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(119,"Pour affichez le symbole " + code + " \ " + reset + " avec echo, il suffit de rajouter juste avant votre caractère d'échappement.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(120,"Essayez par exemple d'afficher dans votre terminal : " + code + "\\quitter" + reset + ".");
await interactive(121,"echo \\\\quitter");
funcjs_121_echo_____quitter();
await new_line(122,"Dans " + code + " \\\\\\quitter " + reset + ", le premier " + code + " \ " + reset + " est le caractère d'échappement, mais le deuxième est simplement le caractère qui doit être interprété littéralement par votre terminal.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(123,"Pour ne pas avoir à utiliser cet " + code + " \ " + reset + " à chaque espace, vous pouvez également utiliser les " + code + "\"" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(124,"Deux " + code + "\"" + reset + " peuvent agir en temps que " + code + "délimiteur" + reset + " d'arguments.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(125,"C'est à dire que " + learn + "echo x\>y" + reset + " peut être remplacé par " + learn + "echo \"x>y\"" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(126,"Le contenu entre le premier " + code + "\"" + reset + " et le deuxième " + code + "\"" + reset + " sera considéré comme un seul argument pour la commande " + code + "echo" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(127,"Faisant partie de l'argument, les espaces seront donc traités et affichés en temps que tel.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(128,"Essayez donc de faire : " + learn + "echo \"X   X\"" + reset + "");
await interactive(129,"echo \"X   X\"");
funcjs_129_echo___X___X__();
await new_line(130,"Ici, les espaces s'affichent correctement.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(131,"Vous pouvez aussi remplacer les " + code + "\"" + reset + " par des " + code + "'" + reset + ". Faites le donc avec " + learn + "echo 'X   X'" + reset + "");
await interactive(132,"echo 'X   X'");
funcjs_132_echo__X___X_();
await new_line(133,"Si vous avez de nombreux " + code + "'" + reset + " à afficher, je vous conseille d'utiliser les " + code + "\"" + reset + " comme délimiteur, et si vous avez beaucoup de " + code + "\"" + reset + " à afficher, je vous conseille d'utiliser les " + code + "\'" + reset + " comme délimiteur.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(134,"Par exemple, même si l'affichage est équivalent, " + learn + "echo '\"Pierre\" et \"Marie\"'" + reset + " est plus lisible que " + learn + "echo \"\\\"Pierre\\\" et \\\"Marie\\\"\"" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(135,"Le " + voc + "caractère d'échappement" + reset + " " + code + " \ " + reset + " peut aussi être utilisé pour afficher d'autres caractères spéciaux, comme des mises à la ligne ou des tabulations.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(136,"Regardez rapidement cette liste dans le manuel de la commmande " + code + "echo" + reset + ".");
await interactive(137,"man echo");
funcjs_137_man_echo();
await new_line(138,"Si vous avez bien lu le manuel, vous avez compris que cela ne fonctionnera que si l'option " + code + "-e" + reset + " est présente.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(139,"La lettre 'n' est utilisée avec " + code + " \ " + reset + " pour représenter une mise à la ligne, 'n' comme " + code + "n" + reset + "ouvelle ligne.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(140,"Affichez donc la lettre 'a', puis la lettre 'b' sur une nouvelle ligne en utilisant les " + code + "'" + reset + " comme délimiteurs.");
await interactive(141,"echo -e 'a\nb'");
funcjs_141_echo__e__a_nb_();
new_line_no_wait(142,"Trouvez la syntaxe d'une " + voc + "tabulation" + reset + " horizontale dans le manuel de la commande " + code + "echo" + reset + ".");
await interactive(143,"man echo");
funcjs_143_man_echo();
new_line_no_wait(144,"En utilisant les " + code + "'" + reset + ", affichez la lettre 'a', suivi d'une tabulation, puis de la lettre 'b'.");
await interactive(145,"echo -e 'a\tb'");
funcjs_145_echo__e__a_tb_();
new_line_no_wait(146,"Maintenant au lieu d'afficher le résultat dans le terminal, mettez le dans un fichier avec le nom 'tab'.");
await interactive(147,"echo -e 'a\tb'>tab");
funcjs_147_echo__e__a_tb__tab();
new_line_no_wait(148,"Affichez le contenu du fichier 'tab'.");
await interactive(149,"cat tab");
funcjs_149_cat_tab();
new_line_no_wait(150,"Affichez maintenant en une seule commande le fichier 'test' avec le fichier 'tab' à la suite.");
await interactive(151,"cat test tab");
funcjs_151_cat_test_tab();
new_line_no_wait(152,"Supprimez maintenant 'tab' et 'test' en une seule commande.");
await interactive(153,"rm tab test");
funcjs_153_rm_tab_test();
await new_line(154,"Excellent ! Vous êtes prêt pour le questionnaire.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
launchGameScript_chapter_quiz();
}
async function launchGameScript_chapter_quiz() {
reset_GS();
intro_quiz_message();
document.getElementById('button_print_passwords').style.display='none';
document.getElementById('GS_selects').style.display='none';
document.getElementById('toggle_music_quiz').style.display='inline';
document.getElementById('button_start_quiz').style.display='none';
document.getElementById('button_start_lecture').value='Stop Quiz';
document.getElementById('button_start_lecture').onclick = function() { reset_GS(); }
toggle_music_quiz();
GOOD=1;
if(GOOD){ GOOD=await quiz("1","Quel est la version abrégée de 'ls -a -l' ?","ls -al"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("2","Comment ajouter le mot 'non' à la fin du fichier texte 'oui' ?","echo non>>oui"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("3","Comment remplacer le contenu du fichier 'test' par le mot 'exemple' ?","echo exemple>test"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("4","Comment afficher le contenu du fichier 'test' ?","cat test"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("5","Sur bash, quel est le caractère d'échappement ?","\\"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("6","Comment afficher dans le terminal : a>b","echo a\\>b"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("7","Quel est la lettre à utiliser après le caractère d'échappement pour représenter une mise à la ligne ?","n"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("8","Affichez, sans utiliser le caractère d'échappement, la phrase : j'ai bon","echo \"j'ai bon\""); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("9","Affichez trois guillemets (\"), sans utiliser le caractère d'échappement.","echo '\"\"\"'"); } else { error_quiz_message(); return; }
P1="2452";
P2="93a3";
await ask_username(P1,P2,WHOAMI,SUBJECT,CHAPTER);
}
LINES=154
setTimeout(function(){ download_audio_chapter(WHOAMI,'fr','classic','bash','m1','3'); }, 2000);
if(VIDEO) download_video_chapter(WHOAMI,'fr','classic','bash','m1','3');
