function funcjs_14_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_16_ls___(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_19_ls____(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_28_ls__(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_30_ls___(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_34_rm___bOb(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_37_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_39_pwd(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_44_mkdir_enfant(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_46_cd_enfant(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_48_pwd(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_50_cd______(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_52_pwd(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_56_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_63_ls__a(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_70_cd____GameScript_bash2(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_75_ls__a(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_84_cd__(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_86_pwd(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_91_rmdir__GameScript_bash2_enfant(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_93_cd__(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_95_rmdir____GameScript_bash2(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_99_ls__a(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_103_ls___all__HOME(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_110_man_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_117_man_rmdir(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_120_rmdir___help(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_123_cd__(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_125_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_129_man_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_134_ls__w_1(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_136_ls__w_100(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_139_ls___width_100(){
GS_text.innerHTML += `<hr>
<hr>`;}
async function launchGameScript_chapter_lecture() {

reset_GS();
document.getElementById('toggle_music').style.display='inline';
document.getElementById('toggle_voice').style.display='inline';
document.getElementById('button_print_passwords').style.display='none';
document.getElementById('GS_selects').style.display='none';
document.getElementById('button_start_lecture').style.display='none';
document.getElementById('button_start_quiz').value='Stop Lecture';
document.getElementById('button_start_quiz').onclick = function() { reset_GS(); };
toggle_music();
await new_line(5,"Dans le dernier cours, nous avons vu l'utilisation de certaines commandes et de leurs arguments.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(6,"La commande " + learn + "cd" + reset + " nous permet par exemple de nous déplacer dans le répertoire de notre choix.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(7,"Mais nous devons donner notre choix en " + voc + "argument" + reset + " de cette commande, par exemple " + learn + "cd test" + reset + " pour se déplacer dans le dossier 'test'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(8,"Ou encore " + learn + "mkdir test" + reset + " pour créer un répertoire qui portera le nom 'test'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(9,"La syntaxe est donc : " + voc + "<COMMANDE> <ARGUMENT>" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(10,"Cet " + voc + "<ARGUMENT>" + reset + " peut être un " + voc + "chemin relatif" + reset + ", comme un dossier dans le " + voc + "répertoire courant" + reset + " avec par exemple : " + learn + "mkdir NouveauDossier" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(11,"Cet " + voc + "<ARGUMENT>" + reset + " peut aussi être un " + voc + "chemin absolu" + reset + ", comme un fichier dans le " + voc + "répertoire racine" + reset + " avec par exemple : " + learn + "rm /fichier" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(12,"Mais vous souvenez-vous des commandes que nous avons déjà vu ?");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(13,"Essayez d'afficher les éléments de de votre répertoire courant.");
await interactive(14,"ls");
funcjs_14_ls();
new_line_no_wait(15,"Maintenant affichez le contenu de votre répertoire parent.");
await interactive(16,"ls ..");
funcjs_16_ls___();
await new_line(17,"" + code + ".." + reset + " étant l'abréviation d'un répertoire, il peut donc également s'écrire " + code + "../" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(18,"Testez donc : " + learn + "ls ../" + reset + "");
await interactive(19,"ls ../");
funcjs_19_ls____();
await new_line(20,"Le résultat de " + learn + "ls ../" + reset + " est équivalent au résultat de la commande précédente : " + learn + "ls .." + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(21,"" + code + ".." + reset + " étant un répertoire, il peut aussi avoir un parent, qui peut être ciblé par " + code + "../.." + reset + " ou encore " + code + "../../" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(22,"" + code + "../.." + reset + " cible donc le grand parent du répertoire courant.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(23,"" + code + "../../.." + reset + " cible son arrière grand parent, et ainsi de suite.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(24,"Mais il existe un autre nom spécial, qui représente le répertoire courant : c'est le " + code + "." + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(25,"Comme il s'agit d'un dossier, " + code + "./" + reset + " est aussi une syntaxe correcte.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(26,"On a déjà vu que " + code + "ls" + reset + " pouvait avoir un argument, comme " + learn + "ls /" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(27,"Donnons le repertoire courant en argument à " + code + "ls" + reset + " avec : " + learn + "ls ." + reset + "");
await interactive(28,"ls .");
funcjs_28_ls__();
new_line_no_wait(29,"Et maintenant faites " + learn + "ls ./" + reset + "");
await interactive(30,"ls ./");
funcjs_30_ls___();
await new_line(31,"Ces deux commandes donnent le même résultat qu'un simple " + learn + "ls" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(32,"Sans argument, la commande " + learn + "ls" + reset + " cible par défaut le répertoire " + code + "." + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(33,"Pour supprimer ce fichier 'bOb', vous pouvez donc par exemple taper " + learn + "rm ./bOb" + reset + ", allez-y.");
await interactive(34,"rm ./bOb");
funcjs_34_rm___bOb();
await new_line(35,"Il n'y a pas de message d'erreur, cela veut donc dire que la commande a bien fonctionné.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(36,"Vérifions néanmoins le contenu du répertoire courant.");
await interactive(37,"ls");
funcjs_37_ls();
new_line_no_wait(38,"Parfait, il n'existe plus. Affichez maintenant le chemin du répertoire courant.");
await interactive(39,"pwd");
funcjs_39_pwd();
await new_line(40,"Attention à ce symbole " + code + "." + reset + ", ici il a une autre signification.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(41,"Ce '.' dans '.GameScript_bash2' ne fait pas du tout référence au répertoire courant, ce '.' fait simplement partie du nom du dossier.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(42,"Le nom complet du dossier est '.GameScript_bash2'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(43,"Maintenant créez un nouveau dossier 'enfant' dans le répertoire courant.");
await interactive(44,"mkdir enfant");
funcjs_44_mkdir_enfant();
new_line_no_wait(45,"Déplacez vous dans ce dossier 'enfant' que vous venez de créer.");
await interactive(46,"cd enfant");
funcjs_46_cd_enfant();
new_line_no_wait(47,"Affichez le chemin du répertoire courant.");
await interactive(48,"pwd");
funcjs_48_pwd();
new_line_no_wait(49,"Maintenant déplacez vous dans votre répertoire grand parent en utilisant son chemin relatif.");
await interactive(50,"cd ../..");
funcjs_50_cd______();
new_line_no_wait(51,"Réaffichez le chemin du répertoire courant.");
await interactive(52,"pwd");
funcjs_52_pwd();
await new_line(53,"Vous êtes maintenant dans le répertoire où se trouve le dossier '.GameScript_bash2'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(54,"Mais si vous tentez d'afficher les éléments de votre répertoire courant, vous ne le verrez pas.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(55,"Essayez donc de l'afficher avec : " + learn + "ls" + reset + ".");
await interactive(56,"ls");
funcjs_56_ls();
await new_line(57,"Sur un système d'exploitation de type Unix, comme Linux, si un nom de fichier ou un nom de dossier commence par un " + code + "." + reset + ", cet élément sera " + voc + "caché" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(58,"Ici il n'est pas dans l'affichage de la commande " + learn + "ls" + reset + ", pourtant il existe bel et bien.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(59,"Mais comment pouvez vous afficher le dossier caché '.GameScript_bash2' ?");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(60,"La plupart des commandes peuvent avoir des arguments spéciaux, qui donnent plus de détails à cette commande.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(61,"Ces arguments spéciaux commence par un " + code + "-" + reset + " et se nomment " + voc + "options" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(62,"Pour que " + learn + "ls" + reset + " affiche également les éléments " + voc + "cachés" + reset + ", il vous faudra faire " + learn + "ls -a" + reset + ", allez-y.");
await interactive(63,"ls -a");
funcjs_63_ls__a();
await new_line(64,"Ici vous devriez pourvoir voir le dossier " + code + ".GameScript_bash2" + reset + ", mais aussi beaucoup d'autres éléments " + voc + "cachés" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(65,"Traditionnelement, ces " + voc + "options" + reset + " sont placés avant les arguments normaux.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(66,"La syntaxe sera donc " + voc + "<COMMANDE> <OPTION> <ARGUMENT_NORMAL>" + reset + " comme par exemple " + learn + "ls -a /" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(67,"Maintenant comment revenir dans ce dossier " + code + ".GameScript_bash2" + reset + " ?");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(68,"Il est possible de revenir dans ce dossier avec un simple " + learn + "cd .GameScript_bash2" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(69,"Mais il est aussi possible de se déplacer dans ce répertoire avec : " + learn + "cd ./.GameScript_bash2" + reset + ", essayez donc cette commande.");
await interactive(70,"cd ./.GameScript_bash2");
funcjs_70_cd____GameScript_bash2();
await new_line(71,"J'espère que la différence entre ces deux " + code + "." + reset + " dans cette commande est pour vous évidente.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(72,"" + code + "." + reset + "/.GameScript_bash2 : Ce '.' représente le répertoire courant.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(73,"./" + code + "." + reset + "GameScript_bash2 : Ce '.' fait de ce dossier un dossier caché.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(74,"Réaffichez les éléments et les éléments " + voc + "cachés" + reset + " de votre nouveau répertoire courant.");
await interactive(75,"ls -a");
funcjs_75_ls__a();
await new_line(76,"Vous pouvez voir ici les deux références spéciales que l'on vient de voir : " + code + "." + reset + " et " + code + ".." + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(77,"Ces deux dossiers cachés, " + code + "." + reset + " et " + code + ".." + reset + ", sont présents dans tous les dossiers.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(78,"Puisque l'on parle de répertoire avec symbole spéciaux, nous pouvons aussi parler du " + code + "~" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(79,"Le " + code + "~" + reset + " représente le " + voc + "répertoire personnel" + reset + " de l'utilisateur.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(80,"Le plus souvent ce répertoire porte le nom de l'utilisateur dans le dossier " + code + "/home/" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(81,"Dans votre cas, " + code + "~" + reset + " remplace ce chemin : " + code + "" + home + "" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(82,"Vous pouvez bien évidemment utiliser ce " + code + "~" + reset + " en argument avec vos commandes.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(83,"Déplacez vous donc dans ce répertoire avec " + learn + "cd ~" + reset + "");
await interactive(84,"cd ~");
funcjs_84_cd__();
new_line_no_wait(85,"Vérifiez maintenant votre nouveau répertoire courant.");
await interactive(86,"pwd");
funcjs_86_pwd();
await new_line(87,"" + code + "~" + reset + " remplace dans votre cas ce chemin absolu : " + code + "" + home + "" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(88,"Pour cibler '.GameScript_bash2', vous pouvez donc utiliser comme chemin relatif " + code + ".GameScript_bash2" + reset + " ou " + code + "./.GameScript_bash2" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(89,"Mais vous pouvez également, grâce à " + code + "~" + reset + ", utiliser un nouveau chemin absolu : " + code + "~/.GameScript_bash2" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(90,"Supprimez le dossier 'enfant' que vous avez créé dans '.GameScript_bash2' en utilisant son chemin relatif.");
await interactive(91,"rmdir .GameScript_bash2/enfant");
funcjs_91_rmdir__GameScript_bash2_enfant();
new_line_no_wait(92,"Déplacez vous maintenant dans le répertoire racine.");
await interactive(93,"cd /");
funcjs_93_cd__();
new_line_no_wait(94,"Maintenant supprimez le dossier " + code + ".GameScript_bash2" + reset + " en utilisant son chemin absolu et le symbole " + code + "~" + reset + " !");
await interactive(95,"rmdir ~/.GameScript_bash2");
funcjs_95_rmdir____GameScript_bash2();
await new_line(96,"Parfait !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(97,"Maintenant revenons sur les commandes et plus précisement sur leurs " + voc + "options" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(98,"Listez tous les éléments du répertoire courant avec " + learn + "ls -a" + reset + ".");
await interactive(99,"ls -a");
funcjs_99_ls__a();
await new_line(100,"Certaines " + voc + "options" + reset + " ont aussi une version longue, parfois plus facile à mémoriser, qui commence elle par " + code + "--" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(101,"Par exemple vous pouvez remplacer " + code + "-a" + reset + " par " + code + "--all" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(102,"Listez tous les éléments de " + code + "" + home + "" + reset + " avec " + learn + "ls --all " + home + "" + reset + ".");
await interactive(103,"ls --all /home/example");
funcjs_103_ls___all__HOME();
await new_line(104,"Les commandes " + code + "ls -a" + reset + " et " + code + "ls --all" + reset + " sont identiques !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(105,"Mais comment pouvoir retenir toutes les options de toutes les commandes ?");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(106,"En fait vous n'avez pas besoin de les mémoriser !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(107,"Vous pouvez toujours accéder au " + voc + "manuel" + reset + " d'une commande avec la commande " + learn + "man" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(108,"Pour quitter le manuel, appuyez sur la touche 'q' de votre clavier, comme " + voc + "q" + reset + "uitter.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(109,"Ouvrez le manuel de la commande ls avec " + learn + "man ls" + reset + ", survoler rapidement son contenu, et enfin quitter avec la touche 'q'.");
await interactive(110,"man ls");
funcjs_110_man_ls();
await new_line(111,"Si vous avez oublié certaines options d'une commande, vous pouvez toujours ouvrir son manuel.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(112,"Si vous posez une question sur internet à propos d'une commande, mais que la réponse est dans le manuel, il est possible que vous ayez la réponse : RTFM.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(113,"C'est un acronyme anglais pour 'Read The Fucking Manual' ou 'Lis le Putain de Manuel'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(114,"Apprendre à lire les manuels est indispensable pour pouvoir vous débrouiller seul face à des problèmes simples.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(115,"Avec la répétition vous devriez vous souvenir des options les plus importantes, mais ayez toujours le réflexe de visiter le manuel avant de demander de l'aide. Le manuel sera toujours là pour vous.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(116,"Faites le donc pour " + code + "rmdir" + reset + ", regardez rapidement les options disponibles dans le manuel et quittez avec la touche 'q' : " + learn + "man rmdir" + reset + "");
await interactive(117,"man rmdir");
funcjs_117_man_rmdir();
await new_line(118,"La plupart des commandes ont une option " + code + "--help" + reset + ", qui affiche l'aide de la commande. Il s'agit parfois simplement du contenu du manuel.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(119,"Affichez l'aide de rmdir avec " + learn + "rmdir --help" + reset + "");
await interactive(120,"rmdir --help");
funcjs_120_rmdir___help();
await new_line(121,"Excellent, maintenant voyons d'autres options.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(122,"D'abord déplacez vous dans votre répertoire racine avec la commande " + learn + "cd /" + reset + "");
await interactive(123,"cd /");
funcjs_123_cd__();
new_line_no_wait(124,"Affichez les éléments du répertoire courant.");
await interactive(125,"ls");
funcjs_125_ls();
await new_line(126,"" + learn + "ls" + reset + " utilise par défaut toute la longueur du terminal pour l'affichage.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(127,"Mais il est possible de limiter sa longueur avec l'option " + code + "-w" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(128,"Ouvrez le manuel de " + code + "ls" + reset + ", lisez les détails de l'option " + code + "-w" + reset + " et quittez le manuel.");
await interactive(129,"man ls");
funcjs_129_man_ls();
await new_line(130,"Certaines options, comme ici " + code + "-w" + reset + ", doivent aussi avoir des valeurs.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(131,"Pour utiliser l'option " + code + "-w" + reset + ", il faudra lui donner une valeur numérique qui correspondra au nombre de caractère par ligne.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(132,"Si vous limitez cette valeur par exemple à 1, vous pouvez être sûr qu'il y aura qu'un seul nom de fichier par ligne.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(133,"Essayez donc cette commande : " + learn + "ls -w 1" + reset + "");
await interactive(134,"ls -w 1");
funcjs_134_ls__w_1();
new_line_no_wait(135,"Essayez maintenant 100 comme limite avec : " + learn + "ls -w 100" + reset + "");
await interactive(136,"ls -w 100");
funcjs_136_ls__w_100();
await new_line(137,"La version longue des options avec valeur est parfois différente, avec l'utilisation du signe " + code + "=" + reset + " au lieu d'un espace.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(138,"Essayez d'utiliser la version longue avec " + learn + "ls --width=100" + reset + "");
await interactive(139,"ls --width=100");
funcjs_139_ls___width_100();
await new_line(140,"Encore une fois, il n'est pas nécessaire d'apprendre par coeur toutes les options disponibles.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(141,"Il faudra surtout apprendre à utiliser " + code + "man" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(142,"Vous êtes prêt pour le questionnaire ! Allez vérifier vos connaissances !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
launchGameScript_chapter_quiz();
}
async function launchGameScript_chapter_quiz() {
reset_GS();
intro_quiz_message();
document.getElementById('button_print_passwords').style.display='none';
document.getElementById('GS_selects').style.display='none';
document.getElementById('toggle_music_quiz').style.display='inline';
document.getElementById('button_start_quiz').style.display='none';
document.getElementById('button_start_lecture').value='Stop Quiz';
document.getElementById('button_start_lecture').onclick = function() { reset_GS(); }
toggle_music_quiz();
GOOD=1;
if(GOOD){ GOOD=await quiz("1","Quel est le symbole qui représente le répertoire personnel de l'utilisateur ?","~"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("2","Par quel symbole commence un fichier caché ?","."); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("3","Par quel symbole commence un dossier caché ?","."); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("4","Comment se déplacer dans le répertoire grand parent ?","cd ../.."); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("5","Quel est le symbole qui représente le répertoire courant ?","."); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("6","Comment afficher le manuel de la commande rm","man rm"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("7","Par quel symbole commencent les options courtes de commande données en argument ?","-"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("8","Par quel symboles commencent les options longues de commande données en argument ?","--"); } else { error_quiz_message(); return; }
P1="246e";
P2="1f13";
await ask_username(P1,P2,WHOAMI,SUBJECT,CHAPTER);
}
LINES=142
setTimeout(function(){ download_audio_chapter(WHOAMI,'fr','classic','bash','m1','2'); }, 2000);
if(VIDEO) download_video_chapter(WHOAMI,'fr','classic','bash','m1','2');
