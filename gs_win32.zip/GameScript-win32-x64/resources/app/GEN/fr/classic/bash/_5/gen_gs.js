function funcjs_9_ls__l(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_48_ls__l(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_54_cat_f1(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_58_cat_f2(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_61_echo_cd__f2(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_66_ls__l_f3(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_68_cat_f3(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_70_echo_def__f3(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_72_cat_f3(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_78_touch_file(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_81_ls__l_file(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_86_whoami(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_96_ls__l__(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_104_ls__l(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_107_cd_Dossier(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_113_ls_Dossier(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_116_ls__l_Dossier(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_132_ls__l(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_141_cat_f1(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_143_chmod_u+r_f1(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_145_ls__l(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_148_cat_f1(){
GS_text.innerHTML += `<hr>
<hr>`;}
async function launchGameScript_chapter_lecture() {

reset_GS();
document.getElementById('toggle_music').style.display='inline';
document.getElementById('toggle_voice').style.display='inline';
document.getElementById('button_print_passwords').style.display='none';
document.getElementById('GS_selects').style.display='none';
document.getElementById('button_start_lecture').style.display='none';
document.getElementById('button_start_quiz').value='Stop Lecture';
document.getElementById('button_start_quiz').onclick = function() { reset_GS(); };
toggle_music();
await new_line(6,"Dans ce chapitre nous revenons sur la commande " + code + "ls" + reset + ", l'une des commandes les plus importantes.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(7,"Et ici nous allons parler de son option la plus importante : " + code + "-l" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(8,"Vous pouvez taper : " + learn + "ls -l" + reset + "");
await interactive(9,"ls -l");
funcjs_9_ls__l();
await new_line(10,"Avec cette option, " + code + "ls" + reset + " nous donne plus d'informations sur les éléments du répertoire courant.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(11,"Vous avez au début une chaine de caractères étrange composé de " + code + "-" + reset + " et de lettres à gauche du premier espace de chaque ligne.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(12,"Le premier caractère représente le type de l'élément.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(13,"Si c'est un " + code + "-" + reset + ", cet élément est un fichier, si c'est un " + code + "d" + reset + ", il s'agit d'un dossier.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(14,"Avec ce premier caractère, on voit clairement que 'Dossier' est un dossier et que les autres sont des fichiers.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(15,"Les neufs autres caractères qui suivent représentent les " + voc + "permissions" + reset + " de l'élément en question.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(16,"Il est possible d'avoir plusieurs utilisateurs sur un même ordinateur.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(17,"Mais certains de vos fichiers méritent peut-être d'être protégés.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(18,"Par exemple, il semblerai raisonnable que votre petite soeur ne puisse pas supprimer vos fichier personnels.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(19,"En revanche, même si vous ne voulez pas qu'elle puisse supprimer vos fichiers, vous avez peut-être besoin de lui donner la permission de les lire.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(20,"Ces neufs caractères sont utilisés pour définir avec précision les permissions que vous désirez.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(21,"La permission 'minimale' est " + code + "---------" + reset + " et la permission 'maximale' est " + code + "rwxrwxrwx" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(22,"Chaque " + code + "-" + reset + " veut dire que qu'un certain type de permission est " + voc + "désactivé" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(23,"A l'inverse, lorsque vous voyez une lettre, c'est qu'un certain type de permission est " + voc + "activé" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(24,"Mais chaque caractère doit respecter cet ordre : " + code + "rwxrwxrwx" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(25,"C'est à dire qu'ils n'auront pour simplifier que deux états possibles.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(26,"Le premier caractère pourra être soit un " + code + "-" + reset + " soit un " + code + "r" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(27,"Ce " + code + "r" + reset + " vient de l'anglais " + code + "r" + reset + "ead et donne le droit de lecture.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(28,"Le second caractère pourra être soit un " + code + "-" + reset + " soit un " + code + "w" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(29,"Ce " + code + "w" + reset + " vient de l'anglais " + code + "W" + reset + "rite et donne le droit d'écriture : la modification ou la suppression.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(30,"Le troisième caractère pourra être soit un " + code + "-" + reset + " soit un " + code + "x" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(31,"Ce " + code + "x" + reset + " vient de l'anglais e" + code + "X" + reset + "ecute et donne le droit d'exécution.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(32,"Et ce schéma de trois caractères " + code + "rwx" + reset + " se répète trois fois.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(33,"Les trois premiers caractères sont les permissions du " + voc + "propriétaire" + reset + " du fichier.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(34,"Exemple : -" + codeFile + "rw-" + reset + "r----- 2 " + codeFile + "albert" + reset + " familleEinstein 4096 Feb 19 00:51 Exemple");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(35,"Le nom du propriétaire du fichier 'Exemple' est ici 'albert'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(36,"Les trois caractères en vert sont les permissions d'albert.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(37,"Exemple : -rw-" + codeFile + "r--" + reset + "--- 2 albert " + codeFile + "familleEinstein" + reset + " 4096 Feb 19 00:51 Exemple");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(38,"Ici les trois caractères en vert sont les permissions des membres du " + voc + "groupe" + reset + " 'familleEinstein'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(39,"Ici on peut imaginer l'existence d'un groupe 'familleEinstein' pour la famille Einstein.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(40,"Exemple : -rw-r--" + codeFile + "---" + reset + " 2 albert familleEinstein 4096 Feb 19 00:51 Exemple");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(41,"Et enfin, les trois derniers caractères sont les permissions des autres utilisateurs.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(42,"Ceux qui ne sont ni albert, ni dans le groupe 'familleEinstein'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(43,"Dans cet exemple, albert, le propriétaire du fichier a le droit de lecture avec ce " + code + "r" + reset + " et le droit d'écriture avec ce " + code + "w" + reset + ", mais pas le droit d'exécution car le troisième caractère n'est pas un " + codeError + "x" + reset + " mais un " + code + "-" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(44,"Les membres du groupe 'familleEinstein' ont uniquement le droit de lecture sur ce fichier avec ce " + code + "r" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(45,"Ils n'ont pas le droit de le modifier ou de le supprimer, car il n'y a pas de " + code + "w" + reset + " !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(46,"Le reste des utilisateurs n'ont aucune permission, car il n'y a pour eux aucune lettre : " + codeFile + "---" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(47,"Maintenant revenons à nos fichiers et relançons la commande " + learn + "ls -l" + reset + "");
await interactive(48,"ls -l");
funcjs_48_ls__l();
await new_line(49,"Sur un système simple, il est probable que vous ayez un nom de groupe similaire à votre nom d'utilisateur, mais ça n'est pas un problème.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(50,"Il y a donc de nombreuses combinaisons de permission possibles, ici nous avons 'f1' avec les permissions minimales : " + code + "---------" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(51,"Nous avons 'f4' avec les permissions maximales : " + code + "rwxrwxrwx" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(52,"Et nous avons d'autres combinaisons de permissions pour les autres éléments.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(53,"Commençez par afficher le contenu du fichier 'f1'.");
await interactive(54,"cat f1");
funcjs_54_cat_f1();
await new_line(55,"Et oui, il n'est pas possible d'afficher le contenu de ce fichier, car vous n'avez pas le droit de lecture.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(56,"Pour pouvoir utiliser la commande " + code + "cat" + reset + ", il vous aurez fallu un " + code + "r" + reset + " à la place de ce tiret rouge : -" + codeError + "-" + reset + "--------.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(57,"Sur le fichier 'f2', vous avez ce 'r' dans : -" + code + "r" + reset + "--r--r-- qui vous donne le droit de lecture. Affichez le contenu de 'f2'.");
await interactive(58,"cat f2");
funcjs_58_cat_f2();
await new_line(59,"Ici pas de problème à l'affichage.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(60,"Ajoutez le texte 'cd' à la fin du fichier 'f2'.");
await interactive(61,"echo cd>>f2");
funcjs_61_echo_cd__f2();
await new_line(62,"Sur 'f2' nous avons encore un problème de permission.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(63,"Cette fois c'est un " + code + "w" + reset + " qui nous manque à la place de ce tiret rouge : -r" + codeError + "-" + reset + "-r--r--.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(64,"Mais 'f3' semble avoir à la fois le " + code + "r" + reset + " et le " + code + "w" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(65,"Affichez les permissions de 'f3' avec le nom du fichier en argument : " + learn + "ls -l f3" + reset + ".");
await interactive(66,"ls -l f3");
funcjs_66_ls__l_f3();
new_line_no_wait(67,"Affichez le contenu de 'f3'.");
await interactive(68,"cat f3");
funcjs_68_cat_f3();
new_line_no_wait(69,"Ajoutez 'def' au fichier 'f3'.");
await interactive(70,"echo def>>f3");
funcjs_70_echo_def__f3();
new_line_no_wait(71,"Affichez le contenu de 'f3' a nouveau.");
await interactive(72,"cat f3");
funcjs_72_cat_f3();
await new_line(73,"Parfait ! Nous pouvons enfin utiliser les commandes que nous avons apprises.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(74,"Mais nous n'avons jamais eu ce problème de permission dans les chapitres précédents...");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(75,"Je viens ici en fait de les simuler pour vous...");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(76,"Vous savez déjà créer un fichier texte avec " + code + "echo" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(77,"Mais vous pouvez aussi utiliser la commande " + code + "touch" + reset + ", faites donc : " + learn + "touch file" + reset + "");
await interactive(78,"touch file");
funcjs_78_touch_file();
await new_line(79,"Maintenant nous pouvons voir les permissions par défaut lors de la création d'un nouveau fichier.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(80,"Pour avoir les permissions de 'file', faites " + learn + "ls -l file" + reset + "");
await interactive(81,"ls -l file");
funcjs_81_ls__l_file();
await new_line(82,"Si le fichier a été créé par vous, vous aurez par défaut le droit de lecture et d'écriture.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(83,"Attention par contre si ce fichier ne vient pas de vous, il peut avoir des permissions limités ou inattendues.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(84,"Nous pouvons voir ici le nom du propriétaire du fichier, mais est-ce bien vous ?");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(85,"Pour connaitre votre nom d'utilisateur, vous pouvez taper : " + learn + "whoami" + reset + "");
await interactive(86,"whoami");
funcjs_86_whoami();
await new_line(87,"'Who am I ?' est l'anglais pour 'Qui suis-je ?'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(88,"Ici votre nom correspond effectivement au nom du propriétaire de ce fichier.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(89,"Mais il existe sur votre machine au moins un autre utilisateur !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(90,"Cet utilisateur possède les droits de vie ou de mort de tout ce qui existe dans votre système...");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(91,"Il s'agit de votre compte administrateur, plus connu sous le nom de " + voc + "root" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(92,"Traditionnelement, vos fichiers personnels doivent être stockés dans : /home/votrenom");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(93,"Et vous devriez être maitre de tout ce qu'il se passe à l'intérieur.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(94,"Mais en tant que simple utilisateur, vous ne pouvez contrôler que les éléments de ce répertoire !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(95,"Essayez donc d'afficher les permissions d'un autre dossier, le répertoire racine par exemple : " + learn + "ls -l /" + reset + "");
await interactive(96,"ls -l /");
funcjs_96_ls__l__();
await new_line(97,"Ici nous voyons bien que le propriétaire de ces éléments est " + voc + "root" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(98,"Vous n'êtes pas " + voc + "root" + reset + ", les trois premiers caractères de permissions ne vous concernent donc pas. : d" + codeError + "rwx" + reset + "r-xr-x");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(99,"Vous ne faites également pas partie du groupe en question : drwx" + codeError + "r-x" + reset + "r-x");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(100,"Les permissions qui vous concernent sont les trois dernières : drwxr-x" + codeFile + "r-x" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(101,"Vous avez donc les droits de lecture " + codeFile + "r" + reset + " et d'exécution " + codeFile + "x" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(102,"Mais qu'en est-il de cette permission " + voc + "d'exécution" + reset + " ?");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(103,"Affichons à nouveau les permissions des éléments du répertoire courant.");
await interactive(104,"ls -l");
funcjs_104_ls__l();
await new_line(105,"Ici nous avons un dossier avec le droit de lecture et d'écriture.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(106,"Rentrons dans ce dossier.");
await interactive(107,"cd Dossier");
funcjs_107_cd_Dossier();
await new_line(108,"Ici, malgré avoir le droit de lecture sur ce dossier, nous ne pouvons pas nous déplacer dedans.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(109,"Pour un fichier texte, les permissions " + codeFile + "x" + reset + " n'ont aucun effet...");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(110,"Mais ici avec un " + voc + "dossier" + reset + ", le " + codeFile + "x" + reset + " joue un rôle important !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(111,"Etrangement, nous avons le droit de lecture avec ce d" + codeFile + "r" + reset + "w-r--r--");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(112,"Donc nous pouvons afficher les éléments de ce dossier, faites le donc.");
await interactive(113,"ls Dossier");
funcjs_113_ls_Dossier();
await new_line(114,"Le contenu de 'Dossier' s'affiche. Il contient un fichier 'X' et un fichier 'Y'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(115,"Affichons maintenant les permissions des fichiers dans ce dossier.");
await interactive(116,"ls -l Dossier");
funcjs_116_ls__l_Dossier();
await new_line(117,"Ici l'absence de " + codeFile + "x" + reset + " dans les permissions de 'Dossier' nous empêche d'accéder aux détails.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(118,"Attention donc à ces permissions !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(119,"Si quelque chose ne se passe pas comme prévu, il se peut que vous ayez simplement un problème de permission à régler.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(120,"C'est ce que nous allons voir maintenant : Comment changer ces permissions ?");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(121,"Donc en premier lieu il faut que vous soyiez capable d'identifier la permission qu'il vous manque !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(122,"La commande " + code + "cat" + reset + " par exemple a besoin d'une permission de lecture : " + codeFile + "r" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(123,"Le fichier 'f1' ne nous donne pas cette permission pour l'afficher.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(124,"Pour changer ces permissions il faudra utiliser la commande : " + code + "chmod" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(125,"Il faudra d'abord mémoriser 3 nouvelles lettres :");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(126,"" + code + "u" + reset + " pour l'" + code + "u" + reset + "tilisateur ou le propriétaire : -" + codeFile + "rwx" + reset + "rwxrwx");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(127,"" + code + "g" + reset + " pour le " + code + "g" + reset + "roupe : -rwx" + codeFile + "rwx" + reset + "rwx");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(128,"et " + code + "o" + reset + " pour '" + code + "o" + reset + "thers', l'anglais de 'autres' : -rwxrwx" + codeFile + "rwx" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(129,"Vous pouvez ensuite utilisez ces lettres en conjonction avec les lettres 'r', 'w' et 'x' que vous connaissez déjà.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(130,"Vous devez également utiliser les symboles " + code + "+" + reset + " et " + code + "-" + reset + ", pour ajouter ou supprimer une permission.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(131,"Relancez : " + learn + "ls -l" + reset + "");
await interactive(132,"ls -l");
funcjs_132_ls__l();
await new_line(133,"Et prenons un exemple : Comment pouvoir nous autoriser l'affichage de 'f1' ?");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(134,"Autrement dit : transformer ---------- en -r--------.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(135,"D'abord nous voulons changer les permissions du propriétaire, il faudra donc utiliser la lettre " + code + "u" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(136,"Nous voulons ajouter une permission, il faudra donc utiliser le symbole " + code + "+" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(137,"Nous voulons le droit de lecture, il faudra donc bien sûr utiliser la lettre " + code + "r" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(138,"Et la cible de chmod sera le fichier 'f1'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(139,"La syntaxe sera donc la suivante : " + learn + "chmod u+r f1" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(140,"Avant de lancer cette commande, essayez donc d'afficher le contenu de 'f1'.");
await interactive(141,"cat f1");
funcjs_141_cat_f1();
new_line_no_wait(142,"Ajoutons donc le droit de lecture à 'f1' pour le propriétaire avec : " + learn + "chmod u+r f1" + reset + "");
await interactive(143,"chmod u+r f1");
funcjs_143_chmod_u+r_f1();
new_line_no_wait(144,"Relancez : " + learn + "ls -l" + reset + "");
await interactive(145,"ls -l");
funcjs_145_ls__l();
await new_line(146,"Ici nous avons bien : -r-------- pour le fichier 'f1'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(147,"Et enfin, affichez le fichier 'f1'.");
await interactive(148,"cat f1");
funcjs_148_cat_f1();
await new_line(149,"Vous pouvez donc utiliser toutes les combinaisons que vous voulez : " + learn + "u+r" + reset + ", " + learn + "g-w" + reset + ", " + learn + "u+x" + reset + ", etc...");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(150,"Mais vous pouvez aussi les cumuler avec d'autres, comme par exemple pour donner au propriétaire le droit de lecture ET d'écriture, vous pouvez faire : " + learn + "u+rw" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(151,"Pour enlever aux membres du groupe et aux autres le droit d'écriture, vous pouvez faire : " + learn + "go-w" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(152,"Ou encore pour donner tous les droits à tout le monde, vous pouvez faire : " + learn + "ugo+rwx" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(153,"Ou enlever tous les droits de tout le monde avec " + learn + "ugo-rwx" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(154,"Avant de passer au questionnaire je vous rappelle que le droit d'écriture donne le droit de " + voc + "suppression" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(155,"Bonne chance !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
launchGameScript_chapter_quiz();
}
async function launchGameScript_chapter_quiz() {
reset_GS();
intro_quiz_message();
document.getElementById('button_print_passwords').style.display='none';
document.getElementById('GS_selects').style.display='none';
document.getElementById('toggle_music_quiz').style.display='inline';
document.getElementById('button_start_quiz').style.display='none';
document.getElementById('button_start_lecture').value='Stop Quiz';
document.getElementById('button_start_lecture').onclick = function() { reset_GS(); }
toggle_music_quiz();
GOOD=1;
if(GOOD){ GOOD=await quiz("1","Comment afficher les permissions des éléments du répertoire personnel de l'utilisateur ?","ls -l ~"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("2","Quelle lettre représente un dossier dans le résultat de 'ls -l' ?","d"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("3","Quel symbole représente un fichier dans le résultat de 'ls -l' ?","-"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("4","Quelle lettre représente le droit d'écriture dans le résultat de 'ls -l' ?","w"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("5","Quelle lettre représente le droit de lecture dans le résultat de 'ls -l' ?","r"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("6","Quelle lettre représente le droit d'exécution dans le résultat de 'ls -l' ?","x"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("7","Quelle est la commande capable de modifier les permissions d'un fichier ?","chmod"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("8","Quelle lettre représente le propriétaire pour la commande chmod ?","u"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("9","Comment supprimer la permission de lecture au propriétaire du fichier 'test' ?","chmod u-r test"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("10","Comment ajouter la permission d'exécution sur le fichier 'test' à tous les utilisateurs sauf pour le propriétaire ?","chmod go+x test"); } else { error_quiz_message(); return; }
P1="28ab";
P2="3d4e";
await ask_username(P1,P2,WHOAMI,SUBJECT,CHAPTER);
}
LINES=155
setTimeout(function(){ download_audio_chapter(WHOAMI,'fr','classic','bash','m1','5'); }, 2000);
if(VIDEO) download_video_chapter(WHOAMI,'fr','classic','bash','m1','5');
