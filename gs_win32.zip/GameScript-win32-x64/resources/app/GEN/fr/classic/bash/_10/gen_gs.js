function funcjs_7_cmd__ls__a__var_(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_9_cmd(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_13___cmd(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_23_alias_a1__ls__a__var_(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_25_a1(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_28_alias(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_31_alias_gamescript(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_36_type_bash(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_41_wc__bin_bash(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_46_echo___PAGER(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_53_less__bin_bash(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_58_alias_monpager_less(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_60_monpager__bin_bash(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_65_pwd_echo____(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_68_pwdd_echo____(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_71_lss_echo____(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_74_cat_x_echo____(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_84_ls__O_VAL____(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_86_echo___VAL(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_91_type_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_95_type__a_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_100_var____pwd_(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_102_echo___var_pwd(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_105_var___ls__var_log___log__(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_107_echo___var(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_113_head___var(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_116_head___ls__var_log___log__(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_120_cat_LOG(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_123_tail___cat_LOG__(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_134_cat____bashrc_grep_gamescript(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_142_cat_variables(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_144_echo___var___var2(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_146_source_variables(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_148_echo___var___var2(){
GS_text.innerHTML += `<hr>
<hr>`;}
async function launchGameScript_chapter_lecture() {

reset_GS();
document.getElementById('toggle_music').style.display='inline';
document.getElementById('toggle_voice').style.display='inline';
document.getElementById('button_print_passwords').style.display='none';
document.getElementById('GS_selects').style.display='none';
document.getElementById('button_start_lecture').style.display='none';
document.getElementById('button_start_quiz').value='Stop Lecture';
document.getElementById('button_start_quiz').onclick = function() { reset_GS(); };
toggle_music();
await new_line(4,"Dans le dernier chapitre nous avons vu comment créer et manipuler les variables.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(5,"Mais les variables sont aussi capables de stocker des commandes bash.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(6,"Créez donc une variable 'cmd' qui contiendra " + code + "ls -a /var" + reset + " en utilisant les " + code + "'" + reset + ".");
await interactive(7,"cmd='ls -a /var'");
funcjs_7_cmd__ls__a__var_();
new_line_no_wait(8,"Faites donc maintenant : " + learn + "cmd" + reset + ".");
await interactive(9,"cmd");
funcjs_9_cmd();
await new_line(10,"Ici nous avons une erreur. Bien évidemment puisque 'cmd' est une " + voc + "variable" + reset + " et n'a jamais été une commande, faites attention à ne pas confondre les deux.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(11,"Vous pouvez néanmoins vous servir de cette variable comme une commande.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(12,"Mais pour cela, il faudra utiliser le \$, faites donc : " + learn + "\$cmd" + reset + ".");
await interactive(13,"\$cmd");
funcjs_13___cmd();
await new_line(14,"Ici " + learn + "\$cmd" + reset + " remplace simplement " + learn + "ls -a /var" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(15,"Mais pour lancer GameScript, il vous suffit de taper 'gamescript' dans votre terminal.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(16,"Si le code de GameScript était dans une variable, il vous faudrait pourtant taper '\$gamescript'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(17,"On peut donc imaginer que 'gamescript' est peut être un script qui est dans un des dossiers de la variable d'environnement 'PATH'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(18,"Et bien pas du tout... mais cela aurait pu être le cas.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(19,"GameScript utilise en fait un " + voc + "alias" + reset + ", un type de variable spécialisé pour les commandes.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(20,"Un " + voc + "alias" + reset + " n'est donc pas un programme mais simplement une commande ou groupe de commande.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(21,"La syntaxe est similaire aux variable classiques, il suffira d'ajouter le mot clef 'alias' avant la création de l'alias.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(22,"Créons notre premier alias avec : " + learn + "alias a1='ls -a /var'" + reset + ".");
await interactive(23,"alias a1='ls -a /var'");
funcjs_23_alias_a1__ls__a__var_();
new_line_no_wait(24,"Puis lancez simplement votre alias avec : " + learn + "a1" + reset + ".");
await interactive(25,"a1");
funcjs_25_a1();
await new_line(26,"Ici " + code + "a1" + reset + " remplace simplement la commande " + code + "ls -a /var" + reset + ", mais vous pouvez créez des alias beaucoup plus complexes.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(27,"Affichez une liste de tous vos alias en faisant simplement : " + learn + "alias" + reset + ".");
await interactive(28,"alias");
funcjs_28_alias();
await new_line(29,"Je le répète, 'gamescript' est dans votre environnement un alias.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(30,"Affichez uniquement l'alias de gamescript avec : " + learn + "alias gamescript" + reset + ".");
await interactive(31,"alias gamescript");
funcjs_31_alias_gamescript();
await new_line(32,"Lorsque vous lancez 'gamescript', voilà donc le code qui est réellement executé.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(33,"" + code + "wget" + reset + " télécharge la dernière version de GameScript et l'execute ensuite sur votre machine.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(34,"La commande 'bash' est exactement comme la commande 'date' du chapitre précédent, il s'agit en fait d'un fichier.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(35,"Pour connaitre le chemin absolu de ce fichier 'bash', faites donc : " + learn + "type bash" + reset + ".");
await interactive(36,"type bash");
funcjs_36_type_bash();
await new_line(37,"Vous l'avez peut être compris, mais 'gamescript', utilisant simplement 'bash' et non pas '/bin/bash', ne fonctionnera que si le dossier '/bin' est dans votre variable 'PATH'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(38,"Le répertoire '/bin' possède certains des fichiers " + voc + "bin" + reset + "aires les plus important de votre système.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(39,"Utiliser 'bash' au lieu de '/bin/bash' semble raisonnable dans cet alias, car '/bin' devrait être présent dans la variable d'environnement 'PATH' de tous les systèmes correctement configurés.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(40,"Affichez donc plus de details sur ce fichier '/bin/bash' avec : " + learn + "wc /bin/bash" + reset + ".");
await interactive(41,"wc /bin/bash");
funcjs_41_wc__bin_bash();
await new_line(42,"Ce fichier est particulièrement volumineux, je vous déconseille donc de l'afficher avec la commande " + code + "cat" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(43,"En revanche, nous pouvons utiliser sans risque notre 'PAGER'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(44,"'PAGER' est une autre variable d'environnement qui définit quel programme sera utilisé pour la lecture de fichiers.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(45,"Pour connaitre la valeur de 'PAGER', faites donc : " + learn + "echo \$PAGER" + reset + ".");
await interactive(46,"echo \$PAGER");
funcjs_46_echo___PAGER();
await new_line(47,"La plupart du temps ce 'PAGER' sera la commande " + code + "less" + reset + ", mais c'est une variable personnalisable, donc il se peut que vous ayez quelque chose d'autre.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(48,"Lorsque vous visitez le manuel d'une commande, vous pouvez naviguer de haut en bas avec votre clavier et même votre souris.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(49,"La commande " + code + "man" + reset + " utilise en fait votre 'PAGER'. C'est la commande " + code + "less" + reset + " qui donne à vos manuels cette interface interactive.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(50,"Lorsque vous quittez le manuel avec la touche 'q', vous quittez en fait l'interface fournie par " + code + "less" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(51,"Et vous pouvez très bien utiliser la commande " + code + "less" + reset + " pour naviguer dans le fichier de votre choix.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(52,"Regardez très rapidement le contenu du fichier '/bin/bash' avec " + learn + "less /bin/bash" + reset + ", puis quittez avec la touche 'q'.");
await interactive(53,"less /bin/bash");
funcjs_53_less__bin_bash();
await new_line(54,"Ici le fichier est illisible car il s'agit en fait d'un fichier " + voc + "binaire" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(55,"" + code + "less" + reset + " considère tout fichier ouvert comme un fichier texte, ce qu'il affiche n'a donc ici simplement aucun sens.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(56,"Si 'less' est la valeur de votre variable d'environnement 'PAGER', vous auriez bien sur également pu faire " + learn + "\$PAGER /bin/bash" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(57,"Créons maintenant l'alias 'monpager' avec : " + learn + "alias monpager=less" + reset + ".");
await interactive(58,"alias monpager=less");
funcjs_58_alias_monpager_less();
new_line_no_wait(59,"Utilisez maintenant ce nouvel alias avec '/bin/bash', puis quittez avec la touche 'q'.");
await interactive(60,"monpager /bin/bash");
funcjs_60_monpager__bin_bash();
await new_line(61,"Nous avonc donc vu comment créer et manipuler les variables et les alias, mais n'oubliez pas que ces variables et ces alias ne seront disponibles que dans la session de bash que vous utilisez actuellement.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(62,"Maintenant parlons d'une variable très particulière : " + code + "\$?" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(63,"" + code + "\$?" + reset + " contient un nombre entre 0 et 255, qui est la " + voc + "valeur de retour" + reset + " de votre dernière commande. (anglais " + voc + "exit status" + reset + ")");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(64,"Faites donc : " + learn + "pwd;echo \$?" + reset + "");
await interactive(65,"pwd;echo \$?");
funcjs_65_pwd_echo____();
await new_line(66,"Ici la valeur retour est 0. Cela veut dire que la commande " + code + "pwd" + reset + " n'a pas rencontré de problème.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(67,"Maintenant faites : " + learn + "pwdd;echo \$?" + reset + "");
await interactive(68,"pwdd;echo \$?");
funcjs_68_pwdd_echo____();
await new_line(69,"Ici la valeur retour est 127. Cela veut dire que la commande " + codeError + "pwdd" + reset + " n'existe pas.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(70,"Faites donc : " + learn + "lss;echo \$?" + reset + "");
await interactive(71,"lss;echo \$?");
funcjs_71_lss_echo____();
await new_line(72,"Ici la valeur retour est encore 127. Cela veut dire que la commande " + codeError + "lss" + reset + " n'existe pas.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(73,"Maintenant faites donc : " + learn + "cat x;echo \$?" + reset + "");
await interactive(74,"cat x;echo \$?");
funcjs_74_cat_x_echo____();
await new_line(75,"Ici la valeur retour n'est pas 0, ce qui veut dire que la commande a rencontré une erreur.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(76,"Cependant la valeur n'est pas la même que pour 'pwdd' et 'lss' car le type d'erreur est différent.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(77,"La commande " + code + "cat" + reset + " existe mais c'est le fichier donné en argument qui n'existe pas.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(78,"Vous avez en fait déjà utilisé cette variable " + code + "\$?" + reset + " sans le savoir.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(79,"" + code + "||" + reset + " et " + code + "&&" + reset + " utilisent la variable " + code + "\$?" + reset + " pour définir l'execution des autres commandes.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(80,"" + code + "&&" + reset + " lancera la prochaine commande si " + code + "\$?" + reset + " est égal à 0.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(81,"Et " + code + "||" + reset + " lancera la prochaine commande si " + code + "\$?" + reset + " n'est pas égal à 0.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(82,"Cette variable changera de valeur à chaque nouvelle commande, mais elle peut être sauvegardé dans une autre variable.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(83,"Essayez donc de sauvegarder la valeur retour de " + code + "ls -O" + reset + " avec : " + learn + "ls -O;VAL=\$?" + reset + "");
await interactive(84,"ls -O;VAL=\$?");
funcjs_84_ls__O_VAL____();
new_line_no_wait(85,"Affichez donc la valeur de la variable 'VAL'.");
await interactive(86,"echo \$VAL");
funcjs_86_echo___VAL();
await new_line(87,"Ce nombre est encore une fois différent, car ici l'erreur vient de l'utilisation d'une option inconnue.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(88,"Pour ce qui est des " + code + "alias" + reset + ", il se peut également que vous utilisiez des alias sans le savoir.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(89,"Ces alias peuvent remplacer une commande en utilisant le même nom.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(90,"Faites donc : " + learn + "type ls" + reset + ".");
await interactive(91,"type ls");
funcjs_91_type_ls();
await new_line(92,"Ici, vous avez probablement un alias vers la commande : " + code + "ls --color=auto" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(93,"Un alias sera prioritaire sur la variable 'PATH', c'est pourquoi vous ne devriez pas voir ici '/bin/ls'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(94,"Affichez toutes les interprétations possibles de la commande " + code + "ls" + reset + " avec : " + learn + "type -a ls" + reset + ".");
await interactive(95,"type -a ls");
funcjs_95_type__a_ls();
await new_line(96,"Si vous avez bien en première ligne l'alias " + code + "ls --color=auto" + reset + " et en deuxième ligne " + code + "/bin/ls" + reset + ", un simple " + code + "ls" + reset + " deviendra en fait " + code + "/bin/ls --color=auto" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(97,"Pour revenir sur les variables, savez-vous qu'elle peuvent aussi stocker le " + voc + "résultat" + reset + " d'une commande.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(98,"Il faudra pour cela utiliser le " + code + "\$" + reset + " et les " + code + "()" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(99,"Par exemple, pour stocker le résultat de la commande " + code + "pwd" + reset + " dans la variable 'var', faites : " + learn + "var=\$(pwd)" + reset + "");
await interactive(100,"var=\$(pwd)");
funcjs_100_var____pwd_();
new_line_no_wait(101,"Maintenant pour vérifier, faites : " + learn + "echo \$var;pwd" + reset + ".");
await interactive(102,"echo \$var;pwd");
funcjs_102_echo___var_pwd();
await new_line(103,"Vous pouvez également faire la même chose en utilisant les " + code + "\`\`" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(104,"Essayez par exemple : " + learn + "var=\`ls /var/log/*.log\`" + reset + "");
await interactive(105,"var=\`ls /var/log/*.log\`");
funcjs_105_var___ls__var_log___log__();
new_line_no_wait(106,"Puis affichez le contenu de la variable 'var'.");
await interactive(107,"echo \$var");
funcjs_107_echo___var();
await new_line(108,"Vous pouvez noter ici que l'utilisation de " + code + "\$()" + reset + " et " + code + "\`\`" + reset + " remplacent les mises a la ligne par des espaces !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(109,"Nous avons déjà vu " + learn + "cat" + reset + " pour afficher le contenu d'un fichier, mais il existe deux autres commandes bien utiles pour l'affichage du contenu des fichiers.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(110,"Il s'agit de " + code + "head" + reset + " et de " + code + "tail" + reset + ", qui affichent respectivement les 10 premières et les 10 dernières lignes d'un fichier.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(111,"La variable 'var' contient une liste de fichier, vous pouvez donc utiliser cette variable en argument de commande.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(112,"Affichez donc par exemple les 10 premières lignes de tous les fichiers dans la variable 'var'.");
await interactive(113,"head \$var");
funcjs_113_head___var();
await new_line(114,"Il est aussi possible de récuperer le résultat d'une commande et d'en faire une variable temporaire qui ne sera pas sauvegardée.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(115,"Vous pouvez par exemple faire la même chose sans la variable 'var', avec : " + learn + "head \`ls /var/log/*.log\`" + reset + "");
await interactive(116,"head \`ls /var/log/*.log\`");
funcjs_116_head___ls__var_log___log__();
await new_line(117,"Mais bien évidemment, ces deux commandes sont équivalentes à : " + learn + "head /var/log/*.log" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(118,"Mais imaginons par exemple que vous ayiez un fichier 'LOG' qui contient une liste des fichiers qui vous intéresse.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(119,"Affichez le contenu du fichier 'LOG'.");
await interactive(120,"cat LOG");
funcjs_120_cat_LOG();
await new_line(121,"Vous pouvez donc directement utiliser " + code + "tail" + reset + " avec le contenu de ce fichier en argument avec : " + code + "tail \$(cat LOG)" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(122,"Essayez donc avec la commande équivalente : " + learn + "tail \`cat LOG\`" + reset + "");
await interactive(123,"tail \`cat LOG\`");
funcjs_123_tail___cat_LOG__();
await new_line(124,"Dans cette situation, je vous le rappelle que les mises à la ligne sont remplacés par des espaces.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(125,"En utilisant cette méthode, le contenu de ce fichier devient une simple chaine de caractères donnée en argument à la commande " + code + "tail" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(126,"" + voc + "Méfiez vous" + reset + " donc des noms de fichiers qui contiennent des espaces ou des caractères spéciaux.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(127,"Si un fichier se nomme par exemple '/var/log/ce fichier.log', il sera donc considéré par " + code + "tail" + reset + " comme deux fichiers/arguments différents : '/var/log/ce' et 'fichier.log'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(128,"D'une manière générale, je vous conseille de ne " + voc + "jamais" + reset + " mettre d'espaces dans vos noms de fichiers, surtout si ces fichiers seront manipulés plus tard par un autre programme.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(129,"'ce fichier.log' peut devenir par exemple 'ce_fichier.log'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(130,"Mais si 'gamescript' est un alias, comment se fait-il que vous puissiez l'utiliser dans toutes vos instances de bash ?");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(131,"L'alias 'gamescript' est en fait créé dans le fichier de configuration principal de bash : " + code + "~/.bashrc" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(132,"Bash analyse le contenu de votre fichier caché " + code + "~/.bashrc" + reset + " à chaque lancement.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(133,"Vous pouvez retrouver la ligne correspondant à 'gamescript' avec : " + learn + "cat ~/.bashrc|grep gamescript" + reset + "");
await interactive(134,"cat ~/.bashrc|grep gamescript");
funcjs_134_cat____bashrc_grep_gamescript();
await new_line(135,"Donc si vous voulez avoir des alias ou des variables permanentes, vous pouvez tout simplement les ajouter dans ce fichier.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(136,"En revanche, n'oubliez pas que 'bash' n'utilise ce fichier qu'à l'ouverture d'une nouvelle session.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(137,"C'est à dire que si votre session bash était déjà ouverte avant la modification de ce fichier, les changements n'auront pas lieu.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(138,"Pour valider vos modifications, il vous faudra donc ouvrir une nouvelle session bash ou forcer la relecture de ce fichier de configuration avec : " + code + "source ~/.bashrc" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(139,"La commande " + code + "source" + reset + " peut également être utilisée pour lire les variables dans un fichier et les ajouter dans la session bash actuelle.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(141,"Affichez le contenu du fichier 'variables' de votre répertoire courant.");
await interactive(142,"cat variables");
funcjs_142_cat_variables();
new_line_no_wait(143,"Affichez les valeur de 'var' et 'var2', séparé par un espace.");
await interactive(144,"echo \$var \$var2");
funcjs_144_echo___var___var2();
new_line_no_wait(145,"Maintenant faites : " + learn + "source variables" + reset + "");
await interactive(146,"source variables");
funcjs_146_source_variables();
new_line_no_wait(147,"Et réaffichez les valeurs de 'var' et 'var2', séparé par un espace.");
await interactive(148,"echo \$var \$var2");
funcjs_148_echo___var___var2();
await new_line(149,"Avec cet exemple, vous devriez mieux comprendre l'effet qu'aura la commande " + learn + "source ~/.bashrc" + reset + " : elle actualisera le contenu du fichier ~/.bashrc.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(150,"" + code + "source ~/.bashrc" + reset + " peut aussi s'écrire " + code + ". ~/.bashrc" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(151,"C'est une syntaxe bien moins lisible que la première, mais vous devez la connaitre car vous risquez de la rencontrer un jour.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(152,"En avant pour le questionnaire !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
launchGameScript_chapter_quiz();
}
async function launchGameScript_chapter_quiz() {
reset_GS();
intro_quiz_message();
document.getElementById('button_print_passwords').style.display='none';
document.getElementById('GS_selects').style.display='none';
document.getElementById('toggle_music_quiz').style.display='inline';
document.getElementById('button_start_quiz').style.display='none';
document.getElementById('button_start_lecture').value='Stop Quiz';
document.getElementById('button_start_lecture').onclick = function() { reset_GS(); }
toggle_music_quiz();
GOOD=1;
if(GOOD){ GOOD=await quiz("1","Comment afficher la commande complète de l'alias 'gamescript' ?","alias gamescript"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("2","Comment afficher la liste complète de vos alias avec 'less' ?","alias|less"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("3","Quel est le nom (sans le $) de la variable d'environnment utilisée par la commande man pour savoir quelle commande doit ouvrir le manuel ?","PAGER"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("4","Comment afficher les dix dernières lignes du fichier 'test' ?","tail test"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("5","Comment affecter à la variable RET le code retour (exit status) de la dernière commande ?","RET=$?"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("6","Sans utiliser de '.', quelle commande vous permet d'ajouter les variables bash contenu dans le fichier 'VAR' dans votre session bash ?","source VAR"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("7","Comment afficher les dix premières lignes du fichier 'test' ?","head test"); } else { error_quiz_message(); return; }
P1="aba2";
P2="d414";
await ask_username(P1,P2,WHOAMI,SUBJECT,CHAPTER);
}
LINES=152
setTimeout(function(){ download_audio_chapter(WHOAMI,'fr','classic','bash','m1','10'); }, 2000);
if(VIDEO) download_video_chapter(WHOAMI,'fr','classic','bash','m1','10');
