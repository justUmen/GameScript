function funcjs_8_pwd_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_10_cat_code_bash(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_14_bash_code_bash(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_16_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_20_cat_code_bash_bash__dev_null(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_25___code_bash2(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_27___code_bash(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_31_ls__l_code_(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_35_chmod_u+x_code_bash(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_39___code_bash(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_43____GameScript_bash9_code_bash(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_55_echo___name(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_60_chemin__var_log(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_64_echo___chemin(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_67_ls___chemin(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_71_name_bob(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_74_echo___name(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_77_echo_mon_nom_est___name_(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_80_echo___nameby(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_84_echo___name__by(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_89_echo____name_by(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_91_echo______name_by__(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_94_echo_______name___name__(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_96_echo______name___name_(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_100_echo_____name_______name____ou___name__by_(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_107_printenv(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_110_printenv_PATH(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_116_type_date(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_119_date__bin_date(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_124_PATH___PATH____GameScript_bash9(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_128_echo___PATH(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_134_code_bash(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_136_cd_FOLDER(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_138_code_bash(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_140_pwd_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
async function launchGameScript_chapter_lecture() {

reset_GS();
document.getElementById('toggle_music').style.display='inline';
document.getElementById('toggle_voice').style.display='inline';
document.getElementById('button_print_passwords').style.display='none';
document.getElementById('GS_selects').style.display='none';
document.getElementById('button_start_lecture').style.display='none';
document.getElementById('button_start_quiz').value='Stop Lecture';
document.getElementById('button_start_quiz').onclick = function() { reset_GS(); };
toggle_music();
await new_line(5,"Bash peut être utilisé de manière interactive, comme nous le faisons depuis le chapitre 1, mais bash est aussi un langage de programmation.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(6,"Vous pouvez donc stocker toutes les commandes que vous avez apprises dans un fichier texte et demander à 'bash' de les lancer ligne par ligne.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(7,"Affichez votre répertoire courant et son contenu avec : " + learn + "pwd;ls" + reset + ".");
await interactive(8,"pwd;ls");
funcjs_8_pwd_ls();
new_line_no_wait(9,"Affichez le contenu du fichier 'code_bash'.");
await interactive(10,"cat code_bash");
funcjs_10_cat_code_bash();
await new_line(11,"Ce fichier 'code_bash' contient trois lignes de commande que vous devriez comprendre.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(12,"Pour lancez les commandes de ce fichier 'code_bash', il suffit de donner ce fichier en argument à la commande " + voc + "bash" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(13,"Faites donc : " + learn + "bash code_bash" + reset + "");
await interactive(14,"bash code_bash");
funcjs_14_bash_code_bash();
new_line_no_wait(15,"Listez les éléments du répertoire courant.");
await interactive(16,"ls");
funcjs_16_ls();
await new_line(17,"Ici 'bash' a bien créé le dossier 'FOLDER' avec la commande " + learn + "mkdir FOLDER" + reset + " contenu dans le fichier 'code_bash'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(18,"Vous pouvez aussi utiliser tous les autres concepts que vous avez déjà appris dans les chapitres précédents.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(19,"Faites par exemple : " + learn + "cat code_bash|bash>/dev/null" + reset + "");
await interactive(20,"cat code_bash|bash>/dev/null");
funcjs_20_cat_code_bash_bash__dev_null();
await new_line(21,"Ici seul l'erreur de " + code + "mkdir" + reset + " est envoyée dans le terminal, puisque les commandes " + code + "ls" + reset + " et " + code + "pwd" + reset + " utilisent la sortie standard.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(22,"Pour rappel, vous auriez pu également faire " + learn + "cat code_bash|bash -" + reset + " ou utiliser le chemin absolu de ce fichier, avec par exemple " + learn + "bash ~/.GameScript_bash9/code_bash" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(23,"Pour executer un fichier, vous pouvez aussi utiliser " + code + "./" + reset + " avant le nom du fichier que vous voulez lancer.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(24,"Faites donc : " + learn + "./code_bash2" + reset + "");
await interactive(25,"./code_bash2");
funcjs_25___code_bash2();
new_line_no_wait(26,"Faites la même chose pour 'code_bash'.");
await interactive(27,"./code_bash");
funcjs_27___code_bash();
await new_line(28,"Ici en utilisant " + code + "./" + reset + " nous avons un problème de permission.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(29,"Etrange puisque nous n'avons pas eu de soucis avec la commande " + learn + "bash code_bash" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(30,"Affichez les permissions de tous les éléments du répertoire courant qui commencent par 'code'.");
await interactive(31,"ls -l code*");
funcjs_31_ls__l_code_();
await new_line(32,"Pour pouvoir executer un fichier avec " + code + "./" + reset + ", ce fichier doit avoir le droit d'execution (x).");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(33,"Un fichier texte n'aura pas cette permission par défaut, vous devez donc l'ajouter manuellement.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(34,"Donnez le droit d'execution sur 'code_bash' pour le propriétaire de ce fichier.");
await interactive(35,"chmod u+x code_bash");
funcjs_35_chmod_u+x_code_bash();
await new_line(36,"On peut dire qu'au moment où un fichier texte devient executable, il se transforme en un " + voc + "script" + reset + " ou " + voc + "programme" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(37,"Autrement dit : " + voc + "Un script bash est un simple fichier texte contenant des commandes bash." + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(38,"Executez maintenant 'code_bash' en utilisant " + code + "./" + reset + ".");
await interactive(39,"./code_bash");
funcjs_39___code_bash();
await new_line(40,"Vous avez peut être remarqué que " + code + "./" + reset + " ne fait que remplacer votre répertoire courant.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(41,"C'est effectivement le cas, pour executer un fichier, il suffit de spécifier son chemin.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(42,"Vous pouvez également utiliser son chemin absolu, faites donc : " + learn + "~/.GameScript_bash9/code_bash" + reset + "");
await interactive(43,"~/.GameScript_bash9/code_bash");
funcjs_43____GameScript_bash9_code_bash();
await new_line(44,"Attention cependant lorsque vous utilisez le chemin absolu, les commandes du script utiliserons votre répertoire courant, " + voc + "pas" + reset + " le dossier où se trouve votre script.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(45,"Par exemple si vous êtes dans le dossier '/var' et que vous faites " + learn + "~/.GameScript_bash9/code_bash" + reset + ", la commande " + learn + "mkdir FOLDER" + reset + " voudra créer le dossier '/var/FOLDER'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(46,"Pour éviter toute surprise, je vous recommande d'utiliser le plus souvent possible, des chemins absolus dans vos scripts.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(47,"Dans les chapitres précédents nous avons vu que si vous voulez garder une trace d'une information, vous pouvez la stocker dans un fichier, comme par exemple " + code + "ls>fichier" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(48,"Si cette information n'a pas besoin d'être sauvegardée sur votre disque, nous avons vu qu'elle pouvait aussi être directement envoyée à une autre commande, comme par exemple " + code + "ls|wc" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(49,"Mais bash peut aussi mémoriser certaines informations sans avoir besoin de créer un nouveau fichier.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(50,"Bash est capable de les stocker dans ce que l'on appelle une " + voc + "variable" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(51,"Une variable est un nom symbolique qui est associé à une valeur.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(53,"Je viens de créer pour vous une variable qui porte le nom : 'name'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(54,"Afficher la valeur de cette variable avec : " + learn + "echo \$name" + reset + "");
await interactive(55,"echo \$name");
funcjs_55_echo___name();
await new_line(56,"Ce " + code + "\$" + reset + " précise que le texte qui suit est le nom d'une variable et qu'il ne faut pas l'afficher tel quel.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(57,"" + code + "echo name" + reset + " affichera bien évidemment le mot 'name' mais " + code + "echo \$name" + reset + " affichera la valeur de la variable 'name'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(58,"Pour créer une nouvelle variable, il faudra simplement utiliser le nom voulu, le symbole " + code + "=" + reset + " suivit de sa valeur.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(59,"Créons donc une nouvelle variable 'chemin' qui contiendra le texte '/var/log' avec : " + learn + "chemin=/var/log" + reset + ".");
await interactive(60,"chemin=/var/log");
funcjs_60_chemin__var_log();
await new_line(61,"Si votre commande contient des espaces, vous pouvez par exemple utiliser les délimiteurs " + learn + "\"" + reset + " et " + learn + "'" + reset + " que nous avons déjà vu avec la commande " + code + "echo" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(62,"" + learn + "chemin=/var/log" + reset + " est équivalent à " + learn + "chemin=\"/var/log\"" + reset + " et " + learn + "chemin='/var/log'" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(63,"Affichons maintenant le contenu de cette variable avec : " + learn + "echo \$chemin" + reset + "");
await interactive(64,"echo \$chemin");
funcjs_64_echo___chemin();
await new_line(65,"La commande " + code + "echo" + reset + " affiche simplement le contenu de cette variable, mais les variables peuvent être utilisés par toutes les commandes.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(66,"Affichez donc le contenu du dossier " + code + "/var/log" + reset + " avec : " + learn + "ls \$chemin" + reset + "");
await interactive(67,"ls \$chemin");
funcjs_67_ls___chemin();
await new_line(68,"Lorsque vous avez fait " + learn + "chemin=/var/log" + reset + ", comme la variable n'existait pas, elle a été créée.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(69,"Pour la modifier, la syntaxe est exactement la même.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(70,"Modifier le contenu de la variable 'name' avec : " + learn + "name=bob" + reset + "");
await interactive(71,"name=bob");
funcjs_71_name_bob();
await new_line(72,"Attention à ne pas faire " + codeError + "\$name=bob" + reset + ", le symbole " + code + "\$" + reset + " ne devra être utilisé " + voc + "que" + reset + " lors de l'utilisation de la variable, pas lors de sa modification.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(73,"Affichez maintenant le nouveau contenu de la variable 'name' avec : " + learn + "echo \$name" + reset + ".");
await interactive(74,"echo \$name");
funcjs_74_echo___name();
await new_line(75,"Ici la valeur 'bjornulf' n'existe plus, votre commande " + learn + "name=bob" + reset + " vient de la remplacer.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(76,"Vous pouvez également ajouter du texte à la commande " + code + "echo" + reset + ", avec par exemple : " + learn + "echo mon nom est \$name." + reset + "");
await interactive(77,"echo mon nom est \$name.");
funcjs_77_echo_mon_nom_est___name_();
await new_line(78,"Comme d'habitude, le '.' étant un caractère spécial, un espace n'est pas nécessaire.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(79,"Maintenant essayez par exemple de rajouter 'by' à la suite de cette variable, pour afficher 'bobby', avec : " + learn + "echo \$nameby" + reset + "");
await interactive(80,"echo \$nameby");
funcjs_80_echo___nameby();
await new_line(81,"Ici 'by' se mélange avec le nom de la variable, mais la variable 'nameby' n'existe pas, " + code + "echo" + reset + " affiche donc une chaine de caractère vide.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(82,"Pour remédier à ce problème, vous pouvez par exemple utiliser le caractère d'échappement après le nom de la variable, pour clairement séparer la prochaine lettre.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(83,"Essayez donc d'utiliser la variable 'name' et le caractère d'échappement pour afficher : 'bobby'.");
await interactive(84,"echo \$name\\by");
funcjs_84_echo___name__by();
await new_line(85,"Attention, vous ne pouvez utiliser le caractère d'échappement qu'en dehors des délimiteurs " + code + "'" + reset + " et " + code + "\"" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(86,"Car je vous le rappelle, le caractère d'échappement est utilisé avec les délimiteurs pour afficher des mises à la ligne, des tabulations. etc...");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(87,"Une autre possibilité est de définir une limite à votre nom de variable, en utilisant les " + code + "{}" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(88,"Essayez donc de faire : " + learn + "echo \${name}by" + reset + "");
await interactive(89,"echo \${name}by");
funcjs_89_echo____name_by();
new_line_no_wait(90,"Parfait, maintenant essayez : " + learn + "echo \"\${name}by\"" + reset + "");
await interactive(91,"echo \"\${name}by\"");
funcjs_91_echo______name_by__();
await new_line(92,"Pour afficher un " + code + "\$" + reset + ", il faudra simplement faire " + code + " \\$ " + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(93,"Faites donc : " + learn + "echo \"\\\$name=\$name\"" + reset + "");
await interactive(94,"echo \"\\\$name=\$name\"");
funcjs_94_echo_______name___name__();
new_line_no_wait(95,"Et enfin essayez : " + learn + "echo '\\\$name=\$name'" + reset + "");
await interactive(96,"echo '\\\$name=\$name'");
funcjs_96_echo______name___name_();
await new_line(97,"Ici le résultat est très différent ! Tous les caractères entre les " + code + "'" + reset + " sont affichés littéralement.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(98,"Les " + code + "'" + reset + " sont donc très utiles si vous avez besoin d'afficher des caractères qui pourraient avoir une autre signification.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(99,"Vous pouvez aussi utiliser tout en même temps, essayez : " + learn + "echo '\${name}='\"\$name. \"ou \$name\\\by." + reset + "");
await interactive(100,"echo '\${name}='\"\$name. \"ou \$name\\by.");
funcjs_100_echo_____name_______name____ou___name__by_();
await new_line(101,"Si vous comprenez parfaitement cette commande, vous avez tout compris.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(102,"Je le répète, la syntaxe de modification d'une variable est identique à celle de sa création.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(103,"Attention donc à ne pas modifier des variables importantes par erreur en pensant les créer.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(104,"N'hésitez pas à vérifier avec un " + code + "echo" + reset + " si une variable portant ce nom existe déjà.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(105,"Votre environnement possède des variables importantes, appelés " + voc + "variables d'environnement" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(106,"Affichez donc vos " + voc + "variables d'environnement" + reset + " avec : " + learn + "printenv" + reset + ".");
await interactive(107,"printenv");
funcjs_107_printenv();
await new_line(108,"Une des variables d'environnement les plus importante est 'PATH'. (l'anglais de chemin)");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(109,"Pour afficher uniquement la variable PATH, faites donc : " + learn + "printenv PATH" + reset + "");
await interactive(110,"printenv PATH");
funcjs_110_printenv_PATH();
await new_line(111,"'PATH' est une liste du chemin absolu de plusieurs dossiers que bash utilise pour simplifier les appels de commandes.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(112,"Ces dossiers sont sur une seule ligne et leurs chemins absolus sont séparés par des " + code + ":" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(113,"Si votre variable d'environnement 'PATH' est mal configurée, vous risquez de rencontrer des difficultés à lancer certaines commandes.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(114,"Des commandes que nous avons déjà vu ensemble sont en fait stockées dans un des dossiers de la variable 'PATH'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(115,"Par exemple, pour savoir où se trouve la commande " + code + "date" + reset + ", faites : " + learn + "type date" + reset + ".");
await interactive(116,"type date");
funcjs_116_type_date();
await new_line(117,"" + code + "type" + reset + " nous permet de comprendre que l'appel de la commande " + code + "date" + reset + " correspond en fait à " + code + "/bin/date" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(118,"Faites donc : " + learn + "date;/bin/date" + reset + ".");
await interactive(119,"date;/bin/date");
funcjs_119_date__bin_date();
await new_line(120,"Il est pour vous possible d'utiliser directement la commande " + code + "date" + reset + " au lieu de taper " + code + "/bin/date" + reset + ", car le chemin absolu '/bin' est dans votre variable 'PATH'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(121,"Attention donc à ne pas modifier accidentellement le contenu de la variable 'PATH', certaines commandes deviendraient inutilisables !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(122,"Pour ajouter du contenu à une variable, il suffit de rajouter son nom au début de la modification.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(123,"Par exemple, pour ajouter ':~/.GameScript_bash9' à la variable 'PATH' faites donc : " + learn + "PATH=\$PATH:~/.GameScript_bash9" + reset + "");
await interactive(124,"PATH=\$PATH:~/.GameScript_bash9");
funcjs_124_PATH___PATH____GameScript_bash9();
await new_line(125,"Ici " + code + "\$PATH" + reset + " est simplement traité comme une chaine de caractère, correspondant au contenu de la variable 'PATH'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(126,"Auquel on y ajoute à la suite la chaine de caractère ':~/.GameScript_bash9'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(127,"Affichez le nouveau contenu de la variable 'PATH'.");
await interactive(128,"echo \$PATH");
funcjs_128_echo___PATH();
await new_line(129,"Ici vous pouvez voir que '~/.GameScript_bash9' a bien été rajouté à la suite de l'ancienne version de 'PATH'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(130,"Mais les modifications que vous faites sur les variables sont valables " + voc + "uniquement" + reset + " pour la session de bash que vous utilisez actuellement.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(131,"Ouvrir un autre terminal " + voc + "réinitialisera" + reset + " les variables importantes, comme par exemple 'PATH', et " + voc + "supprimera" + reset + " les autres, comme ici les variables 'name' et 'chemin'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(132,"Mais pour l'instant, puisque le dossier '~/.GameScript_bash9' est dans votre variable d'environnement 'PATH', vous pouvez simplement lancer le script 'code_bash' en tapant 'code_bash'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(133,"Lancez donc 'code_bash'.");
await interactive(134,"code_bash");
funcjs_134_code_bash();
new_line_no_wait(135,"Déplacez vous dans le dossier 'FOLDER'.");
await interactive(136,"cd FOLDER");
funcjs_136_cd_FOLDER();
new_line_no_wait(137,"Lancez 'code_bash' à nouveau.");
await interactive(138,"code_bash");
funcjs_138_code_bash();
new_line_no_wait(139,"Maintenant faites donc : " + learn + "pwd;ls" + reset + ".");
await interactive(140,"pwd;ls");
funcjs_140_pwd_ls();
await new_line(141,"Ici vous devriez comprendre clairement les effets des chemins relatifs dans vos scripts dont je vous ai parlé auparavant.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(142,"Et on termine par le questionnaire !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
launchGameScript_chapter_quiz();
}
async function launchGameScript_chapter_quiz() {
reset_GS();
intro_quiz_message();
document.getElementById('button_print_passwords').style.display='none';
document.getElementById('GS_selects').style.display='none';
document.getElementById('toggle_music_quiz').style.display='inline';
document.getElementById('button_start_quiz').style.display='none';
document.getElementById('button_start_lecture').value='Stop Quiz';
document.getElementById('button_start_lecture').onclick = function() { reset_GS(); }
toggle_music_quiz();
GOOD=1;
if(GOOD){ GOOD=await quiz("1","Comment afficher le contenu de la variable 'PATH' ?","echo $PATH"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("2","Comment ajouter ':/bin' à la fin de la variable 'PATH' ?","PATH=$PATH:/bin"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("3","En utilisant le caractère d'échappement, comment ajouter la lettre 'x' à la fin de la variable 'phrase' ?","phrase=$phrase\\x"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("4","Comment afficher vos variables d'environnement ?","printenv"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("5","Comment afficher le chemin absolu du fichier utilisé par la commande 'date' ?","type date"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("6","Si vous executez le script bash '/scripts/sc' dans le dossier '/var/' et que ce script contient le code 'rm f', quel est le chemin absolu du fichier que 'bash' voudra supprimer ?","/var/f"); } else { error_quiz_message(); return; }
P1="6521";
P2="ddd2";
await ask_username(P1,P2,WHOAMI,SUBJECT,CHAPTER);
}
LINES=142
setTimeout(function(){ download_audio_chapter(WHOAMI,'fr','classic','bash','m1','9'); }, 2000);
if(VIDEO) download_video_chapter(WHOAMI,'fr','classic','bash','m1','9');
