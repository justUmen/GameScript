function funcjs_7_echo_bonjour_test(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_9_mkdir_DIR(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_11_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_15_mv_test_DIR(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_17_ls_DIR(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_19_cd_DIR(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_21_pwd(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_23_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_33_mv_test_test2(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_35_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_37_cat_test2(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_40_mkdir_DOS(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_44_mv_DOS_DOS2(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_46_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_50_mv_test2_DOS2_test3(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_52_ls_DOS2(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_55_cat_DOS2_test3(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_61_echo__n_bonjour_DOS2_test3(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_63_echo____tout_le_monde____DOS2_test3(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_65_cat_DOS2_test3(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_77_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_79_cp_DOS2_test3__(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_82_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_85_cp_DOS2_test3__new(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_87_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_92_ls__a(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_97_echo_a_echo_b(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_99_cd_DOS_mkdir_NEW(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_101_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_108_rmdir_NEW(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_110_cd_DOS__mkdir_NEW(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_112_ls(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_120_lss__echo_test(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_122_lss__echo_test(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_125_cd_DOS__echo_SUCCESS__echo_ERROR(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_128_cd_DOS2__ls__pwd(){
GS_text.innerHTML += `<hr>
<hr>`;}
async function launchGameScript_chapter_lecture() {

reset_GS();
document.getElementById('toggle_music').style.display='inline';
document.getElementById('toggle_voice').style.display='inline';
document.getElementById('button_print_passwords').style.display='none';
document.getElementById('GS_selects').style.display='none';
document.getElementById('button_start_lecture').style.display='none';
document.getElementById('button_start_quiz').value='Stop Lecture';
document.getElementById('button_start_quiz').onclick = function() { reset_GS(); };
toggle_music();
await new_line(4,"Dans le chapitre précédent, nous avons vu comment créer et modifier les fichiers textes.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(5,"Ici nous allons continuer avec d'autres types de contrôles.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(6,"Commençons par créer un nouveau fichier 'test' avec comme contenu le mot 'bonjour'.");
await interactive(7,"echo bonjour>test");
funcjs_7_echo_bonjour_test();
new_line_no_wait(8,"Créez un nouveau dossier nommé 'DIR'.");
await interactive(9,"mkdir DIR");
funcjs_9_mkdir_DIR();
new_line_no_wait(10,"Affichez les éléments du répertoire courant.");
await interactive(11,"ls");
funcjs_11_ls();
await new_line(12,"Pour déplacer un fichier il faudra utiliser la commande " + code + "mv" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(13,"'m' et 'v' sont les consonnes de 'move', le mot anglais pour 'déplacer'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(14,"Déplacez donc ce fichier 'test' dans le dossier DIR avec la commande : " + learn + "mv test DIR" + reset + "");
await interactive(15,"mv test DIR");
funcjs_15_mv_test_DIR();
new_line_no_wait(16,"Affichez les éléments du dossier 'DIR'.");
await interactive(17,"ls DIR");
funcjs_17_ls_DIR();
new_line_no_wait(18,"Déplacez votre terminal dans le dossier 'DIR'.");
await interactive(19,"cd DIR");
funcjs_19_cd_DIR();
new_line_no_wait(20,"Affichez le chemin absolu du répertoire courant.");
await interactive(21,"pwd");
funcjs_21_pwd();
new_line_no_wait(22,"Affichez les éléments du répertoire courant.");
await interactive(23,"ls");
funcjs_23_ls();
await new_line(24,"Ici le fichier 'test' a bien été déplacé dans le répertoire 'DIR' avec cette commande : " + learn + "mv test DIR" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(25,"Dans cet exemple, notre premier argument est un fichier et le second est un dossier.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(26,"Comme le deuxième argument est un dossier, la commande aurait pu être : " + learn + "mv test DIR/" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(27,"Cette version est nettement plus lisible que la première.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(28,"Parce que " + code + "mv" + reset + " peut avoir indifféremment en arguments des fichiers ou des dossiers.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(29,"Mais si le premier argument est un fichier et que le deuxième n'est pas un dossier, la commande agira différemment : cette fois le premier argument sera " + voc + "renommé" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(30,"Attention donc à bien comprendre votre environnement.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(31,"Dans votre répertoire courant vous avez toujours ce fichier 'test'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(32,"Utilisez cette commande pour renommer 'test' en 'test2' : " + learn + "mv test test2" + reset + "");
await interactive(33,"mv test test2");
funcjs_33_mv_test_test2();
new_line_no_wait(34,"Affichez les éléments du répertoire courant.");
await interactive(35,"ls");
funcjs_35_ls();
new_line_no_wait(36,"Affichez le contenu du fichier 'test2'.");
await interactive(37,"cat test2");
funcjs_37_cat_test2();
await new_line(38,"Le contenu est bien toujours le même, seul le nom du fichier à changé.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(39,"Maintenant créez un nouveau dossier nommé : 'DOS'.");
await interactive(40,"mkdir DOS");
funcjs_40_mkdir_DOS();
await new_line(41,"Je le répète, " + code + "mv" + reset + " peut avoir indifféremment en arguments des fichiers ou des dossiers.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(42,"C'est à dire que si le premier argument est un dossier, et que le second n'existe pas, " + code + "mv" + reset + " va encore une fois simplement renommer le dossier en argument.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(43,"Renommez donc ce dossier 'DOS' en 'DOS2'.");
await interactive(44,"mv DOS DOS2");
funcjs_44_mv_DOS_DOS2();
new_line_no_wait(45,"Et affichez les éléments du répertoire courant.");
await interactive(46,"ls");
funcjs_46_ls();
await new_line(47,"Attention donc à la commande " + code + "mv" + reset + " qui peut avoir deux rôles différents : déplacer et renommer.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(48,"" + code + "mv" + reset + " peut également faire les deux en une seule commande.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(49,"Déplacez 'test2' dans le dossier 'DOS2' et renommez le en 'test3' avec : " + learn + "mv test2 DOS2/test3" + reset + "");
await interactive(50,"mv test2 DOS2/test3");
funcjs_50_mv_test2_DOS2_test3();
new_line_no_wait(51,"Affichez les éléments du répertoire DOS2.");
await interactive(52,"ls DOS2");
funcjs_52_ls_DOS2();
await new_line(53,"Le fichier 'test2' a bien été déplacé dans DOS2 et renommé en 'test3'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(54,"Affichez le contenu de ce fichier 'test3'.");
await interactive(55,"cat DOS2/test3");
funcjs_55_cat_DOS2_test3();
await new_line(56,"Le contenu est toujours identique.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(57,"Si vous ajoutez le texte 'tout le monde' à la suite de ce fichier, le texte sera ajouté sur une nouvelle ligne.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(58,"Parce que lorsque vous utilisez " + code + "echo" + reset + ", il ajoutera par défaut une mise à la ligne à la fin.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(59,"Si vous ne voulez pas de cette mise à la ligne, il faudra utiliser l'option " + learn + "-n" + reset + " de la commande " + code + "echo" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(60,"Remplacez donc le contenu du fichier 'test3' par 'bonjour', mais sans ce retour à la ligne automatique à la fin.");
await interactive(61,"echo -n bonjour>DOS2/test3");
funcjs_61_echo__n_bonjour_DOS2_test3();
new_line_no_wait(62,"Maintenant ajoutez le texte ' tout le monde' à ce fichier 'test3', en utilisant " + learn + "\"" + reset + ".");
await interactive(63,"echo \" tout le monde\">>DOS2/test3");
funcjs_63_echo____tout_le_monde____DOS2_test3();
new_line_no_wait(64,"Et enfin, affichez le contenu de 'test3'.");
await interactive(65,"cat DOS2/test3");
funcjs_65_cat_DOS2_test3();
await new_line(66,"Et voilà, bonjour tout le monde !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(67,"Quand une commande ne fait pas exactement ce que voulez qu'elle fasse, visitez son manuel !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(68,"Il est très probable qu'une simple option soit la réponse à votre problème.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(69,"" + code + "mv" + reset + " utilise deux arguments, le premier est la " + voc + "<SOURCE>" + reset + " et le deuxième est la " + voc + "<DESTINATION>" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(70,"Et la syntaxe comme on l'a déjà vu est : " + code + "mv <SOURCE> <DESTINATION>" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(71,"" + voc + "<SOURCE>" + reset + " et " + voc + "<DESTINATION>" + reset + " sont à remplacer par les fichiers ou les dossiers voulus.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(72,"Lorsqu'une commande a besoin de deux arguments, la plupart du temps cette logique s'applique.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(73,"Le premier argument est la " + voc + "source" + reset + ", le second est la " + voc + "destination" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(74,"Pour " + voc + "copier" + reset + " ou " + voc + "dupliquer" + reset + " un fichier, il faudra utiliser la commande " + code + "cp" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(75,"Son comportement est sensiblement identique à " + code + "mv" + reset + ", sauf que le fichier " + voc + "<SOURCE>" + reset + " ne sera pas supprimé.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(76,"Affichez les éléments du répertoire courant.");
await interactive(77,"ls");
funcjs_77_ls();
new_line_no_wait(78,"Copiez donc le fichier 'test3' dans votre répertoire courant.");
await interactive(79,"cp DOS2/test3 .");
funcjs_79_cp_DOS2_test3__();
await new_line(80,"Et ici nous avons notre première utilisation pratique du " + code + "." + reset + ", qui je vous le rappelle représente le répertoire courant.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(81,"Listez à nouveau les éléments du répertoire courant.");
await interactive(82,"ls");
funcjs_82_ls();
await new_line(83,"Encore une fois " + code + "." + reset + " étant un dossier, vous pouvez également utiliser " + code + "./" + reset + " à la place.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(84,"Maintenant testez cette commande : " + learn + "cp DOS2/test3 .new" + reset + "");
await interactive(85,"cp DOS2/test3 .new");
funcjs_85_cp_DOS2_test3__new();
new_line_no_wait(86,"Puis listez les éléments du répertoire courant.");
await interactive(87,"ls");
funcjs_87_ls();
await new_line(88,"Ce résultat ne devrait pas vous choquer.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(89,"Encore une fois, " + code + ".new" + reset + " et " + code + "./new" + reset + " représentent deux choses différentes.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(90,"" + code + ".new" + reset + " est bien évidemment un fichier caché.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(91,"Listez les fichiers cachés du répertoire courant.");
await interactive(92,"ls -a");
funcjs_92_ls__a();
await new_line(93,"Si vous voulez copier le fichier 'test3' et renommer cette copie en 'new' dans le répertoire courant, la commande serait : " + learn + "cp DOS2/test3 ./new" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(94,"Ici la commande " + learn + "cp DOS2/test3 .new" + reset + " est identique à " + learn + "cp DOS2/test3 ./.new" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(95,"Il est aussi possible d'avoir plusieures commandes sur une seule ligne, il suffit de les séparer par des " + code + ";" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(96,"Essayez donc d'afficher 'a', puis sur une autre ligne 'b'. Avec deux commandes et un " + code + ";" + reset + ".");
await interactive(97,"echo a;echo b");
funcjs_97_echo_a_echo_b();
new_line_no_wait(98,"Maintenant, essayez de vous déplacer dans le dossier DOS et de créer un dossier NEW à l'intérieur.");
await interactive(99,"cd DOS;mkdir NEW");
funcjs_99_cd_DOS_mkdir_NEW();
new_line_no_wait(100,"Listez les éléments de votre répertoire courant.");
await interactive(101,"ls");
funcjs_101_ls();
await new_line(102,"Avec " + code + ";" + reset + ", quel que soit le résultat de la première commande, la deuxième se lancera.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(103,"Ici le dossier 'DOS' n'existait pas, pourtant la commande " + learn + "mkdir NEW" + reset + " a été lancée dans " + code + "." + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(104,"Le " + code + ";" + reset + " ne donne aucun contrôle sur l'état des commandes précédentes.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(105,"Mais vous pouvez aussi créer des conditions avant de passer à la prochaine commande.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(106,"Si vous voulez que la deuxième commande s'exécute uniquement si la première a été un succès, vous pouvez utiliser " + code + "&&" + reset + " à la place du " + code + ";" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(107,"Commencez par supprimer ce dossier NEW, que nous avons créé par erreur dans le mauvais répertoire.");
await interactive(108,"rmdir NEW");
funcjs_108_rmdir_NEW();
new_line_no_wait(109,"Maintenant, pour créer un dossier NEW dans DOS, essayez : " + learn + "cd DOS&&mkdir NEW" + reset + "");
await interactive(110,"cd DOS&&mkdir NEW");
funcjs_110_cd_DOS__mkdir_NEW();
new_line_no_wait(111,"Listez les éléments de votre répertoire courant.");
await interactive(112,"ls");
funcjs_112_ls();
await new_line(113,"La commande " + learn + "cd DOS" + reset + " renvoyant une erreur, " + code + "&&" + reset + " a bloqué le lancement de la prochaine commande.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(114,"Cette technique est particulièrement importante si vous utilisez des commandes " + voc + "destructrices" + reset + ", comme " + code + "rm" + reset + ", ou " + code + "echo" + reset + " avec le " + code + ">" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(115,"Si vous ne prenez pas de précaution, vous risquez de supprimer accidentellement un fichier important.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(116,"Il est possible d'utiliser " + code + ";" + reset + " et " + code + "&&" + reset + " avec toutes les commandes que vous connaissez déjà.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(117,"Mais il existe une autre syntaxe : " + code + "||" + reset + ", qui fait l'inverse de " + code + "&&" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(118,"C'est à dire que la prochaine commande ne se lancera que si la précédente est un échec.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(119,"Essayez donc avec une faute de frappe la commande : " + learn + "lss||echo test" + reset + "");
await interactive(120,"lss||echo test");
funcjs_120_lss__echo_test();
new_line_no_wait(121,"Essayez la même commande, cette fois avec " + code + "&&" + reset + " : " + learn + "lss&&echo test" + reset + "");
await interactive(122,"lss&&echo test");
funcjs_122_lss__echo_test();
await new_line(123,"Mais il est aussi possible d'avoir les deux conditions sur une seule ligne.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(124,"Essayez cette commande : " + learn + "cd DOS&&echo SUCCESS||echo ERROR" + reset + "");
await interactive(125,"cd DOS&&echo SUCCESS||echo ERROR");
funcjs_125_cd_DOS__echo_SUCCESS__echo_ERROR();
await new_line(126,"Si vous savez déjà programmer, cette commande peut être vu comme une condition de programmation if/else.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(127,"Ici le dossier 'DOS' n'existe pas, utilisez donc DOS2 avec cette commande : " + learn + "cd DOS2&&ls||pwd" + reset + "");
await interactive(128,"cd DOS2&&ls||pwd");
funcjs_128_cd_DOS2__ls__pwd();
await new_line(129,"Comme le dossier 'DOS2' existe, la commande " + learn + "pwd" + reset + ", ne sera pas exécutée.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(130,"Vous êtes prêt pour le questionnaire !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
launchGameScript_chapter_quiz();
}
async function launchGameScript_chapter_quiz() {
reset_GS();
intro_quiz_message();
document.getElementById('button_print_passwords').style.display='none';
document.getElementById('GS_selects').style.display='none';
document.getElementById('toggle_music_quiz').style.display='inline';
document.getElementById('button_start_quiz').style.display='none';
document.getElementById('button_start_lecture').value='Stop Quiz';
document.getElementById('button_start_lecture').onclick = function() { reset_GS(); }
toggle_music_quiz();
GOOD=1;
if(GOOD){ GOOD=await quiz("1","Quelle est la commande pour déplacer des fichiers ou dossiers ?","mv"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("2","Quelle est la commande pour renommer des fichiers ou dossiers ?","mv"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("3","Comment renommer un fichier nommé 'oui' dans votre répertoire courant en 'non' et le déplacer dans son répertoire parent ?","mv oui ../non"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("4","Comment copier dans votre répertoire courant un fichier dont le chemin absolu est '/root/file' ?","cp /root/file ."); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("5","Comment copier un fichier caché '.file' situé dans votre répertoire parent et le renommer en un fichier non caché 'file' dans le dossier '/root' ?","cp ../.file /root/file"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("6","Quel symbole doit être utilisé pour séparer simplement deux commandes sur une même ligne ?",";"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("7","Comment exécuter la commande 'rm file' uniquement si la commande précédente 'cd /root' est un succès ?","cd /root&&rm file"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("8","Comment afficher 'good' si la commande 'cd /root' est un succès, et 'bad' sinon ?","cd /root&&echo good||echo bad"); } else { error_quiz_message(); return; }
P1="a9d1";
P2="21af";
await ask_username(P1,P2,WHOAMI,SUBJECT,CHAPTER);
}
LINES=130
setTimeout(function(){ download_audio_chapter(WHOAMI,'fr','classic','bash','m1','4'); }, 2000);
if(VIDEO) download_video_chapter(WHOAMI,'fr','classic','bash','m1','4');
