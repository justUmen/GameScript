function funcjs_6_ls__l(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_11_chmod_u+rw_f1_f2__ls__l(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_19_chmod_u+rw____ls__l(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_25_cat__(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_35_ls_f_(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_38_ls__0(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_41_ls__l__0__s(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_43_ls__l_i_s(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_49_ls__l_f_(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_52_ls__l_f__(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_54_ls__l_f(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_58_ls_f_(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_62_ls__l__(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_67_cat_f(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_70_ls__l_f(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_91_touch_f(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_93_ls__l(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_96_date(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_99_cat_intrus(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_101_ls__l_intrus(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_117_chmod_644___(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_119_ls__l(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_131_chown_root_f(){
GS_text.innerHTML += `<hr>
<hr>`;}
async function launchGameScript_chapter_lecture() {

reset_GS();
document.getElementById('toggle_music').style.display='inline';
document.getElementById('toggle_voice').style.display='inline';
document.getElementById('button_print_passwords').style.display='none';
document.getElementById('GS_selects').style.display='none';
document.getElementById('button_start_lecture').style.display='none';
document.getElementById('button_start_quiz').value='Stop Lecture';
document.getElementById('button_start_quiz').onclick = function() { reset_GS(); };
toggle_music();
new_line_no_wait(5,"Commençons par évaluer notre situation avec un : " + learn + "ls -l" + reset + "");
await interactive(6,"ls -l");
funcjs_6_ls__l();
await new_line(7,"Nous avons ici quelques problèmes de permission à régler...");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(8,"Nous voulons rajouter le droit de lecture et d'écriture pour le propriétaire sur tous les éléments du répertoire courant.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(9,"Il est possible de mettre tous les noms les uns à la suite des autres avec " + code + "chmod" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(10,"Faites le donc pour 'f1' et 'f2', puis réaffichez les nouvelles permissions si la commande est un succès.");
await interactive(11,"chmod u+rw f1 f2&&ls -l");
funcjs_11_chmod_u+rw_f1_f2__ls__l();
await new_line(12,"Taper tous les noms de fichiers est finalement particulièrement rébarbatif, surtout si vous avez un grand nombre de fichiers à changer.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(13,"Dans ce chapitre nous allons ajouter de nouveaux caractères spéciaux à notre arsenal !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(14,"Le premier que nous allons voir est : " + code + "*" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(15,"" + code + "*" + reset + " est un symbole très puissant, on l'appelle un " + voc + "joker" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(16,"" + code + "*" + reset + " peut être utilisée pour remplacer tous les éléments d'un répertoire.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(17,"C'est à dire qu'au lieu d'avoir à taper tous les noms les uns à la suite des autres, vous avez juste à mettre une " + code + "*" + reset + " à la place.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(18,"Ajoutez donc le droit de lecture et d'écriture pour le propriétaire sur tous les éléments du répertoire courant, puis réaffichez les nouvelles permissions si la commande est un succès.");
await interactive(19,"chmod u+rw *&&ls -l");
funcjs_19_chmod_u+rw____ls__l();
await new_line(20,"Si " + code + "*" + reset + " est utilisée seule, le répertoire en question est bien évidemment le répertoire courant : " + code + "*" + reset + " = " + code + "./*" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(21,"Mais " + code + "*" + reset + " peut être utilisée avec n'importe quel chemin, par exemple : " + code + "/*" + reset + " représente tous les éléments du répertoire racine.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(22,"Ici nous avons finalement résolu tous nos problèmes de permissions en une seule commande !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(23,"Mais " + code + "*" + reset + " peut aussi être utilisée avec les autres commandes.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(24,"Affichez donc le contenu de tous les fichiers du répertoire courant les uns à la suite des autres.");
await interactive(25,"cat *");
funcjs_25_cat__();
await new_line(26,"L'ordre d'affichage est " + voc + "alphabétique" + reset + ", exactement comme le résultat de " + code + "ls" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(27,"Notez que 'f10' est placé avant 'f2', car l'affichage par défaut est " + voc + "alphabétique" + reset + " et non pas " + voc + "numérique" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(28,"Si l'affichage numérique vous intéresse, vous auriez pu trouver facilement l'option " + code + "-v" + reset + " dans le manuel de " + code + "ls" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(29,"" + code + "*" + reset + " peut donc représenter tous les éléments d'un répertoire.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(30,"Mais que fait-elle exactement pour avoir cet effet ?");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(31,"" + code + "*" + reset + " peut en fait remplacer une chaine de caractère quelconque.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(32,"Si elle est utilisée seule, elle représente donc tous les fichiers qui ont un nom quelconque...");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(33,"Mais il est aussi possible de limiter ce qu'elle représente en y ajoutant des caractères.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(34,"Par exemple, vous pouvez afficher tous les éléments du répertoire courant qui commence par un 'f' avec : " + learn + "ls f*" + reset + "");
await interactive(35,"ls f*");
funcjs_35_ls_f_();
await new_line(36,"Ici le fichier 'intrus' n'est pas présent car son nom ne commence pas par un 'f'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(37,"Affichez tous les éléments du répertoire courant qui se terminent par un 0 avec : " + learn + "ls *0" + reset + "");
await interactive(38,"ls *0");
funcjs_38_ls__0();
await new_line(39,"La commande " + code + "ls" + reset + " accepte aussi plusieurs arguments, vous pouvez donc cumuler les syntaxes.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(40,"Essayez par exemple de lister les permissions de tous les éléments du répertoire courant qui finissent soit par un 0, soit par un s.");
await interactive(41,"ls -l *0 *s");
funcjs_41_ls__l__0__s();
new_line_no_wait(42,"Lister maintenant toutes les permissions des éléments du répertoire courant qui commencent par un 'i' et finissent par un 's'.");
await interactive(43,"ls -l i*s");
funcjs_43_ls__l_i_s();
await new_line(44,"Avec " + code + "i*s" + reset + ", seul le fichier 'intrus' rentre dans les critères de sélection.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(45,"Dans le cas de ce fichier 'intrus', " + code + "*" + reset + " remplacera la chaine de caractère 'ntru'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(46,"Si vous avez besoin d'un ciblage plus en finesse, vous pouvez utiliser un autre " + voc + "joker" + reset + " : le " + code + "?" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(47,"" + code + "?" + reset + " ne remplace lui qu'" + voc + "un" + reset + " seul caractère !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(48,"Essayer donc cette commande : " + learn + "ls -l f?" + reset + "");
await interactive(49,"ls -l f?");
funcjs_49_ls__l_f_();
await new_line(50,"Ici 'f10' et 'f50' ne s'affichent pas, car il y a deux caractères après la lettre f.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(51,"Affichez donc ces deux fichiers, en faisant : " + learn + "ls -l f??" + reset + "");
await interactive(52,"ls -l f??");
funcjs_52_ls__l_f__();
new_line_no_wait(53,"Mais qu'en est-il du fichier 'f' ? Affichez donc ses permissions.");
await interactive(54,"ls -l f");
funcjs_54_ls__l_f();
await new_line(55,"Le fichier 'f' existe bel et bien, mais ne s'est pas affiché lors de nos dernières commandes avec " + code + "?" + reset + "...");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(56,"" + code + "?" + reset + " remplace exactement " + code + "un" + reset + " caractère, ni plus, ni moins.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(57,"Essayez donc avec : ls " + learn + "f*" + reset + "");
await interactive(58,"ls f*");
funcjs_58_ls_f_();
await new_line(59,"Ici même s'il n'y a aucun caractère après le f, le fichier 'f' s'affiche.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(60,"C'est tout simplement parce que " + code + "*" + reset + " peut aussi représenter une chaine de caractère vide !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(61,"Pour afficher les permissions de tous les fichiers avec un nom d'une lettre, vous pouvez utiliser : " + learn + "ls -l ?" + reset + "");
await interactive(62,"ls -l ?");
funcjs_62_ls__l__();
await new_line(63,"Ici 'f' est notre seul fichier avec un nom d'une lettre.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(64,"Attention donc lorsque vous utilisez ces " + voc + "jokers" + reset + ", surtout avec des commandes " + voc + "destructrices" + reset + " !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(65,"Une commande comme " + learn + "rm *" + reset + " peut avoir de graves conséquences.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(66,"Maintenant que ces deux nouveaux symboles sont acquis, affichez le contenu du fichier 'f'.");
await interactive(67,"cat f");
funcjs_67_cat_f();
await new_line(68,"Lorque vous utilisez la commande " + code + "cat" + reset + " vous affichez en fait les " + voc + "données" + reset + " du fichier 'f'. (data en anglais)");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(69,"Affichez maintenant les résultats de " + learn + "ls -l f" + reset + ".");
await interactive(70,"ls -l f");
funcjs_70_ls__l_f();
await new_line(71,"Les informations qui s'affichent ici sont les " + voc + "métadonnées" + reset + " du fichier 'f'. (metadata en anglais)");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(72,"Les " + voc + "métadonnées" + reset + " sont des informations sur des données !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(73,"" + learn + "ls -l" + reset + " vous affiche donc des " + voc + "métadonnées" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(74,"Prenons cet exemple : -rw------- 1 umen team 10 Feb 20 16:16 f");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(75,"Dans cet affichage, il y a en fait 7 colonnes.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(76,"" + codeFile + "-rw-------" + reset + " 1 umen team 10 Feb 20 16:16 f : Vous connaissez déjà la première colonne, il s'agit du type de l'élément et de ses permissions.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(77,"-rw------- " + codeFile + "1" + reset + " umen team 10 Feb 20 16:16 f : La deuxième colonne est un nombre qui compte le nombre de liens ou de répertoires dans un élément.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(78,"Mais nous reviendrons sur ce nombre dans un autre chapitre, ignorez le pour le moment.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(79,"-rw------- 1 " + codeFile + "umen" + reset + " team 10 Feb 20 16:16 f : La troisième colonne est je le rappelle le nom du propriétaire.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(80,"-rw------- 1 umen " + codeFile + "team" + reset + " 10 Feb 20 16:16 f : La quatrième colonne est je le rappelle le nom du groupe.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(81,"-rw------- 1 umen team " + codeFile + "10" + reset + " Feb 20 16:16 f : La cinquième colonne est la " + voc + "taille" + reset + " en " + voc + "octet" + reset + " du fichier. (octect = byte en anglais)");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(82,"Pour rappel : un octet est égal à 8 bits. Et un bit ne peut avoir que deux valeurs, 0 ou 1.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(83,"Ce fichier de 10 octets fait donc 80 bits !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(84,"Pour information, le contenu de notre fichier 'f' est égal en binaire à ça : 01100011 01101111 01101110 01110100 01100101 01101110 01110101 00100000 01100110 00001010");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(85,"-rw------- 1 umen team 10 " + codeFile + "Feb 20 16:16" + reset + " f : La sixième colonne est la date de la dernière modification du fichier.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(86,"-rw------- 1 umen team 10 Feb 20 16:16 " + codeFile + "f" + reset + " : Et la dernière colonne est simplement le nom du fichier.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(87,"Dans le chapitre précédent, vous aviez déjà utilisé la commande " + code + "touch" + reset + " pour créer un fichier.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(88,"Effectivement, avec " + code + "touch" + reset + ", si le fichier donné en argument n'existe pas il sera créé.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(89,"Mais le but premier de cette commande est de changer cette métadonnée de dernière modification. -rw------- 1 umen team 10 " + codeFile + "Feb 20 16:16" + reset + " f");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(90,"Pour actualisez la date de dernière modification de 'f' faites : " + learn + "touch f" + reset + "");
await interactive(91,"touch f");
funcjs_91_touch_f();
new_line_no_wait(92,"Faites donc maintenant : " + learn + "ls -l" + reset + "");
await interactive(93,"ls -l");
funcjs_93_ls__l();
await new_line(94,"La date de dernière modification de 'f' est effectivement la plus récente.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(95,"Pour afficher la date du moment il suffit de lancer la commande : " + learn + "date" + reset + "");
await interactive(96,"date");
funcjs_96_date();
await new_line(97,"La commande " + code + "touch" + reset + " a donc bien eu son effet.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(98,"Affichez maintenant le contenu du fichier 'intrus'.");
await interactive(99,"cat intrus");
funcjs_99_cat_intrus();
new_line_no_wait(100,"Lancez enfin : " + learn + "ls -l intrus" + reset + "");
await interactive(101,"ls -l intrus");
funcjs_101_ls__l_intrus();
await new_line(102,"La date ici n'a pas changé, malgré l'utilisation de la commande " + code + "cat" + reset + " sur ce fichier.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(103,"Sans autre options, " + learn + "ls -l" + reset + " affiche la dernière date de " + voc + "modification" + reset + ", pas la dernière date " + voc + "d'accès" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(104,"Et évidemment, " + code + "cat" + reset + " ne fait qu'afficher le fichier sans le modifier, donc la date ne change pas.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(105,"Et maintenant nous allons revenir rapidement sur les permissions, en particulier sur la commande " + code + "chmod" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(106,"Nous avons déjà vu comment utiliser " + code + "chmod" + reset + " avec des lettres : r, w, x, u, g, o.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(107,"Mais il est aussi possible d'utiliser " + code + "chmod" + reset + " avec 3 chiffres !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(108,"A chaque lettre correspond une valeur numérique, la lettre 'r' sera 4, 'w' sera 2 et 'x' sera 1.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(109,"Il faudra ensuite faire l'addition des permissions, 'rw-' sera donc 4+2=" + voc + "6" + reset + ", 'r-x' sera 4+1=" + voc + "5" + reset + ", 'r--' sera " + voc + "4" + reset + ", 'rwx' sera 4+2+1=" + voc + "7" + reset + ", '---' sera bien évidemment " + voc + "0" + reset + ", etc...");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(110,"Vous devez utiliser trois de ces sommes pour respectivement : le propriétaire, le groupe et les autres.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(111,"Par exemple, sur le fichier 'test', pour donner tous les droits au propriétaire mais aucun au reste, il faudra faire " + learn + "chmod 700 test" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(112,"" + codeFile + "7" + reset + "00 donne toutes les permissions au propriétaire : " + codeFile + "rwx" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(113,"7" + codeFile + "0" + reset + "0 ne donne aucune permission au groupe : " + codeFile + "---" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(114,"70" + codeFile + "0" + reset + " ne donne aucune permission aux autres : " + codeFile + "---" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(115,"" + codeFile + "700" + reset + " est donc équivalent à " + codeFile + "rwx------" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(116,"Donnez donc les droits rw-r--r-- à tous les éléments de deux lettres du répertoire courant, en utilisant chmod et ses chiffres.");
await interactive(117,"chmod 644 ??");
funcjs_117_chmod_644___();
new_line_no_wait(118,"Voyons le résultat avec : " + learn + "ls -l" + reset + "");
await interactive(119,"ls -l");
funcjs_119_ls__l();
await new_line(120,"Vous avez peut être remarqué que la commande " + learn + "chmod 644 ??" + reset + " n'a pas d'équivalent avec des lettres.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(121,"Ou plutôt qu'il faut plusieures commandes pour avoir le même effet.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(122,"Il faudra d'abord réinitialiser toutes les permissions à 0 avec " + learn + "chmod ugo-rwx ??" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(123,"Ensuite " + learn + "chmod ugo+r ??" + reset + " pour faire l'équivalent de " + learn + "chmod 444 ??" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(124,"Et il faudra ensuite transformer " + code + "444" + reset + " en " + code + "644" + reset + " avec " + learn + "chmod u+w ??" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(125,"Cependant l'inverse n'est pas du tout possible, " + code + "u+w" + reset + " n'a pas d'équivalent en chiffre, parce que le résultat dépendra des permissions précédentes.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(126,"Les deux méthodes ne sont pas pas équivalentes !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(127,"Ca sera donc à vous de choisir quelle méthode vous souhaitez utiliser, en fonction de votre situation.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(128,"Et pour en terminer avec les bases sur les permissions, nous allons voir comment changer de propriétaire et de groupe.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(129,"La commande à utiliser sera : " + code + "chown" + reset + ", abréviation anglaise de : " + code + "ch" + reset + "ange " + code + "own" + reset + "er.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(130,"Pour mettre " + voc + "root" + reset + " comme propriétaire du fichier 'f' vous pouvez simplement taper : " + learn + "chown root f" + reset + "");
await interactive(131,"chown root f");
funcjs_131_chown_root_f();
await new_line(132,"Ici cette commande ne fonctionne pas ! C'est encore une fois un problème de permission, mais qui n'est pas du même type.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(133,"Par mesure de sécurité, certaines commandes peuvent uniquement être utilisées par l'utilisateur administrateur : " + voc + "root" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(134,"" + code + "chown" + reset + " est l'une d'entre elles, c'est une commande que seul " + voc + "root" + reset + " peut utiliser !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(135,"Mais je ne vous demanderai pas votre mot de passe " + voc + "root" + reset + " dans GameScript.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(136,"Je vous invite donc à tester cette commande " + code + "chown" + reset + " plus tard, en root, par vous même dans un autre terminal !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(137,"Pour vous connectez en " + code + "root" + reset + " vous pouvez faire : " + learn + "su root" + reset + ". Votre mot de passe vous sera alors demandé et vous aurez votre terminal en " + code + "root" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(138,"Pour tester si vous êtes bien " + voc + "root" + reset + " vous pouvez utiliser la commande : " + learn + "whoami" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(139,"Si vous voulez changer le " + voc + "groupe" + reset + " il faudra utiliser le symbole " + code + ":" + reset + ", comme par exemple " + learn + "chown :familleEinstein f" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(140,"Et bien évidemment vous pouvez changer les deux en même temps, comme par exemple " + learn + "chown albert:familleEinstein f" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(141,"Attention cependant à toutes les commandes que vous lancez en " + voc + "root" + reset + " !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(142,"" + voc + "root" + reset + " possède TOUTES les permissions pour TOUS les éléments !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(143,"" + voc + "root" + reset + " est non seulement capable de supprimer tous vos fichiers, mais il a aussi le pouvoir de rendre votre système inutilisable !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(144,"Une commande maladroite en " + voc + "root" + reset + ", ou un script malicieux en " + voc + "root" + reset + " peuvent avoir des effets dévastateurs.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(145,"Vous maitrisez maintenant tout ce qu'il vous faut pour analyser et maitriser vos permissions.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(146,"Bonne chance pour le questionnaire !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
launchGameScript_chapter_quiz();
}
async function launchGameScript_chapter_quiz() {
reset_GS();
intro_quiz_message();
document.getElementById('button_print_passwords').style.display='none';
document.getElementById('GS_selects').style.display='none';
document.getElementById('toggle_music_quiz').style.display='inline';
document.getElementById('button_start_quiz').style.display='none';
document.getElementById('button_start_lecture').value='Stop Quiz';
document.getElementById('button_start_lecture').onclick = function() { reset_GS(); }
toggle_music_quiz();
GOOD=1;
if(GOOD){ GOOD=await quiz("1","Dans un terminal root, comment définir 'albert' comme propriétaire et 'familleEinstein' comme groupe au fichier 'test' du répertoire courant ?","chown albert:familleEinstein test"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("2","Quelle commande affiche les éléments du répertoire courant par ordre alphabétique ?","ls"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("3","Quelle commande affiche les métadonnées des éléments du répertoire courant ?","ls -l"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("4","Comment afficher tous les éléments du répertoire courant dont le nom commence par 'x' ?","ls x*"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("5","Comment supprimer tous les éléments du répertoire courant ayant un nom de 2 lettres ?","rm ??"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("6","Comment déplacer tous les éléments du répertoire courant qui finissent par '.html' dans le répertoire parent de votre répertoire parent ?","mv *.html ../.."); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("7","Comment donner au fichier 'test' les permissions : --x-----x ?","chmod 101 test"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("8","Comment donner au fichier 'test' les permissions : rwxr-x-wx ?","chmod 753 test"); } else { error_quiz_message(); return; }
P1="8239";
P2="df22";
await ask_username(P1,P2,WHOAMI,SUBJECT,CHAPTER);
}
LINES=146
setTimeout(function(){ download_audio_chapter(WHOAMI,'fr','classic','bash','m1','6'); }, 2000);
if(VIDEO) download_video_chapter(WHOAMI,'fr','classic','bash','m1','6');
