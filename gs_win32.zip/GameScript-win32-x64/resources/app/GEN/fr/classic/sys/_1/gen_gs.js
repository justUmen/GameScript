function funcjs_14_ps(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_17_ps__e(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_19_ps__e_wc__l(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_22_ps(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_26_ps__f(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_32_ps__fH(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_43_sleep_3(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_75_ps(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_133_ps__elf_grep_leafpad(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_145_kill__THISPID(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_153_man_7_signal(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_171_ps__elf_grep_leafpad(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_173_kill__SIGTSTP__THISPID(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_175_ps__elf_grep_leafpad(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_178_kill__SIGCONT__THISPID(){
GS_text.innerHTML += `<hr>
<hr>`;}
function funcjs_180_ps__elf_grep_leafpad(){
GS_text.innerHTML += `<hr>
<hr>`;}
async function launchGameScript_chapter_lecture() {

reset_GS();
document.getElementById('toggle_music').style.display='inline';
document.getElementById('toggle_voice').style.display='inline';
document.getElementById('button_print_passwords').style.display='none';
document.getElementById('GS_selects').style.display='none';
document.getElementById('button_start_lecture').style.display='none';
document.getElementById('button_start_quiz').value='Stop Lecture';
document.getElementById('button_start_quiz').onclick = function() { reset_GS(); };
toggle_music();
await new_line(7,"Votre système d'exploitation est multitâche, c'est à dire qu'il est capable d'exécuter plusieures tâches simultanément.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(8,"Par exemple, vous pouvez avoir un éditeur de texte et un navigateur web ouvert en même temps sans rencontrer de difficultés.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(9,"Lorsque ces programmes sont en cours d'exécution sur votre ordinateur, on parle alors de " + voc + "processus" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(10,"Un programme est donc une entité " + voc + "passive" + reset + " (Seulement présente sur votre disque en tant que fichier exécutable), alors qu'un processus est une entité " + voc + "active" + reset + " (Exécuté par votre processeur).");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(11,"Un même programme peut être lancé plusieures fois, il est donc possible d'avoir plusieurs processus pour un seul programme.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(12,"Dans cette série nous verrons ensemble comment analyser et contrôler ces processus.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(13,"Commencons par lister vos processus avec la commande : " + learn + "ps" + reset + "");
await interactive(14,"ps");
funcjs_14_ps();
await new_line(15,"Evidemment il y a bien plus de processus que ça sur votre ordinateur...");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(16,"Pour lister tous les processus, faites : " + learn + "ps -e" + reset + "");
await interactive(17,"ps -e");
funcjs_17_ps__e();
new_line_no_wait(18,"Pour compter le nombre de processus dans cette liste, vous pouvez donc faire : " + learn + "ps -e|wc -l" + reset + "");
await interactive(19,"ps -e|wc -l");
funcjs_19_ps__e_wc__l();
await new_line(20,"Mais pour l'instant nous allons nous concentrer sur le résultat de la commande ps, qui affiche uniquement certains de ces processus.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(21,"Faites donc à nouveau : " + learn + "ps" + reset + "");
await interactive(22,"ps");
funcjs_22_ps();
await new_line(23,"Tout exécutable qui a été 'exécuté' sur votre système d'exploitation est un processus !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(24,"Votre terminal est un processus, mais l'instance de bash à l'intérieur de ce terminal est également un processus.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(25,"Affichez plus détails sur ces processus avec : " + learn + "ps -f" + reset + "");
await interactive(26,"ps -f");
funcjs_26_ps__f();
await new_line(27,"Chaque processus aura un identifiant unique capable de l'identifier : son PID, ici la deuxième colonne. (l'anglais de Process IDentifier)");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(28,"C'est un numéro unique qui pourra être utilisé pour manipuler le comportement du processus portant ce numéro.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(29,"Vous avez ici, une colonne nommée 'PPID' : Il s'agit de l'identifiant (PID) du processus parent. (Parent Process IDentifier)");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(30,"Les processus ont une relation parent/enfant : Dans cet example, on dit que la commande 'ps -f' est le processus enfant de 'standalone.sh' et que 'standalone.sh' est le parent du processus 'ps -f'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(31,"Affichez donc le même résultat avec une indentation : " + learn + "ps -fH" + reset + "");
await interactive(32,"ps -fH");
funcjs_32_ps__fH();
await new_line(33,"Cette indentation/décalage avec l'option '-H' représente visuellement cette relation enfant/parent.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(34,"Ici vous pouvez voir que 'gamescript.sh' est le parent d'un processus 'standalone', qui est en fait le chapitre que vous utilisez en ce moment. (sys 1)");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(35,"Toutes les commandes que vous lancez ici seront bien évidemment aussi des processus.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(36,"C'est pourquoi vous pouvez voir ici la commande 'ps -fH'. C'est un processus comme un autre, on peut dire qu'il s'affiche lui-même.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(37,"Mais ce processus 'ps -fH' est différent des autres parce qu'il n'existe plus !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(38,"Il existera juste le temps qu'il lui faut pour afficher ce qu'il doit afficher et disparaîtra.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(39,"Si cette commande est lancée à partir d'un shell bash, cette instance de bash sera le parent de ce processus et cette commande y sera 'attachée'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(40,"Ici ,cette commande étant lancé à partir d'un script (standalone.sh), elle s'attachera au même terminal que ce script.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(41,"Le processus en question prendra le contrôle de votre shell et s'appropriera son interactivité.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(42,"Voyons la même chose au ralentit : lancez par exemple la commande qui attend 3 secondes : " + learn + "sleep 3" + reset + "");
await interactive(43,"sleep 3");
funcjs_43_sleep_3();
await new_line(44,"Ici, votre terminal attend que la commande soit terminée pour vous rendre la main. Cette commande dure bien évidemment 3 secondes.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(45,"Entre temps, votre terminal est inutilisable !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(47,"Je viens d'ouvrir pour vous une nouvelle instance de bash avec 'tmux'. Pour alterner entre ce nouveau terminal et GameScript, vous devez faire 'Ctrl + b' puis appuyez sur la touche 'o' ou les flèches de votre clavier. Revenez donc sur GameScript pour continuer.");
new_line_no_wait(49,"Maintenant retournez dans le terminal du bas, lancez 'sleep 10', mais avant que cette commande ne se termine, essayez de lancer la commande 'pwd', puis revenez sur GameScript.");
await new_line(52,"Ici vous voyez que le terminal a complétement ignoré votre commande.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(53,"Maintenant retournez dans le terminal du bas, lancez 'leafpad', essayez de lancer la commande 'pwd', puis revenez sur GameScript.");
await new_line(56,"Encore une fois, vous pouvez voir que le terminal a complétement ignoré votre commande.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(57,"Quitter maintenant le processus leafpad en faisant 'Fichier' 'Quitter' et vous devriez voir que le terminal du bas redeviendra disponible.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(58,"Si vous lancez un processus interactif (comme leafpad), votre terminal se mettre en 'pause'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(59,"Vous ne pouvez plus interagir avec votre shell, mais vous pouvez en revanche envoyer des signaux à ce processus à partir du terminal qui l'a lancé.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(60,"Le signal le plus important est certainement 'Ctrl + c', qui vous permet de fermer le processus qui monopolise votre terminal.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(61,"Retournez dans le terminal du bas, lancez à nouveau 'leafpad', puis faites 'Ctrl + c' dans ce terminal pour fermer 'leafpad'.");
await new_line(64,"Si vous voulez lancer un programme, mais que vous voulez continuer à pouvoir utiliser votre terminal, vous pouvez aussi le " + voc + "suspendre" + reset + " avec la combinaison 'Ctrl + z'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(65,"Retournez dans le terminal du bas, lancez " + learn + "leafpad" + reset + ", puis faites 'Ctrl + z' dans le terminal pour détacher 'leafpad', essayez la commande 'pwd'.");
await new_line(68,"Cette fois, vous pouvez remarqué que leafpad ne s'est pas fermé, mais vous pouvez continuer à utiliser votre terminal normalement.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(69,"Maintenant lancez dans le terminal du bas la commande " + learn + "ps" + reset + ", puis revenez sur GameScript.");
await new_line(72,"Sans argument, la commande " + learn + "ps" + reset + " affichera les processus enfants de votre shell.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(73,"Comme vous avez utilisé ce terminal pour lancer 'leafpad', vous pouvez voir ici que 'leafpad' est dans la liste.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(74,"Lancez donc ici également la commande : " + learn + "ps" + reset + "");
await interactive(75,"ps");
funcjs_75_ps();
await new_line(76,"Dans le terminal de GameScript, vous voyez bien que 'leafpad' n'est pas présent avec un simple 'ps', car ce terminal n'est pas le parent de ce processus !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(77,"Retournez maintenant dans le terminal du bas et affichez les relations parents/enfants de vos processus avec la commande : " + learn + "ps -fH" + reset + "");
await new_line(80,"Ici vous pouvez voir clairement que leafpad est un enfant de votre shell (bash).");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(81,"Maintenant, essayez d'écrire quelque chose dans leafpad, puis revenez sur GameScript pour continuer.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(82,"'Ctrl + z' a " + voc + "suspendu" + reset + " ce processus de leafpad, ce qui a eu pour effet de le rendre " + voc + "inutilisable" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(83,"Pour faire l'inverse de 'Ctrl + z', c'est à dire récupérer ce programme, vous pouvez utilisez la commande 'fg'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(84,"Retournez dans le terminal du bas, lancez " + learn + "fg" + reset + ", essayez d'utiliser votre instance de 'leafpad' et revenez sur GameScript.");
await new_line(87,"'fg' est l'abréviation de 'foreground', l'anglais de 'premier plan' : le processus revient donc au 'premier plan'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(88,"Vous pouvez voir que 'leafpad' est maintenant utilisable mais plus votre terminal...");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(89,"Vous pouvez aussi utiliser la commande 'bg', l'abréviation de 'background', l'anglais de 'arrière plan' pour que le processus soit utilisable mais ne monopolise pas le terminal !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(90,"Retournez sur le terminal du bas, faites 'Ctrl + z' pour détacher 'leafpad' et utilisez la commande 'bg' pour rendre 'leafpad' utilisable à nouveau. ('leafpad' tournera en 'arrière plan'.)");
new_line_no_wait(93,"Retournez sur le terminal du bas, puis affichez la situation des processus que vous avez ouvert dans ce terminal avec la commande : " + learn + "jobs" + reset + "");
await new_line(96,"Un 'job' est un processus que vous pouvez contrôler avec 'fg' ou 'bg'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(97,"Nous n'avons qu'un seul processus pour le moment, mais nous allons en rajouter un à cette liste !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(98,"Retournez sur votre terminal, lancez une autre instance de 'leafpad', faites à nouveau 'Ctrl + z' et lancer la commande " + learn + "jobs" + reset + " avant de revenir sur GameScript.");
await new_line(101,"Ici nous avons deux 'jobs', et l'un d'entre eux n'est pas utilisable, comme vous pouvez le voir car son état est : " + voc + "Stopped" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(102,"Si il n'y a qu'un seul job dans votre terminal, vous n'avez pas besoin de spécifier un argument aux commandes " + code + "fg" + reset + " et " + code + "bg" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(103,"En revanche, si vous en avez plusieurs comme maintenant, il faudra ajouter en argument leur identifiants, que vous pouvez voir dans la première colonne.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(104,"Retournez dans le terminal du bas, et mettez le job [2] en arrière plan avec " + learn + "bg %2" + reset + ", puis revenez sur GameScript.");
await new_line(107,"Si vous vouliez utiliser " + learn + "fg" + reset + " à la place, la syntaxe aurait été similaire : " + learn + "fg %2" + reset + "");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(108,"Retournez dans le terminal du bas, et faites à nouveau : " + learn + "jobs" + reset + "");
await new_line(111,"Vous devriez voir maintenant que vos deux instances de leafpad ont comme état : " + voc + "Running" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(112,"Il est aussi possible de lancer directement un processus en arrière plan avec le symbole " + code + "&" + reset + " à la fin de votre commande.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(113,"Faites le donc maintenant. Retournez dans le terminal du bas, lancez une troisième instance de leafpad directement en arrière plan avec " + learn + "leafpad&" + reset + " et refaites " + learn + "jobs" + reset + ".");
await new_line(116,"Ici vous voyez qu'avec l'utilisation du symbole " + code + "&" + reset + " son statut est automatiquement " + voc + "Running" + reset + " et votre terminal est utilisable.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(117,"'jobs', 'bg', 'fg' et '&' sont très utiles pour contrôler les jobs du terminal en question.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(118,"Mais " + voc + "attention" + reset + " !! Si vous fermez ce terminal, tous ses jobs se fermeront également !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(121,"Voyons un exemple de ce phénomène. Je viens d'ouvrir un troisième terminal avec 'tmux'. Lancez la commande 'galculator&' dedans puis fermer ce "terminal" avec la commande 'tmux kill-pane'.");
await new_line(124,"La commande 'tmux kill-pane' simule dans tmux le simple fait de fermer votre terminal. (Fichier/Quitter dans un terminal graphique par exemple.)");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(125,"Et vous pouvez voir que le processus 'galculator' s'est également fermé en même temps.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(126,"Attention donc à ne pas fermer le terminal qui contient vos processus importants !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(127,"Si vous voulez fermer ce terminal, mais que ce processus enfant reste ouvert, vous pouvez ordonner à ce terminal d'abandonner ce processus avec la commande " + learn + "disown" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(128,"Retournez donc dans le terminal du bas, faites " + learn + "disown %1" + reset + ", puis réaffichez l'état de vos jobs.");
await new_line(131,"Ici vous voyez que l'un des processus de leafpad n'est plus dans la liste, mais ce processus existe toujours.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(132,"Vérifiez sa présence maintenant avec un : " + learn + "ps -elf|grep leafpad" + reset + "");
await interactive(133,"ps -elf|grep leafpad");
funcjs_133_ps__elf_grep_leafpad();
await new_line(134,"Ici il y a bien 3 instances de leafpad, mais seulement 2 sont relié au terminal du bas.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(135,"A partir de maintenant, ce processus ne se fermera plus quand votre terminal se fermera. (Faites moi confiance pour le moment.)");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(136,"Mais n'oubliez pas que ces 'jobs' sont avant tout des " + voc + "processus" + reset + " !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(137,"Et vous pouvez aussi directement les contrôler avec leur PID, quel que soit votre terminal actuel.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(138,"Retournez dans le terminal du bas, affichez le PID de vos jobs avec " + learn + "jobs -l" + reset + " et la liste de vos processus enfants avec " + learn + "ps -fH" + reset + ".");
await new_line(141,"Avec son PID et la commande " + code + "kill" + reset + ", vous pouvez cibler un processus même en dehors de votre terminal. (contrairement à fg, bg et disown.)");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(142,"La commande " + code + "kill" + reset + " (anglais de tuer) permet de fermer un processus dont le PID est donné en argument.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(144,"Fermez l'un des processus de leafpad à partir du terminal de GameScript avec : " + learn + "kill $THISPID" + reset + " (Notez le PID correspondant dans le terminal ci-dessous.)");
await interactive(145,"kill $THISPID");
funcjs_145_kill__THISPID();
new_line_no_wait(146,"Retournez dans le terminal du bas et listez vos processus à nouveau avec " + learn + "ps -fH" + reset + ", puis revenez sur GameScript.");
await new_line(149,"Ici il est bien clair que l'une des instances de leafpad a été fermée.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(150,"Malgré son nom, la commande " + code + "kill" + reset + " est capable de faire bien plus que de 'tuer' un processus.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(151,"" + code + "kill" + reset + " est capable d'envoyer vers un processus une grande quantité de " + voc + "signaux" + reset + " différents que vous pouvez donner en option.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(152,"Regardez rapidement le résultat de la commande " + code + "man 7 signal" + reset + " pour affichez la liste des signaux disponibles et revenez sur GameScript en quittant avec la touche 'q'.");
await interactive(153,"man 7 signal");
funcjs_153_man_7_signal();
await new_line(154,"Ici nous allons nous intéresser à seulement cinq de ces signaux : SIGTSTP, SIGSTOP, SIGCONT, SIGTERM et SIGKILL");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(155,"SIGTERM est le signal par défaut de la commande " + code + "kill" + reset + ", c'est à dire que la commande " + code + "kill" + reset + " est équivalente à la commande " + code + "kill -SIGTERM" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(156,"Le processus en argument de la commande " + code + "kill" + reset + " recevra ce signal SIGTERM et tentera de se fermer proprement.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(157,"Si votre processus ne répond plus pour une certaine raison, il ne sera pas possible de le fermer de cette manière...");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(158,"Dans ce genre de situation, (qui ne devrait jamais se produire sans une excellente raison) vous pouvez envoyez le signal SIGKILL !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(159,"Contrairement à SIGTERM, le signal SIGKILL ne peut pas être bloqué par le processus cible, il n'aura donc pas l'occassion de se fermer proprement : on peut dire qu'il sera froidement assassiné.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(160,"Pour afficher le statut de vos processus, vous pouvez utiliser ps avec son option -l. Essayez donc " + learn + "ps -l" + reset + " dans le terminal du bas.");
await new_line(163,"Le statut de vos processus est dans le résultat de " + code + "ps -l" + reset + " une lettre dans la colonne S (statut).");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(164,"" + code + "T" + reset + " est l'équivalent du statut job 'Running', et " + code + "S" + reset + " est l'équivalent du statut 'Stopped'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(165,"Pour plus de détails sur ces statuts et leurs significations, n'hésitez pas à visitez le manuel de la commande " + code + "ps" + reset + ".");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(167,"Voyons maintenant deux autres signaux, capables de changer le statut de vos processus : SIGTSTP et SIGSTOP.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(168,"Le signal SIGTSTP a le même effet que la combinaison de touche 'Ctrl + z' : votre processus sera 'suspendu'.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(169,"Le signal SIGSTOP est similaire à SIGTSTP, mais comme SIGKILL, il ne pourra pas être ignoré par le processus cible.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(170,"Affichez donc le statut de vos processus leafpad avec : " + learn + "ps -elf|grep leafpad" + reset + " ('elf' est l'anglais de 'elfe' :p)");
await interactive(171,"ps -elf|grep leafpad");
funcjs_171_ps__elf_grep_leafpad();
new_line_no_wait(172,"Suspendez l'un de ces processus leafpad avec : " + learn + "kill -SIGTSTP $THISPID" + reset + "");
await interactive(173,"kill -SIGTSTP $THISPID");
funcjs_173_kill__SIGTSTP__THISPID();
new_line_no_wait(174,"Puis listez à nouveau le statut de vos processus leafpad.");
await interactive(175,"ps -elf|grep leafpad");
funcjs_175_ps__elf_grep_leafpad();
await new_line(176,"Cette commande confirme que cette instance de leafpad à été suspendue (T), mais vous pouvez tester par vous-même : l'une de vos instance de leafpad n'est plus utilisable.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(177,"Pour permettre à ce processus de continuer à exister, faites : " + learn + "kill -SIGCONT $THISPID" + reset + "");
await interactive(178,"kill -SIGCONT $THISPID");
funcjs_178_kill__SIGCONT__THISPID();
new_line_no_wait(179,"Puis faites à nouveau : " + learn + "ps -elf|grep leafpad" + reset + "");
await interactive(180,"ps -elf|grep leafpad");
funcjs_180_ps__elf_grep_leafpad();
await new_line(181,"Cette commande confirme que cette instance de leafpad est à nouveau utilisable (S), mais vous pouvez tester par vous-même.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(182,"Mais... qu'en est-il de la combinaison 'Ctrl + c' que nous avions déjà vu ? Est-ce un signal ?");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(183,"Et bien oui. Et le signal en question est SIGINT, qui représente une interruption par l'intermédiaire du clavier.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(184,"Mais son effet est similaire à SIGTERM : il donne donc au processus l'occasion de se fermer proprement.");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
new_line_no_wait(185,"Avant de finir ce chapitre, fermez le terminal du bas avec la commande " + learn + "tmux kill-pane" + reset + ".");
await new_line(188,"Comme promis, l'un des processus de leafpad a survécu : celui que vous avez " + code + "disown" + reset + " !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
await new_line(189,"Votre confiance a finit par payer... Vous être prêt pour le questionnaire !");
if(STOP_RUNNING){STOP_RUNNING=0;return 1;}
launchGameScript_chapter_quiz();
}
async function launchGameScript_chapter_quiz() {
reset_GS();
intro_quiz_message();
document.getElementById('button_print_passwords').style.display='none';
document.getElementById('GS_selects').style.display='none';
document.getElementById('toggle_music_quiz').style.display='inline';
document.getElementById('button_start_quiz').style.display='none';
document.getElementById('button_start_lecture').value='Stop Quiz';
document.getElementById('button_start_lecture').onclick = function() { reset_GS(); }
toggle_music_quiz();
GOOD=1;
if(GOOD){ GOOD=await quiz("1","Quelle est la commande qui affiche la liste de vos 'jobs' ?","jobs"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("2","Comment lancer le gestionnaire de fichier 'pcmanfm' en arrière plan à partir d'un terminal ?","pcmanfm&"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("3","Si votre job est 'Stopped', quel signal devez vous envoyer pour le rendre utilisable ? (Votre réponse doit commencer par SIG)","SIGCONT"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("4","Quelle est la lettre INCONNU dans la phrase ? : Pour envoyer le signal SIGINT au processus, vous devez faire 'Ctrl + INCONNU'.","c"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("5","Un PID représente uniquement un seul processus à un moment donné. (vrai/faux)","vrai"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("6","Un PPID en revanche peut représenter plusieurs processus à un moment donné. (vrai/faux)","faux"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("7","Quelle est la commande pour envoyer le job numéro 4 en arrière plan ?","bg %4"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("8","Quelle est la commande pour demander sa fermeture au processus avec le PID 666 ?","kill 666"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("9","Quelle est la commande qui permet d'éviter que le job numéro 4 ne se ferme en même temps que son terminal parent ?","disown %4"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("10","Quelle est la lettre INCONNU dans la phrase ? : Pour envoyer le signal SIGTSTP au processus, vous devez faire 'Ctrl + INCONNU'.","z"); } else { error_quiz_message(); return; }
if(GOOD){ GOOD=await quiz("11","Quelle est la commande qui peut fermer le processus avec le PID 666 même s'il ne répond plus ? (la commande doit utiliser la syntaxe -SIG...)","kill -SIGKILL 666"); } else { error_quiz_message(); return; }
P1="bbb2";
P2="112b";
await ask_username(P1,P2,WHOAMI,SUBJECT,CHAPTER);
}
LINES=173
setTimeout(function(){ download_audio_chapter(WHOAMI,'fr','classic','sys','m1','1'); }, 2000);
if(VIDEO) download_video_chapter(WHOAMI,'fr','classic','sys','m1','1');
