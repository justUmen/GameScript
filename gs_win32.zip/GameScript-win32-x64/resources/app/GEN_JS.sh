#!/bin/bash
#./GEN_JS.sh fr classic bash 1

#COMPILE AND LAUNCH :
# electron-packager . GameScript --overwrite --platform=linux --arch=x64 --out=release-builds && cd release-builds/GameScript-linux-x64/ && ./GameScript;cd -

if [ ! $4 ]; then
	echo "USE CONTENT OF /home/umen/SyNc/Projects/GameScript/ : for each chapter, LIST_4GEN.txt, electron_functions.js and quiz_and_password.txt to create a file gen_gs.js in folder GameScript_electron/GEN/fr/classic/bash/_1/ that is included in shell.html."
	echo "Usage : ./GEN_JS.sh fr classic bash 1"
	exit 233
fi

#Test if all 3 files exist
if [ ! -e "/home/umen/SyNc/Projects/GameScript/${1}/${2}/${3}/_${4}/LIST_4GEN.txt" ]; then
	echo "ERROR, file not exist : /home/umen/SyNc/Projects/GameScript/${1}/${2}/${3}/_${4}/LIST_4GEN.txt";
	exit 211
fi
#CREATE EMPTY CONTENT of electron_functions.js with script ???
if [ ! -e "/home/umen/SyNc/Projects/GameScript/${1}/${2}/${3}/_${4}/electron_functions.js" ]; then
	echo "ERROR, file not exist : /home/umen/SyNc/Projects/GameScript/${1}/${2}/${3}/_${4}/electron_functions.js";
	exit 211
fi
if [ ! -e "/home/umen/SyNc/Projects/GameScript/${1}/${2}/${3}/_${4}/quiz_and_password.txt" ]; then
	echo "ERROR, file not exist : /home/umen/SyNc/Projects/GameScript/${1}/${2}/${3}/_${4}/quiz_and_password.txt";
	exit 211
fi

# exit

mkdir -p /home/umen/SyNc/Projects/GameScript_electron/GEN/${1}/${2}/${3}/_${4}

cat /home/umen/SyNc/Projects/GameScript/${1}/${2}/${3}/_${4}/electron_functions.js > GEN/${1}/${2}/${3}/_${4}/gen_gs.js
#Before launch with button
#~ \nGS_text.innerHTML += \"<div> Press any key to start GameScript Chapter ... </div>\";await waitPressKey();
echo -e "async function launchGameScript_chapter_lecture() {\n" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
echo -e "reset_GS();" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
echo -e "document.getElementById('toggle_music').style.display='inline';" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
echo -e "document.getElementById('toggle_voice').style.display='inline';" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
echo -e "document.getElementById('button_print_passwords').style.display='none';" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js

echo -e "document.getElementById('GS_selects').style.display='none';" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
echo -e "document.getElementById('button_start_lecture').style.display='none';" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
echo -e "document.getElementById('button_start_quiz').value='Stop Lecture';" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
#reload for simple go back, make better now...
# echo -e "document.getElementById('button_start_quiz').onclick = function() { location.reload(); }" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
echo -e "document.getElementById('button_start_quiz').onclick = function() { reset_GS(); };" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
echo -e "toggle_music();" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js

#~ echo -e "GS_text.innerHTML = '';" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
#~ echo -e "if(FOCUS) clearInterval(FOCUS);" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
CMP=0
rm tmp/tmp_gen_functions_js_to_add_to_SPECIFIC_4GEN.js 2> /dev/null
while read LINE; do
	CMP=`expr $CMP + 1`
	#TEST IF START WITH A #
	if [[ "$LINE" =~ ^#.* ]]; then #THIS IS CODE
		#ONLY if function tree for now (TEST) ???
		if [[ "$LINE" =~ tree ]]; then
			echo "$LINE" | sed "s/^#//" | sed "s/$/();/" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
		fi
	elif [[ "$LINE" =~ ^\!.* ]]; then #This is interactive code
		# | sed 's#\\\#_#g'
		LINE_INTO_FUNC_NAME=`echo "$LINE" | sed "s/^!//" | sed "s/^!//" | sed "s/£.*//" | sed "s/ /_/g" | sed 's/"/_/g' | sed "s/'/_/g" | sed 's/[$]/_/g' | sed 's#/#_#g' | sed 's/\./_/g' | sed 's/~/_/g' | sed 's/-/_/g' | sed 's/\\\\/_/g' | sed 's/*/_/g' | sed 's/&/_/g' | sed 's/?/_/g' | sed 's/@/_/g' | sed 's/|/_/g' | sed 's/>/_/g' | sed 's/</_/g' | sed 's/(/_/g' | sed 's/)/_/g' | sed 's/{/_/g' | sed 's/}/_/g' | sed 's/:/_/g' | sed 's/=/_/g' | sed 's/;/_/g' | sed 's/\`/_/g' | sed 's/\[/_/g' | sed 's/\]/_/g'`
		echo "$LINE" | sed 's#$HOME#/home/example#' | sed "s/^!/await interactive($CMP,\"/" | sed "s/£.*/\");/" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
		echo "funcjs_${CMP}_$LINE_INTO_FUNC_NAME();" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js #??? need To write output function for every interactive lines (copy result from basic GS bash)
		#IF doesn't exist yet put in tmp_functions
		echo -e "function funcjs_${CMP}_$LINE_INTO_FUNC_NAME(){\nGS_text.innerHTML += \`<hr>\n<hr>\`;}"
		echo -e "function funcjs_${CMP}_$LINE_INTO_FUNC_NAME(){\nGS_text.innerHTML += \`<hr>\n<hr>\`;}" >> tmp/tmp_gen_functions_js_to_add_to_SPECIFIC_4GEN.js
	elif [[ "$LINE" =~ ^\+.* ]]; then #This line without waiting (next line starts with a !)
		echo "$LINE" | sed "s#^\+#new_line_no_wait($CMP,\"#" | sed 's#$#");#' | sed 's#${code}#" + code + "#g' | sed 's#${learn}#" + learn + "#g' | sed 's#${codeError}#" + codeError + "#g' | sed 's#${codeFile}#" + codeFile + "#g' | sed 's#${voc}#" + voc + "#g' | sed 's#${reset}#" + reset + "#g' | sed 's#$HOME#" + home + "#g' >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
	else
		echo "$LINE" | sed "s#^#await new_line($CMP,\"#" | sed 's#$#");#' | sed 's#${code}#" + code + "#g' | sed 's#${learn}#" + learn + "#g' | sed 's#${codeError}#" + codeError + "#g' | sed 's#${codeFile}#" + codeFile + "#g' | sed 's#${voc}#" + voc + "#g' | sed 's#${reset}#" + reset + "#g' | sed 's#$HOME#" + home + "#g' >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
		echo "if(STOP_RUNNING){STOP_RUNNING=0;return 1;}" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
	fi
done < /home/umen/SyNc/Projects/GameScript/${1}/${2}/${3}/_${4}/LIST_4GEN.txt
echo "launchGameScript_chapter_quiz();" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
echo "}" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js

#ON LAUNCH QUIZ, HIDE SOME BUTTONS
echo -e "async function launchGameScript_chapter_quiz() {" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
echo -e "reset_GS();" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
echo -e "intro_quiz_message();" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
echo -e "document.getElementById('button_print_passwords').style.display='none';" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
echo -e "document.getElementById('GS_selects').style.display='none';" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
echo -e "document.getElementById('toggle_music_quiz').style.display='inline';" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
#~ echo -e "await ask_username('24d8','f016',WHOAMI);" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js #ONLY ASK IF NOT SET
echo -e "document.getElementById('button_start_quiz').style.display='none';" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
echo -e "document.getElementById('button_start_lecture').value='Stop Quiz';" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
# echo -e "document.getElementById('button_start_lecture').onclick = function() { location.reload(); }" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
echo -e "document.getElementById('button_start_lecture').onclick = function() { reset_GS(); }" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
#~ echo -e "GS_text.innerHTML = '';" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
#~ echo -e "if(FOCUS) clearInterval(FOCUS);" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
echo -e "toggle_music_quiz();" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
echo -e "GOOD=1;" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
LINE=0
CMP=0
while read LINE; do
	CMP=`expr $CMP + 1`
	if [[ "$LINE" =~ ^#.* ]]; then #THIS CONTAINS PASSWORD (OR NUMBER OF LINES)
		if [[ "$LINE" =~ ^#P.* ]]; then #THIS CONTAINS PASSWORD
			echo "$LINE;" | sed "s/^#//" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
		else
			NUMBER_OF_LINES="$LINE" #NUMBER OF LINES = NUMBER OF AUDIO FILES
		fi
	else
		RIGHT=`echo "$LINE" | sed 's/.* |=| //' | sed 's/\\\\/\\\\\\\\/g' | sed 's/"/\\\\"/g'` #allow \ and " inside function argument
		LEFT=`echo "$LINE" | sed 's/ |=| .*//' | sed 's/"/\\\\"/g'`
		echo "if(GOOD){ GOOD=await quiz(\"$CMP\",\"$LEFT\",\"$RIGHT\"); } else { error_quiz_message(); return; }" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
	fi
done < /home/umen/SyNc/Projects/GameScript/${1}/${2}/${3}/_${4}/quiz_and_password.txt
echo -e "await ask_username(P1,P2,WHOAMI,SUBJECT,CHAPTER);" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
echo "}" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
echo "$NUMBER_OF_LINES" | sed "s/^#//" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js

# NB_LINE=`echo "$NUMBER_OF_LINES"|sed 's/.*=//'`
echo "setTimeout(function(){ download_audio_chapter(WHOAMI,'${1}','${2}','${3}','m1','${4}'); }, 2000);" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js

#??? video too for testing purposes...
echo "if(VIDEO) download_video_chapter(WHOAMI,'${1}','${2}','${3}','m1','${4}');" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js

#~ echo "launchGameScript_chapter();" >> GEN/${1}/${2}/${3}/_${4}/gen_gs.js
#launch with button instead...
#|grep -v '^#'
