#!/bin/bash
#GEN_JS.sh (tmp/) need :
#   [Edit manually] /home/umen/SyNc/Projects/GameScript/fr/classic/bash/_1/SPECIFIC_4GEN.js (functions)
#   [Edit manually] /home/umen/SyNc/Projects/GameScript/fr/classic/bash/_1/QUIZ_4GEN.txt (quiz and base64 passwords)
#   [TAKE FROM GAMESCRIPT] /home/umen/SyNc/Projects/GameScript/fr/classic/bash/_1/LIST_4GEN.txt
#GEN_JS.sh creates "gen_js.js" (tmp/)
for i in {1..11}; do
  echo "./GEN_JS.sh fr classic bash $i;"
  ./GEN_JS.sh fr classic bash $i
done

./GEN_JS.sh fr classic sys 1

#~ exit
#DO FOR ENGLISH LANGUAGE
for i in {1..1}; do
  echo "./GEN_JS.sh en classic bash $i;"
  ./GEN_JS.sh en classic bash $i
done
#~ ./GEN_JS.sh en classic sys 1
