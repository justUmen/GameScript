//TODO :
- for "press any key" to work properly, be sure to disable selection of all buttons...
- Store user info in userData ??? ~/.config/GameScript_electron on linux, windows ???

//LAUNCH WITH : (OLD)
//node_modules/electron/dist/electron .

//COMPILE WITH
electron-packager . GameScript --overwrite --platform=linux --arch=x64 --out=release-builds;cd release-builds/GameScript-linux-x64/;./GameScript;cd -

//TO SET DEFAULT OPTIONS, create manually file in folder 'tmp' : echo -n y > /home/umen/SyNc/Projects/GameScript_electron/tmp/video_background.tmp

//WINDOWS COMPILATION
electron-packager . GameScript --overwrite --platform=win32 --arch=x64 --out=release-builds;cd release-builds;zip -r gs.zip GameScript-win32-x64;php -S 192.168.39.116:5556 -t /home/umen/SyNc/Projects/GameScript_electron/release-builds;cd -
